# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(sf)
  library(ggplot2)
  library(rnaturalearth)
  library(scales)
  library(cowplot)
  library(svglite)
  library(grid)
})

sf::sf_use_s2(FALSE)

# =========================
# 1) File paths
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/未来情景/coal_plant_future_result.xlsx"
gpkg_path  <- "/Users/xuruiqing/Desktop/文章试验整体流程/data/GHS_UCDB_GLOBE_R2024A_V1_1/GHS_UCDB_GLOBE_R2024A.gpkg"

layer_name <- "GHS_UCDB_THEME_CLIMATE_GLOBE_R2024A"

# =========================
# 2) Config
# =========================
LON_COL  <- "Longitude"
LAT_COL  <- "Latitude"
BASE_COL <- "Productivity_loss"

SCENARIO <- "SSP126"
YEAR_USE <- 2050

FUTURE_COL <- paste0("loss_", SCENARIO, "_", YEAR_USE)

CITY_ID_COL <- "ID_UC_G0"

# =========================
# 2.5) Global scale for all 15 loss maps
# =========================
SCENARIOS_ALL <- c("SSP126", "SSP245", "SSP370")
YEARS_ALL <- c(2025, 2030, 2050, 2070, 2100)

df_all_raw <- read_excel(excel_path)

loss_cols_all <- unlist(lapply(SCENARIOS_ALL, function(ss) {
  paste0("loss_", ss, "_", YEARS_ALL)
}))

need_global_cols <- c(LON_COL, LAT_COL, BASE_COL, loss_cols_all)
need_global_cols <- unique(need_global_cols[need_global_cols %in% names(df_all_raw)])

df_all <- df_all_raw %>%
  mutate(
    Longitude = as.numeric(.data[[LON_COL]]),
    Latitude  = as.numeric(.data[[LAT_COL]]),
    loss_base = as.numeric(.data[[BASE_COL]])
  )

global_vals <- c()

for (ss in SCENARIOS_ALL) {
  for (yy in YEARS_ALL) {
    fcol <- paste0("loss_", ss, "_", yy)
    if (!(fcol %in% names(df_all))) next
    
    tmp <- df_all %>%
      mutate(loss_future = as.numeric(.data[[fcol]])) %>%
      filter(!is.na(Longitude), !is.na(Latitude), !is.na(loss_base), !is.na(loss_future)) %>%
      mutate(plot_val = pmax(loss_base - loss_future, 0))
    
    global_vals <- c(global_vals, tmp$plot_val)
  }
}

GLOBAL_Q95 <- quantile(global_vals, 0.95, na.rm = TRUE)
GLOBAL_UPPER_CAP <- max(GLOBAL_Q95, 1)

# =========================
# 3) Output folder
# =========================
out_dir <- paste0("lossmap_", SCENARIO, "_", YEAR_USE)
if (!dir.exists(out_dir)) dir.create(out_dir)

prefix <- file.path(
  out_dir,
  paste0("city_centroid_", SCENARIO, "_", YEAR_USE, "_avoidedloss_sum")
)

OUT_MAP_SVG   <- paste0(prefix, "_map.svg")
OUT_MAP_PDF   <- paste0(prefix, "_map.pdf")
OUT_LEG_SVG   <- paste0(prefix, "_legend.svg")
OUT_LEG_PDF   <- paste0(prefix, "_legend.pdf")
OUT_FINAL_SVG <- paste0(prefix, "_withLegend.svg")
OUT_FINAL_PDF <- paste0(prefix, "_withLegend.pdf")

# =========================
# 4) Read plant excel
# =========================
df_raw <- read_excel(excel_path)

df <- df_raw %>%
  mutate(
    Longitude   = as.numeric(.data[[LON_COL]]),
    Latitude    = as.numeric(.data[[LAT_COL]]),
    loss_base   = as.numeric(.data[[BASE_COL]]),
    loss_future = as.numeric(.data[[FUTURE_COL]])
  ) %>%
  filter(!is.na(Longitude), !is.na(Latitude), !is.na(loss_base), !is.na(loss_future)) %>%
  mutate(
    plot_val = loss_base - loss_future
  )

plants_sf <- st_as_sf(df, coords = c("Longitude","Latitude"), crs = 4326)

# =========================
# 5) City polygons
# =========================
cities <- st_read(gpkg_path, layer = layer_name, quiet = TRUE)
names(cities) <- sub("^X\\.","",names(cities))
geom_col <- attr(cities,"sf_column")

plants_sf_proj <- st_transform(plants_sf, st_crs(cities))

plants_joined <- st_join(
  plants_sf_proj,
  cities[,c(CITY_ID_COL,geom_col)],
  join = st_within,
  left = FALSE
)

# =========================
# 6) 聚合（总和）
# =========================
city_stat <- plants_joined %>%
  st_drop_geometry() %>%
  group_by(.data[[CITY_ID_COL]]) %>%
  summarise(
    sum_loss = sum(plot_val, na.rm = TRUE),
    plant_count = n(),
    .groups = "drop"
  )

cities_stat <- cities %>%
  left_join(city_stat, by = CITY_ID_COL) %>%
  filter(!is.na(sum_loss))

city_pts <- st_point_on_surface(cities_stat)
city_pts_wgs84 <- st_transform(city_pts, 4326)

world <- ne_countries(scale="medium", returnclass="sf")

# =========================
# 7) Color scale（统一）
# =========================
city_pts_wgs84$sum_loss <- pmax(city_pts_wgs84$sum_loss, 0)

upper_cap <- GLOBAL_UPPER_CAP
limits <- c(0, upper_cap)

# 红色
# cols <- c("#fee3ce","#eabaa1","#dc917b","#d16d5b","#c44438","#b7282e")

# 绿色
# cols <- c("#cfeadf","#a4cbb7","#81b095","#669877","#4d7e54","#376439")

# 紫红
cols <- c("#ebcce2","#dda1be","#c87d98","#b25f79","#9b3f5c","#832440")

anchors <- seq(0, upper_cap, length.out = length(cols))
vals <- rescale(anchors, to = c(0,1), from = limits)

brks <- pretty(c(0, upper_cap), n = 5)

# =========================
# 8) Main map
# =========================
p_map <- ggplot() +
  geom_sf(data=world, fill="grey88", color="grey70", linewidth=0.25) +
  geom_sf(
    data=city_pts_wgs84,
    aes(color=sum_loss, size=plant_count),
    alpha=0.95
  ) +
  scale_color_gradientn(
    colours=cols,
    values=vals,
    limits=limits,
    oob=scales::squish,
    breaks=brks,
    labels=label_number(scale_cut=cut_short_scale()),
    name=NULL,
    guide="none"
  ) +
  scale_size_continuous(
    range=c(0.8,3.5),
    breaks=c(1,3,5,10,20),
    name=NULL,
    guide="none"
  ) +
  coord_sf(expand=FALSE,xlim=c(-150,150),ylim=c(-60,80)) +
  theme_minimal(base_size=12) +
  theme(
    panel.grid=element_blank(),
    panel.border=element_rect(color="grey40", fill=NA, linewidth=0.6)
  )

ggsave(OUT_MAP_SVG,p_map,width=12,height=5.2,device=svglite::svglite)
ggsave(OUT_MAP_PDF,p_map,width=12,height=5.2)

# =========================
# 9) Legend（完全按你原版）
# =========================
LEG_TITLE_COLOR <- paste0("Avoided loss\n",SCENARIO," ",YEAR_USE)

p_leg_color_src <- ggplot() +
  geom_sf(data=world, fill="grey88", color="grey70", linewidth=0.25) +
  geom_sf(
    data=city_pts_wgs84,
    aes(color=sum_loss),
    size=2.5,
    alpha=0.95
  ) +
  scale_color_gradientn(
    colours=cols,
    values=vals,
    limits=limits,
    oob=scales::squish,
    breaks=brks,
    labels=label_number(scale_cut=cut_short_scale()),
    name=LEG_TITLE_COLOR,
    guide=guide_colorbar(
      barheight=unit(50,"mm"),
      barwidth=unit(6,"mm"),
      ticks.colour="grey30",
      frame.colour="grey30"
    )
  ) +
  theme_minimal(base_size=12) +
  theme(
    panel.grid=element_blank(),
    legend.position="left",
    legend.title=element_text(size=10),
    legend.text=element_text(size=9)
  )

leg_color <- cowplot::get_legend(p_leg_color_src)

ggsave(OUT_LEG_SVG,leg_color,width=1.8,height=2.8,device=svglite::svglite)
ggsave(OUT_LEG_PDF,leg_color,width=1.8,height=2.8)

# =========================
# 10) Combine
# =========================
p_final <- cowplot::ggdraw() +
  cowplot::draw_plot(p_map,0,0,1,1) +
  cowplot::draw_plot(leg_color,0.08,0.09,0.12,0.42)

ggsave(OUT_FINAL_SVG,p_final,width=12,height=5.2,device=svglite::svglite)
ggsave(OUT_FINAL_PDF,p_final,width=12,height=5.2)