suppressPackageStartupMessages({
  library(rsvg)
})

base_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图三退役与未来情景"
map_dir <- file.path(base_dir, "2050年GADM城市年度损失减少世界地图")
rank_dir <- file.path(base_dir, "2050年城市减损与持续风险双榜图")
donut_dir <- file.path(base_dir, "2050年三情景避免损失环形图")
include_donuts <- tolower(Sys.getenv("INCLUDE_DONUTS", unset = "true")) %in%
  c("true", "1", "yes")
out_dir <- file.path(
  base_dir,
  if (include_donuts) "图三三情景地图与城市双榜组图" else "图三三情景地图与城市双榜组图_无环形图"
)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

scenarios <- c("SSP126", "SSP245", "SSP370")
map_files <- file.path(
  map_dir,
  paste0("gadm_admin2_annual_loss_reduction_", scenarios, "_2050.svg")
)
rank_files <- file.path(
  rank_dir,
  paste0("city_dual_rank_", scenarios, "_2050.svg")
)
donut_files <- file.path(
  donut_dir,
  paste0("avoided_loss_donut_", scenarios, "_2050.svg")
)

all_files <- c(map_files, rank_files, if (include_donuts) donut_files else character())
if (!all(file.exists(all_files))) {
  stop("Missing source SVG files: ", paste(all_files[!file.exists(all_files)], collapse = ", "))
}

output_stem <- if (include_donuts) {
  "Figure3_2050_three_SSP_maps_city_dual_rank"
} else {
  "Figure3_2050_three_SSP_maps_city_dual_rank_no_donuts"
}
out_svg <- file.path(out_dir, paste0(output_stem, ".svg"))
out_pdf <- file.path(out_dir, paste0(output_stem, ".pdf"))
out_png <- file.path(out_dir, paste0(output_stem, ".png"))

canvas_w <- 1200
canvas_h <- 960
left_margin <- 24
top_margin <- 24
column_gap <- 8
row_gap <- 14
map_w <- 690
row_h <- map_w / (864 / 374.4)
rank_x <- left_margin + map_w + column_gap
rank_w <- canvas_w - rank_x - 24
row_y <- top_margin + (0:2) * (row_h + row_gap)

inline_svg <- function(path, prefix, x, y, width, height, source_w, source_h) {
  txt <- paste(readLines(path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
  txt <- sub("^<\\?xml[^>]*>\\s*", "", txt, perl = TRUE)
  txt <- sub("^<!DOCTYPE[^>]*>\\s*", "", txt, perl = TRUE)
  txt <- sub("^<svg[^>]*>", "", txt, perl = TRUE)
  txt <- sub("</svg>\\s*$", "", txt, perl = TRUE)

  id_hits <- regmatches(txt, gregexpr("id=['\"][^'\"]+['\"]", txt, perl = TRUE))[[1]]
  if (length(id_hits) > 0 && id_hits[1] != "") {
    ids <- unique(sub("^id=['\"]([^'\"]+)['\"]$", "\\1", id_hits, perl = TRUE))
    for (old_id in ids) {
      txt <- gsub(paste0("id='", old_id, "'"), paste0("id='", prefix, old_id, "'"), txt, fixed = TRUE)
      txt <- gsub(paste0('id="', old_id, '"'), paste0('id="', prefix, old_id, '"'), txt, fixed = TRUE)
      txt <- gsub(paste0("#", old_id), paste0("#", prefix, old_id), txt, fixed = TRUE)
    }
  }

  paste0(
    sprintf(
      paste0(
        "  <svg x='%.2f' y='%.2f' width='%.2f' height='%.2f' ",
        "viewBox='0 0 %.2f %.2f' preserveAspectRatio='xMidYMid meet'>\n"
      ),
      x, y, width, height, source_w, source_h
    ),
    txt,
    "\n  </svg>"
  )
}

panel_letters <- matrix(c("a", "b", "c", "d", "e", "f"), nrow = 3, byrow = TRUE)
svg_lines <- c(
  sprintf(
    paste0(
      "<svg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' ",
      "width='%dpt' height='%dpt' viewBox='0 0 %d %d'>"
    ),
    canvas_w, canvas_h, canvas_w, canvas_h
  ),
  sprintf("  <rect x='0' y='0' width='%d' height='%d' fill='white'/>", canvas_w, canvas_h)
)

for (i in seq_along(scenarios)) {
  y <- row_y[i]
  # Match the normalized Indian-Ocean inset used in Figure 2 panel a.
  donut_x <- left_margin + 0.60 * map_w
  donut_y <- y + 0.54 * row_h
  donut_w <- 0.25 * map_w
  donut_h <- 0.36 * row_h
  donut_markup <- if (include_donuts) {
    inline_svg(donut_files[i], paste0("donut", i, "_"), donut_x, donut_y, donut_w, donut_h, 216, 162)
  } else {
    character()
  }
  svg_lines <- c(
    svg_lines,
    inline_svg(map_files[i], paste0("map", i, "_"), left_margin, y, map_w, row_h, 864, 374.4),
    donut_markup,
    inline_svg(rank_files[i], paste0("rank", i, "_"), rank_x, y, rank_w, row_h, 698.4, 460.8),
    sprintf(
      "  <text x='65' y='%.2f' font-family='Arial, Helvetica, sans-serif' font-size='22' font-weight='700'>%s</text>",
      y - 5, panel_letters[i, 1]
    ),
    sprintf(
      "  <text x='%.2f' y='%.2f' font-family='Arial, Helvetica, sans-serif' font-size='22' font-weight='700'>%s</text>",
      rank_x + 16, y - 5, panel_letters[i, 2]
    )
  )
}

svg_lines <- c(svg_lines, "</svg>")
writeLines(svg_lines, out_svg, useBytes = TRUE)
rsvg_pdf(out_svg, out_pdf)
rsvg_png(out_svg, out_png, width = 3000)

cat("Composite SVG:", out_svg, "\n")
cat("Composite PDF:", out_pdf, "\n")
cat("Composite PNG:", out_png, "\n")
