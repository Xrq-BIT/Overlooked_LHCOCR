suppressPackageStartupMessages({
  library(readxl)
  library(readr)
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(ggplot2)
  library(scales)
  library(patchwork)
  library(svglite)
  library(rsvg)
})

future_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/未来情景/coal_plant_future_result2.xlsx"
top10_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图二经济损失/图二整体润色版素材/Fig2c_top10_cities.csv"
out_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图三退役与未来情景/图二Top10城市2020_2050损失减少轨迹"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

scenarios <- c("SSP126", "SSP245", "SSP370")
years_data <- c(2021, 2025, 2030, 2035, 2040, 2045, 2050)
years_plot <- c(2020, years_data)

scenario_labels <- c(
  SSP126 = "SSP1-2.6",
  SSP245 = "SSP2-4.5",
  SSP370 = "SSP3-7.0"
)

# Restrained but distinguishable colors; line types retain meaning in greyscale.
scenario_colors <- c(
  "SSP1-2.6" = "#3E718B",
  "SSP2-4.5" = "#719A94",
  "SSP3-7.0" = "#B17B63"
)
scenario_linetypes <- c(
  "SSP1-2.6" = "solid",
  "SSP2-4.5" = "longdash",
  "SSP3-7.0" = "dotted"
)

normalize_iso3 <- function(x) {
  x <- str_to_upper(str_trim(as.character(x)))
  ifelse(x %in% c("TWN", "TWM", "HKG", "MAC"), "CHN", x)
}

clean_city <- function(x) str_squish(as.character(x))

top10 <- read_csv(top10_path, show_col_types = FALSE) %>%
  transmute(
    city_rank = row_number(),
    city = clean_city(admin2),
    iso3 = normalize_iso3(iso3),
    city_label = paste0(city, ", ", iso3)
  )

if (nrow(top10) != 10L) stop("The Figure 2 city list must contain exactly 10 cities")

future_cols <- as.vector(outer(scenarios, years_data, paste, sep = "_"))
future_cols <- paste0("loss_", future_cols)
required_cols <- c(
  "gadm_admin2", "gadm_iso3", "All_loss_annual_mean_LSM_10km",
  "future_loss_analysis_included_2021", future_cols
)

raw <- read_excel(future_path)
missing_cols <- setdiff(required_cols, names(raw))
if (length(missing_cols) > 0) stop("Missing columns: ", paste(missing_cols, collapse = ", "))

plants <- raw %>%
  transmute(
    city = clean_city(gadm_admin2),
    iso3 = normalize_iso3(gadm_iso3),
    included = suppressWarnings(as.numeric(future_loss_analysis_included_2021)),
    baseline_loss_usd = suppressWarnings(as.numeric(All_loss_annual_mean_LSM_10km)),
    across(all_of(future_cols), ~ suppressWarnings(as.numeric(.x)))
  ) %>%
  filter(
    included == 1,
    !is.na(city), city != "",
    !is.na(iso3), iso3 != "",
    is.finite(baseline_loss_usd), baseline_loss_usd > 0
  ) %>%
  inner_join(top10 %>% select(city_rank, city, iso3, city_label), by = c("city", "iso3"))

matched <- plants %>% distinct(city_rank, city_label)
missing_cities <- anti_join(top10, matched, by = c("city_rank", "city_label"))
if (nrow(missing_cities) > 0) {
  message(
    "No eligible future-scenario plants; annotated as unavailable: ",
    paste(missing_cities$city_label, collapse = "; ")
  )
}

city_year <- plants %>%
  pivot_longer(
    cols = all_of(future_cols),
    names_to = c("scenario_code", "year"),
    names_pattern = "loss_(SSP[0-9]+)_([0-9]{4})",
    values_to = "future_loss_usd"
  ) %>%
  mutate(
    year = as.integer(year),
    future_loss_usd = pmin(pmax(future_loss_usd, 0), baseline_loss_usd),
    avoided_loss_usd = pmax(baseline_loss_usd - future_loss_usd, 0)
  ) %>%
  group_by(city_rank, city_label, scenario_code, year) %>%
  summarise(
    baseline_loss_usd = sum(baseline_loss_usd, na.rm = TRUE),
    avoided_loss_usd = sum(avoided_loss_usd, na.rm = TRUE),
    plant_count = n(),
    .groups = "drop"
  ) %>%
  mutate(
    scenario = unname(scenario_labels[scenario_code]),
    annual_loss_reduction_musd = avoided_loss_usd / 1e6
  )

year_zero <- crossing(
  city_rank = top10$city_rank,
  scenario_code = scenarios
) %>%
  left_join(top10 %>% select(city_rank, city_label), by = "city_rank") %>%
  mutate(
    year = 2020L,
    scenario = unname(scenario_labels[scenario_code]),
    annual_loss_reduction_musd = 0
  )

plot_df <- bind_rows(
  year_zero %>% select(city_rank, city_label, scenario_code, scenario, year, annual_loss_reduction_musd),
  city_year %>% select(city_rank, city_label, scenario_code, scenario, year, annual_loss_reduction_musd)
) %>%
  mutate(
    scenario = factor(scenario, levels = unname(scenario_labels)),
    city_label = factor(city_label, levels = top10$city_label)
  ) %>%
  arrange(city_rank, scenario, year)

write_csv(plot_df, file.path(out_dir, "top10_city_annual_loss_reduction_2020_2050.csv"))

base_theme <- theme_classic(base_size = 9.5, base_family = "sans") +
  theme(
    axis.line = element_line(color = "#4F4F4F", linewidth = 0.38),
    axis.ticks = element_line(color = "#5F5F5F", linewidth = 0.32),
    axis.text = element_text(color = "#424242", size = 8.2),
    axis.title = element_text(color = "#222222", size = 9.2),
    plot.title = element_text(face = "bold", size = 10.2, hjust = 0),
    legend.position = "bottom",
    legend.title = element_blank(),
    legend.text = element_text(size = 8),
    legend.key.width = unit(14, "mm"),
    plot.margin = margin(5, 7, 5, 6)
  )

make_city_plot <- function(city_rank_use, show_legend = TRUE) {
  dat <- plot_df %>% filter(city_rank == city_rank_use)
  city_title <- top10$city_label[top10$city_rank == city_rank_use]

  if (!any(dat$year > 2020)) {
    return(
      ggplot() +
        annotate(
          "text", x = 2035, y = 0.56,
          label = "Not included in\nfuture analysis",
          color = "#6F6F6F", size = 3.2, lineheight = 1.05
        ) +
        scale_x_continuous(
          breaks = c(2020, 2030, 2040, 2050),
          limits = c(2020, 2050),
          expand = expansion(mult = c(0.01, 0.025))
        ) +
        scale_y_continuous(
          breaks = c(0, 1), labels = c("0", "NA"), limits = c(0, 1),
          expand = expansion(mult = c(0, 0.08))
        ) +
        labs(
          title = city_title,
          x = "Year",
          y = "Annual loss reduction (M USD)"
        ) +
        base_theme +
        theme(legend.position = "none")
    )
  }

  ggplot(dat, aes(year, annual_loss_reduction_musd, color = scenario, linetype = scenario)) +
    geom_line(linewidth = 0.88, lineend = "round") +
    geom_point(size = 1.65, stroke = 0, alpha = 0.96) +
    scale_color_manual(values = scenario_colors, drop = FALSE) +
    scale_linetype_manual(values = scenario_linetypes, drop = FALSE) +
    scale_x_continuous(
      breaks = c(2020, 2030, 2040, 2050),
      limits = c(2020, 2050),
      expand = expansion(mult = c(0.01, 0.025))
    ) +
    scale_y_continuous(
      labels = label_number(big.mark = ",", accuracy = 0.1),
      limits = c(0, NA),
      expand = expansion(mult = c(0, 0.10))
    ) +
    labs(
      title = city_title,
      x = "Year",
      y = "Annual loss reduction (M USD)"
    ) +
    base_theme +
    theme(legend.position = if (show_legend) "bottom" else "none")
}

individual_plots <- lapply(top10$city_rank, make_city_plot, show_legend = TRUE)

for (i in seq_len(nrow(top10))) {
  rank_i <- top10$city_rank[i]
  city_stem <- str_replace_all(str_to_lower(top10$city_label[i]), "[^a-z0-9]+", "_") %>%
    str_replace_all("^_|_$", "")
  stem <- sprintf("%02d_%s_annual_loss_reduction_2020_2050", rank_i, city_stem)
  ggsave(file.path(out_dir, paste0(stem, ".svg")), individual_plots[[i]],
         width = 4.25, height = 3.05, device = svglite::svglite)
  rsvg_pdf(
    file.path(out_dir, paste0(stem, ".svg")),
    file.path(out_dir, paste0(stem, ".pdf"))
  )
}

combined_plots <- lapply(top10$city_rank, make_city_plot, show_legend = FALSE)
combined <- wrap_plots(combined_plots, ncol = 2, guides = "collect") &
  theme(legend.position = "bottom")

ggsave(
  file.path(out_dir, "top10_cities_annual_loss_reduction_2020_2050_combined.svg"),
  combined, width = 8.2, height = 11.4, device = svglite::svglite
)
rsvg_pdf(
  file.path(out_dir, "top10_cities_annual_loss_reduction_2020_2050_combined.svg"),
  file.path(out_dir, "top10_cities_annual_loss_reduction_2020_2050_combined.pdf")
)

coverage <- plants %>%
  count(city_rank, city_label, name = "eligible_plant_count") %>%
  right_join(top10 %>% select(city_rank, city_label), by = c("city_rank", "city_label")) %>%
  mutate(eligible_plant_count = replace_na(eligible_plant_count, 0L)) %>%
  arrange(city_rank)
write_csv(coverage, file.path(out_dir, "top10_city_future_analysis_coverage.csv"))

message(
  "Done\n",
  "- cities: ", nrow(top10), "\n",
  "- individual SVG/PDF pairs: 10\n",
  "- combined SVG/PDF: top10_cities_annual_loss_reduction_2020_2050_combined"
)
