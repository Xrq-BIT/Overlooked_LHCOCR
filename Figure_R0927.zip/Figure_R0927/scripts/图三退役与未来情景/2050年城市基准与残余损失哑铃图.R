suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(scales)
  library(svglite)
})

base_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图三退役与未来情景"
source_dir <- file.path(
  base_dir,
  "city_persistent_risk_quadrant_gadm_admin2_top10_each_nature_musd"
)
out_dir <- file.path(base_dir, "2050年城市基准与残余损失哑铃图")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

scenario_labels <- c(
  SSP126 = "SSP1-2.6",
  SSP245 = "SSP2-4.5",
  SSP370 = "SSP3-7.0"
)

scenario_files <- file.path(
  source_dir,
  paste0("city_persistent_risk_", names(scenario_labels), "_2050_all.csv")
)
if (!all(file.exists(scenario_files))) {
  stop("Missing city-level source files: ",
       paste(scenario_files[!file.exists(scenario_files)], collapse = ", "))
}

all_city <- bind_rows(lapply(seq_along(scenario_files), function(i) {
  read_csv(scenario_files[i], show_col_types = FALSE) |>
    mutate(scenario = names(scenario_labels)[i])
}))

# A common x limit keeps the three scenario panels quantitatively comparable.
global_max <- max(all_city$baseline_loss_musd, na.rm = TRUE)
x_limit <- global_max * 1.30

plot_one <- function(scenario_code, top_n = 12) {
  dat <- all_city |>
    filter(
      scenario == scenario_code,
      is.finite(baseline_loss_musd),
      is.finite(future_loss_musd),
      baseline_loss_musd > 0
    ) |>
    arrange(desc(future_loss_musd), desc(baseline_loss_musd)) |>
    slice_head(n = top_n) |>
    mutate(
      link_id = row_number(),
      link_label = sprintf("%02d", link_id),
      reduction_pct_label = percent(reduction_rate, accuracy = 1),
      city_label_text = paste0(link_label, "  ", city_label_plot),
      city_label = factor(city_label_text, levels = rev(city_label_text))
    )

  write_csv(
    dat |>
      transmute(
        link_id, link_label, city_raw, iso3_raw, iso3_final,
        city_label_plot, baseline_loss_musd, future_loss_musd,
        reduction_rate
      ),
    file.path(
      out_dir,
      paste0("selected_city_links_", scenario_code, "_2050.csv")
    )
  )

  ggplot(dat, aes(y = city_label)) +
    geom_segment(
      aes(x = future_loss_musd, xend = baseline_loss_musd, yend = city_label),
      linewidth = 1.15,
      colour = "#C3ADD2",
      lineend = "round"
    ) +
    geom_point(
      aes(x = baseline_loss_musd),
      shape = 21,
      size = 3.2,
      stroke = 0.8,
      fill = "white",
      colour = "#858D90"
    ) +
    geom_point(
      aes(x = future_loss_musd),
      shape = 21,
      size = 3.4,
      stroke = 0.55,
      fill = "#674784",
      colour = "white"
    ) +
    geom_text(
      aes(x = x_limit * 0.985, label = reduction_pct_label),
      hjust = 1,
      size = 3.0,
      colour = "#5D6467",
      family = "sans"
    ) +
    scale_x_continuous(
      trans = pseudo_log_trans(base = 10, sigma = 0.5),
      limits = c(0, x_limit),
      breaks = c(0, 1, 10, 100, 1000, 10000),
      labels = label_number(big.mark = ",", accuracy = 1),
      expand = expansion(mult = c(0.01, 0))
    ) +
    labs(
      x = "Annual loss (M USD)",
      y = NULL,
      caption = paste0(
        "Open: current | Filled: residual | Right: reduction | ",
        scenario_labels[[scenario_code]],
        " | 2050"
      )
    ) +
    theme_classic(base_family = "sans", base_size = 10.5) +
    theme(
      axis.line.y = element_blank(),
      axis.ticks.y = element_blank(),
      axis.ticks.x = element_line(colour = "#777D7F", linewidth = 0.35),
      axis.line.x = element_line(colour = "#777D7F", linewidth = 0.45),
      axis.text.y = element_text(colour = "#34383A", size = 8.5),
      axis.text.x = element_text(colour = "#4C5254", size = 8.5),
      axis.title.x = element_text(colour = "#34383A", margin = margin(t = 6)),
      panel.grid.major.y = element_line(colour = "#ECEEED", linewidth = 0.35),
      plot.caption = element_text(
        hjust = 0.5,
        face = "bold",
        size = 10.5,
        colour = "#303638",
        margin = margin(t = 8)
      ),
      plot.margin = margin(8, 8, 5, 6)
    )
}

for (scenario_code in names(scenario_labels)) {
  p <- plot_one(scenario_code)
  stem <- file.path(
    out_dir,
    paste0("city_current_residual_loss_", scenario_code, "_2050")
  )
  ggsave(paste0(stem, ".svg"), p, width = 8.8, height = 6.4, units = "in")
  ggsave(paste0(stem, ".pdf"), p, width = 8.8, height = 6.4, units = "in")
  ggsave(paste0(stem, ".png"), p, width = 8.8, height = 6.4,
         units = "in", dpi = 300, bg = "white")
}

cat("Saved paired current-residual city plots to:", out_dir, "\n")
