# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(scales)
  library(svglite)
  library(stringr)
  library(ggh4x)
})

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/未来情景/coal_plant_future_result2.xlsx"

out_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图三退役与未来情景/city_top20_mitigation_waterfall_2050"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

CITY_COL <- "gadm_admin2"
ISO3_COL <- "gadm_iso3"
BASE_LOSS_COL <- "All_loss_annual_mean_LSM_10km"
INCLUDE_COL <- "future_loss_analysis_included_2021"

SCENARIOS <- c("SSP126", "SSP245", "SSP370")
YEAR_USE <- 2050
TOP_N <- 20
DISPLAY_MAX_CHARS <- 18

OUT_CSV <- file.path(out_dir, "city_waterfall_step_all_2050.csv")
OUT_TOP_CSV <- file.path(out_dir, "city_waterfall_step_top20_2050.csv")
OUT_SVG <- file.path(out_dir, "city_waterfall_step_top20_2050.svg")
OUT_PDF <- file.path(out_dir, "city_waterfall_step_top20_2050.pdf")

# =========================
# 2) Read data
# =========================
df_raw <- read_excel(excel_path)

future_cols <- paste0("loss_", SCENARIOS, "_", YEAR_USE)
need_cols <- c(CITY_COL, ISO3_COL, BASE_LOSS_COL, INCLUDE_COL, future_cols)

if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

# =========================
# 3) Clean plant-level data
# =========================
df <- df_raw %>%
  transmute(
    city_raw = str_trim(as.character(.data[[CITY_COL]])),
    iso3_raw = str_to_upper(str_trim(as.character(.data[[ISO3_COL]]))),
    included = suppressWarnings(as.numeric(.data[[INCLUDE_COL]])),
    
    baseline_loss = suppressWarnings(as.numeric(.data[[BASE_LOSS_COL]])),
    loss_SSP126 = suppressWarnings(as.numeric(.data[[paste0("loss_SSP126_", YEAR_USE)]])),
    loss_SSP245 = suppressWarnings(as.numeric(.data[[paste0("loss_SSP245_", YEAR_USE)]])),
    loss_SSP370 = suppressWarnings(as.numeric(.data[[paste0("loss_SSP370_", YEAR_USE)]]))
  ) %>%
  mutate(
    city_raw = ifelse(
      is.na(city_raw) |
        city_raw == "" |
        str_to_lower(city_raw) %in% c("unknown", "na", "n/a", "none", "null"),
      NA_character_,
      city_raw
    ),
    
    iso3_raw = ifelse(
      is.na(iso3_raw) |
        iso3_raw == "" |
        str_to_lower(iso3_raw) %in% c("unknown", "na", "n/a", "none", "null"),
      NA_character_,
      iso3_raw
    ),
    
    iso3_raw = ifelse(
      iso3_raw %in% c("TWN", "TWM", "HKG", "MAC"),
      "CHN",
      iso3_raw
    )
  ) %>%
  filter(
    included == 1,
    !is.na(city_raw),
    !is.na(iso3_raw),
    !is.na(baseline_loss),
    baseline_loss > 0,
    if_all(starts_with("loss_SSP"), ~ !is.na(.x))
  )

# =========================
# 4) City-level aggregation
# =========================
city_df <- df %>%
  group_by(city_raw, iso3_raw) %>%
  summarise(
    plant_count = n(),
    
    Current = sum(baseline_loss, na.rm = TRUE),
    loss_SSP126 = sum(loss_SSP126, na.rm = TRUE),
    loss_SSP245 = sum(loss_SSP245, na.rm = TRUE),
    loss_SSP370 = sum(loss_SSP370, na.rm = TRUE),
    
    .groups = "drop"
  ) %>%
  mutate(
    loss_SSP126 = pmin(loss_SSP126, Current),
    loss_SSP245 = pmin(loss_SSP245, Current),
    loss_SSP370 = pmin(loss_SSP370, Current),
    
    mitigation_SSP126 = pmax(Current - loss_SSP126, 0),
    mitigation_SSP245 = pmax(Current - loss_SSP245, 0),
    mitigation_SSP370 = pmax(Current - loss_SSP370, 0),
    
    Current_M = Current / 1e6,
    loss_SSP126_M = loss_SSP126 / 1e6,
    loss_SSP245_M = loss_SSP245 / 1e6,
    loss_SSP370_M = loss_SSP370 / 1e6,
    
    mitigation_SSP126_M = mitigation_SSP126 / 1e6,
    mitigation_SSP245_M = mitigation_SSP245 / 1e6,
    mitigation_SSP370_M = mitigation_SSP370 / 1e6,
    
    mean_mitigation_M = rowMeans(
      cbind(
        mitigation_SSP126_M,
        mitigation_SSP245_M,
        mitigation_SSP370_M
      ),
      na.rm = TRUE
    ),
    
    city_name_short = str_trunc(
      city_raw,
      width = DISPLAY_MAX_CHARS,
      side = "right"
    ),
    
    city_label_plot = paste0(city_name_short, "_", iso3_raw)
  ) %>%
  arrange(desc(mean_mitigation_M)) %>%
  mutate(rank_mitigation = row_number())

write.csv(city_df, OUT_CSV, row.names = FALSE)

# =========================
# 5) Select top cities
# =========================
top_city <- city_df %>%
  filter(mean_mitigation_M > 0) %>%
  slice_head(n = TOP_N) %>%
  mutate(
    panel_id = row_number(),
    panel_label = paste0(
      letters[panel_id],
      ". ",
      city_label_plot
    )
  )

write.csv(top_city, OUT_TOP_CSV, row.names = FALSE)

# =========================
# 6) Build true waterfall / bridge data
# =========================
stage_levels <- c("Current", "SSP126", "SSP245", "SSP370")

wide_for_step <- top_city %>%
  transmute(
    panel_label,
    city_label_plot,
    plant_count,
    Current = Current_M,
    SSP126 = loss_SSP126_M,
    SSP245 = loss_SSP245_M,
    SSP370 = loss_SSP370_M
  )

plot_df <- wide_for_step %>%
  rowwise() %>%
  do({
    d <- .
    
    end_value <- c(
      Current = d$Current,
      SSP126 = d$SSP126,
      SSP245 = d$SSP245,
      SSP370 = d$SSP370
    )
    
    start_value <- c(
      Current = 0,
      SSP126 = d$Current,
      SSP245 = d$SSP126,
      SSP370 = d$SSP245
    )
    
    data.frame(
      panel_label = d$panel_label,
      city_label_plot = d$city_label_plot,
      plant_count = d$plant_count,
      stage = stage_levels,
      x_id = seq_along(stage_levels),
      start_value = as.numeric(start_value[stage_levels]),
      end_value = as.numeric(end_value[stage_levels])
    )
  }) %>%
  ungroup() %>%
  mutate(
    ymin = pmin(start_value, end_value),
    ymax = pmax(start_value, end_value),
    
    direction = case_when(
      stage == "Current" ~ "Current",
      end_value < start_value ~ "Residual reduction",
      end_value > start_value ~ "Residual increase",
      TRUE ~ "No change"
    ),
    
    stage = factor(stage, levels = stage_levels)
  )

# 每一步最终水平的黑色短横线
level_line_df <- plot_df %>%
  mutate(
    x = x_id - 0.36,
    xend = x_id + 0.36,
    y = end_value,
    yend = end_value
  )

# 相邻步骤之间的黑色连接线
connector_df <- plot_df %>%
  arrange(panel_label, x_id) %>%
  group_by(panel_label) %>%
  mutate(
    x = x_id + 0.36,
    xend = lead(x_id) - 0.36,
    y = end_value,
    yend = end_value
  ) %>%
  filter(!is.na(xend)) %>%
  ungroup()

# =========================
# 7) Plot
# =========================
fill_pal <- c(
  "Current" = "#9CDCF4",
  "Residual reduction" = "#72C6AD",
  "Residual increase" = "#F4A582",
  "No change" = "#CFCFCF"
)

p <- ggplot(plot_df) +
  
  geom_rect(
    aes(
      xmin = x_id - 0.32,
      xmax = x_id + 0.32,
      ymin = ymin,
      ymax = ymax,
      fill = direction
    ),
    color = NA,
    alpha = 0.96
  ) +
  
  geom_segment(
    data = level_line_df,
    aes(
      x = x,
      xend = xend,
      y = y,
      yend = yend
    ),
    inherit.aes = FALSE,
    color = "black",
    linewidth = 0.55
  ) +
  
  geom_segment(
    data = connector_df,
    aes(
      x = x,
      xend = xend,
      y = y,
      yend = yend
    ),
    inherit.aes = FALSE,
    color = "black",
    linewidth = 0.55
  ) +
  
  ggh4x::facet_wrap2(
    ~ panel_label,
    ncol = 5,
    scales = "free_y",
    axes = "x"
  ) +
  
  scale_x_continuous(
    breaks = seq_along(stage_levels),
    labels = stage_levels,
    expand = expansion(mult = c(0.08, 0.08))
  ) +
  
  scale_y_continuous(
    labels = label_number(big.mark = ",", accuracy = 1),
    expand = expansion(mult = c(0, 0.10))
  ) +
  
  scale_fill_manual(
    values = fill_pal,
    breaks = c(
      "Current",
      "Residual reduction",
      "Residual increase",
      "No change"
    ),
    labels = c(
      "Current",
      "Residual reduction",
      "Residual increase",
      "No change"
    ),
    name = NULL
  ) +
  
  labs(
    x = NULL,
    y = "Annual economic loss (million USD)"
  ) +
  
  theme_classic(base_size = 12) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_blank(),
    
    axis.line = element_line(
      color = "black",
      linewidth = 0.45
    ),
    
    axis.ticks = element_line(
      color = "black",
      linewidth = 0.35
    ),
    
    axis.ticks.length = unit(2, "mm"),
    
    strip.background = element_blank(),
    strip.text = element_text(
      size = 10.5,
      face = "bold",
      color = "black",
      margin = margin(b = 4)
    ),
    
    axis.text.x = element_text(
      size = 9,
      color = "black",
      angle = 90,
      hjust = 1,
      vjust = 0.5
    ),
    
    axis.text.y = element_text(
      size = 8.5,
      color = "black"
    ),
    
    axis.title.y = element_text(
      size = 11.5,
      color = "black"
    ),
    
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.text = element_text(size = 9.3),
    legend.key.width = unit(0.85, "cm"),
    legend.key.height = unit(0.35, "cm"),
    
    plot.margin = margin(6, 8, 6, 6)
  )

# =========================
# 8) Export
# =========================
ggsave(
  OUT_SVG,
  p,
  width = 12,
  height = 9.2,
  device = svglite::svglite
)

ggsave(
  OUT_PDF,
  p,
  width = 12,
  height = 9.2,
  device = grDevices::pdf
)

message(
  "Done!\n",
  "- ", OUT_CSV, "\n",
  "- ", OUT_TOP_CSV, "\n",
  "- ", OUT_SVG, "\n",
  "- ", OUT_PDF
)
