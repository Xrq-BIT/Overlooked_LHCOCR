# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(sf)
  library(ggplot2)
  library(rnaturalearth)
  library(scales)
  library(cowplot)
  library(svglite)
  library(grid)
})

sf::sf_use_s2(FALSE)

# =========================
# 1) File paths
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/未来情景/coal_plant_future_result.xlsx"
gpkg_path  <- "/Users/xuruiqing/Desktop/文章试验整体流程/data/GHS_UCDB_GLOBE_R2024A_V1_1/GHS_UCDB_GLOBE_R2024A.gpkg"

layer_name <- "GHS_UCDB_THEME_CLIMATE_GLOBE_R2024A"

# =========================
# 2) Config
# =========================
LON_COL  <- "Longitude"
LAT_COL  <- "Latitude"
BASE_COL <- "delt_warm_min"

SCENARIO <- "SSP245"   # 改这里：SSP126 / SSP245 / SSP370
YEAR_USE <- 2025       # 改这里：2021, 2025, ..., 2100

FUTURE_COL <- paste0("dT_", SCENARIO, "_", YEAR_USE)

# GHS-UCDB 城市ID字段
CITY_ID_COL <- "ID_UC_G0"

# =========================
# 3) Output folder
# =========================
out_dir <- paste0("map_", SCENARIO, "_", YEAR_USE)

if (!dir.exists(out_dir)) {
  dir.create(out_dir)
}

prefix <- file.path(
  out_dir,
  paste0("city_centroid_", SCENARIO, "_", YEAR_USE, "_coolingdelt")
)

OUT_MAP_SVG      <- paste0(prefix, "_map.svg")
OUT_MAP_PDF      <- paste0(prefix, "_map.pdf")
OUT_LEG_SVG      <- paste0(prefix, "_legend.svg")
OUT_LEG_PDF      <- paste0(prefix, "_legend.pdf")
OUT_FINAL_SVG    <- paste0(prefix, "_withLegend.svg")
OUT_FINAL_PDF    <- paste0(prefix, "_withLegend.pdf")
OUT_SIZE_LEG_SVG <- paste0(prefix, "_size_legend.svg")
OUT_SIZE_LEG_PDF <- paste0(prefix, "_size_legend.pdf")

# =========================
# 4) Read plant excel
# =========================
df_raw <- read_excel(excel_path)

need_cols <- c(LON_COL, LAT_COL, BASE_COL, FUTURE_COL)
if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

df <- df_raw %>%
  mutate(
    Longitude = as.numeric(.data[[LON_COL]]),
    Latitude  = as.numeric(.data[[LAT_COL]]),
    dt_base   = as.numeric(.data[[BASE_COL]]),
    dt_future = as.numeric(.data[[FUTURE_COL]])
  ) %>%
  filter(!is.na(Longitude), !is.na(Latitude), !is.na(dt_base), !is.na(dt_future)) %>%
  mutate(
    plot_val = dt_base - dt_future   # 关键：改成降温
  ) %>%
  filter(!is.na(plot_val))

plants_sf <- st_as_sf(
  df,
  coords = c("Longitude", "Latitude"),
  crs = 4326,
  remove = FALSE
)

# =========================
# 5) Read city polygons
# =========================
cities <- st_read(gpkg_path, layer = layer_name, quiet = TRUE)

cat("当前图层名：", layer_name, "\n")
print(names(cities))
print(st_crs(cities))

names(cities) <- sub("^X\\.", "", names(cities))

if (!(CITY_ID_COL %in% names(cities))) {
  stop(paste0("城市图层中不存在字段：", CITY_ID_COL))
}

geom_col <- attr(cities, "sf_column")

# =========================
# 6) CRS align
# =========================
plants_sf_proj <- st_transform(plants_sf, st_crs(cities))

# =========================
# 7) Spatial join: plant -> city
# =========================
plants_joined <- st_join(
  plants_sf_proj,
  cities[, c(CITY_ID_COL, geom_col)],
  join = st_within,
  left = FALSE
)

cat("成功匹配到城市的电厂数：", nrow(plants_joined), "\n")

# =========================
# 8) Aggregate to city level
# =========================
city_stat <- plants_joined %>%
  st_drop_geometry() %>%
  group_by(.data[[CITY_ID_COL]]) %>%
  summarise(
    mean_cooling = mean(plot_val, na.rm = TRUE),
    plant_count  = n(),
    .groups = "drop"
  )

cities_stat <- cities %>%
  left_join(city_stat, by = CITY_ID_COL) %>%
  filter(!is.na(mean_cooling))

cat("有电厂且成功聚合的城市数：", nrow(cities_stat), "\n")

# 城市质心点
city_pts <- st_point_on_surface(cities_stat)
city_pts_wgs84 <- st_transform(city_pts, 4326)

# 世界底图
world <- ne_countries(scale = "medium", returnclass = "sf")

# =========================
# 9) Color scale
# =========================
# 降温一般为正值；若有极少负值，截到0
city_pts_wgs84$mean_cooling <- pmax(city_pts_wgs84$mean_cooling, 0)

q95 <- as.numeric(quantile(city_pts_wgs84$mean_cooling, 0.95, na.rm = TRUE))
upper_cap <- max(q95, 0.02)
limits <- c(0, upper_cap)

cols <- c("#EEF5FB", "#CFE3F3", "#9ECAE1", "#4292C6", "#08519C")

anchors <- c(
  0,
  upper_cap * 0.10,
  upper_cap * 0.30,
  upper_cap * 0.60,
  upper_cap * 1.00
)

vals <- rescale(anchors, to = c(0, 1), from = limits)

if (upper_cap <= 0.10) {
  brks <- seq(0, upper_cap, by = 0.02)
} else if (upper_cap <= 0.20) {
  brks <- seq(0, upper_cap, by = 0.05)
} else {
  brks <- pretty(c(0, upper_cap), n = 5)
}

# =========================
# 10) Main map (NO legend)
# =========================
p_map <- ggplot() +
  geom_sf(data = world, fill = "grey88", color = "grey70", linewidth = 0.25) +
  geom_sf(
    data = city_pts_wgs84,
    aes(color = mean_cooling, size = plant_count),
    alpha = 0.95
  ) +
  scale_color_gradientn(
    colours = cols,
    values  = vals,
    limits  = limits,
    oob     = scales::squish,
    breaks  = brks,
    labels  = label_number(accuracy = 0.01),
    name    = NULL,
    guide   = "none"
  ) +
  scale_size_continuous(
    range = c(1.0, 3.8),
    breaks = c(1, 3, 5, 10, 20),
    name = NULL,
    guide = "none"
  ) +
  coord_sf(expand = FALSE, xlim = c(-150, 150), ylim = c(-60, 80)) +
  scale_x_continuous(
    breaks = seq(-150, 150, by = 60),
    labels = function(x) paste0(ifelse(x == 0, "0", abs(x)), "°",
                                ifelse(x < 0, "W", ifelse(x > 0, "E", "")))
  ) +
  scale_y_continuous(
    breaks = seq(-30, 60, by = 30),
    labels = function(y) paste0(ifelse(y == 0, "0", abs(y)), "°",
                                ifelse(y < 0, "S", ifelse(y > 0, "N", "")))
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.background  = element_rect(fill = "white", color = NA),
    panel.grid.major  = element_blank(),
    panel.grid.minor  = element_blank(),
    axis.title        = element_blank(),
    axis.text         = element_text(color = "grey25", size = 9),
    axis.ticks        = element_line(color = "grey60", linewidth = 0.3),
    axis.ticks.length = unit(2.0, "mm"),
    panel.border      = element_rect(color = "grey40", fill = NA, linewidth = 0.6),
    plot.margin       = margin(5, 10, 5, 10)
  )

ggsave(OUT_MAP_SVG, p_map, width = 12, height = 5.2, device = svglite::svglite)
ggsave(OUT_MAP_PDF, p_map, width = 12, height = 5.2)

# =========================
# 11) Color legend
# =========================
LEG_TITLE_COLOR <- paste0("Cooling (°C)\n", SCENARIO, " ", YEAR_USE)
LEG_TITLE_SIZE  <- "Plant count"

p_leg_color_src <- ggplot() +
  geom_sf(data = world, fill = "grey88", color = "grey70", linewidth = 0.25) +
  geom_sf(
    data = city_pts_wgs84,
    aes(color = mean_cooling),
    size = 2.5,
    alpha = 0.95
  ) +
  scale_color_gradientn(
    colours = cols,
    values  = vals,
    limits  = limits,
    oob     = scales::squish,
    breaks  = brks,
    labels  = label_number(accuracy = 0.01),
    name    = LEG_TITLE_COLOR,
    guide   = guide_colorbar(
      barheight = unit(50, "mm"),
      barwidth  = unit(6, "mm"),
      ticks.colour = "grey30",
      frame.colour = "grey30"
    )
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position  = "left",
    legend.title     = element_text(size = 10),
    legend.text      = element_text(size = 9)
  )

leg_color <- cowplot::get_legend(p_leg_color_src)

ggsave(OUT_LEG_SVG, leg_color, width = 1.8, height = 2.8, device = svglite::svglite)
ggsave(OUT_LEG_PDF, leg_color, width = 1.8, height = 2.8)

# =========================
# 12) Size legend
# =========================
size_df <- data.frame(
  x = 1:5,
  y = 1,
  plant_count = c(1, 3, 5, 10, 20)
)

p_leg_size_src <- ggplot(size_df, aes(x = x, y = y, size = plant_count)) +
  geom_point(color = "grey20", alpha = 0.95) +
  scale_size_continuous(
    range = c(1.0, 6.5),
    breaks = c(1, 3, 5, 10, 20),
    name = LEG_TITLE_SIZE
  ) +
  theme_void(base_size = 12) +
  theme(
    legend.position = "left",
    legend.title    = element_text(size = 10),
    legend.text     = element_text(size = 9)
  )

leg_size <- cowplot::get_legend(p_leg_size_src)

ggsave(OUT_SIZE_LEG_SVG, leg_size, width = 1.6, height = 2.0, device = svglite::svglite)
ggsave(OUT_SIZE_LEG_PDF, leg_size, width = 1.6, height = 2.0)

# =========================
# 13) COMBINE map + color legend
# =========================
LEG_X <- 0.08
LEG_Y <- 0.09
LEG_W <- 0.12
LEG_H <- 0.42

p_final <- cowplot::ggdraw() +
  cowplot::draw_plot(p_map, x = 0, y = 0, width = 1, height = 1) +
  cowplot::draw_plot(
    leg_color,
    x = LEG_X, y = LEG_Y,
    width = LEG_W, height = LEG_H
  )

ggsave(
  OUT_FINAL_SVG,
  p_final,
  width = 12,
  height = 5.2,
  device = svglite::svglite
)
ggsave(
  OUT_FINAL_PDF,
  p_final,
  width = 12,
  height = 5.2
)

message(
  "Done!\n- ", OUT_MAP_SVG,
  "\n- ", OUT_SIZE_LEG_SVG,
  "\n- ", OUT_LEG_SVG,
  "\n- ", OUT_FINAL_SVG
)