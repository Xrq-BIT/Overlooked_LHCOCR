suppressPackageStartupMessages({
  library(xml2)
  library(rsvg)
})

root <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图三退役与未来情景"
map_dir <- file.path(root, "2050年GADM城市年度损失减少世界地图")
profile_dir <- file.path(root, "2050年GADM城市年度损失减少纬度分布")
donut_dir <- file.path(root, "2050年三情景避免损失环形图")
quadrant_dir <- file.path(root, "city_loss_mitigation_quadrant_remaining_top10_comparison")
out_dir <- file.path(root, "图三两情景地图与四象限组图_图二协调配色")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

paths <- list(
  map126 = file.path(map_dir, "gadm_admin2_annual_loss_reduction_SSP126_2050_fig2_palette.svg"),
  map370 = file.path(map_dir, "gadm_admin2_annual_loss_reduction_SSP370_2050_fig2_palette.svg"),
  profile126 = file.path(profile_dir, "annual_loss_reduction_latitudinal_profile_SSP126_2050.svg"),
  profile370 = file.path(profile_dir, "annual_loss_reduction_latitudinal_profile_SSP370_2050.svg"),
  donut126 = file.path(donut_dir, "avoided_loss_donut_SSP126_2050_fig2_palette.svg"),
  donut370 = file.path(donut_dir, "avoided_loss_donut_SSP370_2050_fig2_palette.svg"),
  quadrant126 = file.path(
    quadrant_dir,
    "city_quadrant_percentile_strict_remaining_loss_top10_each_SSP126_2050_scatter.svg"
  ),
  quadrant370 = file.path(
    quadrant_dir,
    "city_quadrant_percentile_strict_remaining_loss_top10_each_SSP370_2050_scatter.svg"
  )
)

missing_paths <- unlist(paths)[!file.exists(unlist(paths))]
if (length(missing_paths) > 0) {
  stop("Missing input SVG files:\n", paste(missing_paths, collapse = "\n"))
}

read_svg_inner <- function(path) {
  doc <- read_xml(path)
  root_node <- xml_root(doc)
  list(
    view_box = xml_attr(root_node, "viewBox"),
    content = paste(as.character(xml_children(root_node)), collapse = "\n")
  )
}

embed_svg <- function(path, x, y, width, height) {
  svg <- read_svg_inner(path)
  sprintf(
    '<svg x="%.3f" y="%.3f" width="%.3f" height="%.3f" viewBox="%s" preserveAspectRatio="xMidYMid meet">%s</svg>',
    x, y, width, height, svg$view_box, svg$content
  )
}

panel_letter <- function(letter, x, y) {
  sprintf(
    '<text x="%.3f" y="%.3f" font-family="Arial, Helvetica, sans-serif" font-size="25" font-weight="700" fill="#111111">%s</text>',
    x, y, letter
  )
}

svg_open <- function(canvas_w, canvas_h) {
  c(
    sprintf(
      '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="%s" height="%s" viewBox="0 0 %s %s">',
      canvas_w, canvas_h, canvas_w, canvas_h
    ),
    '<rect x="0" y="0" width="100%" height="100%" fill="white"/>'
  )
}

save_composite <- function(parts, stem, canvas_w, canvas_h) {
  svg_path <- paste0(stem, ".svg")
  pdf_path <- paste0(stem, ".pdf")
  png_path <- paste0(stem, ".png")
  writeLines(c(parts, "</svg>"), svg_path, useBytes = TRUE)
  invisible(read_xml(svg_path))
  rsvg_pdf(svg_path, pdf_path, width = canvas_w, height = canvas_h)
  rsvg_png(svg_path, png_path, width = canvas_w, height = canvas_h)
  message("Saved: ", stem)
}

# Figure 1 top-row reference geometry.
canvas_w <- 1200
outer_x <- 24
outer_w <- 1152
row_h <- 400.50
row_gap <- 46
map_slot_w <- outer_w * 4.55 / (4.55 + 1.15)
profile_slot_w <- outer_w - map_slot_w

map_slot_x <- outer_x
profile_slot_x <- outer_x + map_slot_w
letter_left_x <- 65
letter_profile_x <- 946
letter_y_offset <- 17
quadrant_letter_y_offset <- 5

# Native source geometry; all scaling below is proportional.
map_source_w <- 864
map_source_h <- 374.4
profile_source_w <- 198
profile_source_h <- 331.2
quadrant_source_w <- 748.8
quadrant_source_h <- 460.8
donut_source_w <- 216
donut_source_h <- 162

map_scale <- min(map_slot_w / map_source_w, row_h / map_source_h)
map_draw_w <- map_source_w * map_scale
map_draw_h <- map_source_h * map_scale
map_draw_x <- map_slot_x + (map_slot_w - map_draw_w) / 2
map_draw_y <- function(row_y) row_y + (row_h - map_draw_h) / 2

profile_scale <- min(profile_slot_w / profile_source_w, row_h / profile_source_h)
profile_draw_w <- profile_source_w * profile_scale
profile_draw_h <- profile_source_h * profile_scale
profile_draw_x <- profile_slot_x + (profile_slot_w - profile_draw_w) / 2
profile_draw_y <- function(row_y) row_y + (row_h - profile_draw_h) / 2

map_panel_left_source <- 93.21
profile_panel_right_source <- 184.06
quadrant_panel_left_source <- 50.87
quadrant_panel_right_source <- 741.83
quadrant_panel_width_source <- quadrant_panel_right_source - quadrant_panel_left_source

target_panel_left <- map_draw_x + map_panel_left_source * map_scale
target_panel_right <- profile_draw_x + profile_panel_right_source * profile_scale
target_panel_width <- target_panel_right - target_panel_left

quadrant_full_scale <- target_panel_width / quadrant_panel_width_source
quadrant_full_w <- quadrant_source_w * quadrant_full_scale
quadrant_full_h <- quadrant_source_h * quadrant_full_scale
quadrant_full_x <- target_panel_left - quadrant_panel_left_source * quadrant_full_scale

donut_draw_w <- map_draw_w * 0.25
donut_draw_h <- donut_draw_w * donut_source_h / donut_source_w
donut_x <- map_draw_x + map_draw_w * 0.60
donut_y <- function(row_y) map_draw_y(row_y) + map_draw_h * 0.50

map_profile_panels <- function(map_path, profile_path, donut_path, row_y, map_letter, profile_letter) {
  c(
    embed_svg(map_path, map_draw_x, map_draw_y(row_y), map_draw_w, map_draw_h),
    embed_svg(profile_path, profile_draw_x, profile_draw_y(row_y), profile_draw_w, profile_draw_h),
    embed_svg(donut_path, donut_x, donut_y(row_y), donut_draw_w, donut_draw_h),
    panel_letter(map_letter, letter_left_x, row_y + letter_y_offset),
    panel_letter(profile_letter, letter_profile_x, row_y + letter_y_offset)
  )
}

# Variant 1: SSP1-2.6 quadrant between the two map-profile rows.
v1_row1_y <- 18
v1_row2_y <- v1_row1_y + row_h + row_gap
v1_row3_y <- v1_row2_y + quadrant_full_h + row_gap
v1_row4_y <- v1_row3_y + row_h + row_gap
v1_canvas_h <- v1_row4_y + quadrant_full_h + 18

v1_parts <- c(
  svg_open(canvas_w, v1_canvas_h),
  map_profile_panels(paths$map126, paths$profile126, paths$donut126, v1_row1_y, "a", "b"),
  embed_svg(paths$quadrant126, quadrant_full_x, v1_row2_y, quadrant_full_w, quadrant_full_h),
  panel_letter("c", letter_left_x, v1_row2_y + quadrant_letter_y_offset),
  map_profile_panels(paths$map370, paths$profile370, paths$donut370, v1_row3_y, "d", "e"),
  embed_svg(paths$quadrant370, quadrant_full_x, v1_row4_y, quadrant_full_w, quadrant_full_h),
  panel_letter("f", letter_left_x, v1_row4_y + quadrant_letter_y_offset)
)

v1_stem <- file.path(
  out_dir,
  "Figure3_2050_SSP126_quadrant_between_maps_SSP370_quadrant_proportional_strict_remaining_loss_top10"
)
save_composite(v1_parts, v1_stem, canvas_w, v1_canvas_h)

# Variant 2: two proportional quadrants side by side below the map-profile rows.
side_panel_gap <- 90
quadrant_side_scale <- (target_panel_width - side_panel_gap) /
  (2 * quadrant_panel_width_source)
quadrant_side_w <- quadrant_source_w * quadrant_side_scale
quadrant_side_h <- quadrant_source_h * quadrant_side_scale

left_panel_left <- target_panel_left
right_panel_left <- target_panel_left +
  quadrant_panel_width_source * quadrant_side_scale + side_panel_gap
quadrant_left_x <- left_panel_left - quadrant_panel_left_source * quadrant_side_scale
quadrant_right_x <- right_panel_left - quadrant_panel_left_source * quadrant_side_scale

v2_row1_y <- 18
v2_row2_y <- v2_row1_y + row_h + row_gap
v2_row3_y <- v2_row2_y + row_h + row_gap
v2_canvas_h <- v2_row3_y + quadrant_side_h + 18

right_letter_offset <- target_panel_left - letter_left_x
right_letter_x <- right_panel_left - right_letter_offset

v2_parts <- c(
  svg_open(canvas_w, v2_canvas_h),
  map_profile_panels(paths$map126, paths$profile126, paths$donut126, v2_row1_y, "a", "b"),
  map_profile_panels(paths$map370, paths$profile370, paths$donut370, v2_row2_y, "c", "d"),
  embed_svg(paths$quadrant126, quadrant_left_x, v2_row3_y, quadrant_side_w, quadrant_side_h),
  panel_letter("e", letter_left_x, v2_row3_y + letter_y_offset),
  embed_svg(paths$quadrant370, quadrant_right_x, v2_row3_y, quadrant_side_w, quadrant_side_h),
  panel_letter("f", right_letter_x, v2_row3_y + letter_y_offset)
)

v2_stem <- file.path(
  out_dir,
  "Figure3_2050_SSP126_SSP370_maps_lat_profiles_quadrants_side_by_side_proportional_strict_remaining_loss_top10"
)
save_composite(v2_parts, v2_stem, canvas_w, v2_canvas_h)
