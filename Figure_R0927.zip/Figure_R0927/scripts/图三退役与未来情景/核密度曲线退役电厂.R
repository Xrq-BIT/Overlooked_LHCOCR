# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(svglite)
})

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/48/414retired_plants_with_delta.xlsx"   # 改成你的Excel路径
sheet_name <- 1                                           # 如果有多个sheet可改
value_col  <- "delt_premax_minus_postmean"                                      # 要画分布的列
type_col   <- "Type"                                      # 类型列名
type_keep  <- "coal"                                      # 如不筛选可设为 NULL

out_svg <- "density_dlet_coal.svg"

# 坐标轴标题
x_lab <- "Cooling ΔT"
y_lab <- "Density"

# =========================
# 2) Read data
# =========================
df <- read_excel(excel_path, sheet = sheet_name)

# =========================
# 3) Optional filter
# =========================
if (!is.null(type_keep)) {
  df <- df %>%
    filter(.data[[type_col]] == type_keep)
}

# 只保留目标列，并转成数值
plot_df <- df %>%
  mutate(value = as.numeric(.data[[value_col]])) %>%
  filter(!is.na(value))

# =========================
# 4) Statistics
# =========================
mean_val <- mean(plot_df$value, na.rm = TRUE)
n_val    <- nrow(plot_df)

cat("样本量 n =", n_val, "\n")
cat("均值 =", mean_val, "\n")

# =========================
# 5) Plot
# =========================
p <- ggplot(plot_df, aes(x = value)) +
  geom_density(
    fill = "#8FB3C9",
    color = "black",
    linewidth = 1.2,
    adjust = 1
  ) +
  geom_vline(
    xintercept = 0,
    linetype = "dashed",
    color = "black",
    linewidth = 1.2
  ) +
  geom_vline(
    xintercept = mean_val,
    color = "red",
    linewidth = 1.2
  ) +
  geom_rug(
    sides = "b",
    alpha = 0.35,
    linewidth = 0.4
  ) +
  labs(
    x = "Cooling ΔT",
    y = "Density"
  ) +
  
  # ===== 横轴刻度（关键调整）=====
scale_x_continuous(
  breaks = seq(0, 0.3, by = 0.05),   # 调整刻度间距
  limits = c(-0.05, 0.3)               # 控制范围更像图一
) +

 
  # ===== 加完整边框 =====
theme_classic(base_size = 18) +
  theme(
    axis.line = element_line(color = "black", linewidth = 0.9),
    panel.border = element_rect(
      color = "black",
      fill = NA,
      linewidth = 1
    ),
    axis.ticks = element_line(color = "black"),
    axis.text = element_text(color = "black"),
    axis.title = element_text(color = "black")
  )

print(p)

# =========================
# 6) Export SVG
# =========================
svglite(out_svg, width = 7.8, height = 5.0, bg = "white")
print(p)
dev.off()