suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(readr)
  library(scales)
  library(stringr)
  library(svglite)
})

base_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图三退役与未来情景"
source_dir <- file.path(
  base_dir,
  "city_persistent_risk_quadrant_gadm_admin2_top10_each_nature_musd"
)
out_dir <- file.path(base_dir, "2050年城市减损与持续风险双榜图")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

scenario_labels <- c(
  SSP126 = "SSP1-2.6",
  SSP245 = "SSP2-4.5",
  SSP370 = "SSP3-7.0"
)

source_files <- file.path(
  source_dir,
  paste0("city_persistent_risk_", names(scenario_labels), "_2050_all.csv")
)
if (!all(file.exists(source_files))) {
  stop("Missing city-level source files: ",
       paste(source_files[!file.exists(source_files)], collapse = ", "))
}

all_city <- bind_rows(lapply(seq_along(source_files), function(i) {
  read_csv(source_files[i], show_col_types = FALSE) |>
    mutate(scenario = names(scenario_labels)[i])
}))

clean_city_label <- function(x) {
  x |>
    str_replace_all("_", ", ") |>
    str_replace("Mumbai Suburban", "Mumbai Suburb.") |>
    str_replace("Visakhapatnam", "Visakhapat.")
}

select_dual_rank <- function(dat, top_n = 5) {
  best <- dat |>
    filter(is.finite(mitigation_loss_musd), mitigation_loss_musd > 0) |>
    arrange(desc(mitigation_loss_musd), desc(baseline_loss_musd)) |>
    slice_head(n = top_n) |>
    transmute(
      section = "Largest avoided losses",
      city_label = clean_city_label(city_label_plot),
      value = mitigation_loss_musd,
      reduction_rate,
      value_label = paste0(
        label_number(accuracy = 0.1, big.mark = ",")(value),
        "  (", percent(reduction_rate, accuracy = 1), " reduced)"
      )
    )

  priority <- dat |>
    filter(is.finite(future_loss_musd), future_loss_musd > 0) |>
    arrange(desc(future_loss_musd), reduction_rate) |>
    slice_head(n = top_n) |>
    transmute(
      section = "Highest remaining losses",
      city_label = clean_city_label(city_label_plot),
      value = future_loss_musd,
      reduction_rate,
      value_label = paste0(
        label_number(accuracy = 0.1, big.mark = ",")(value),
        "  (", percent(reduction_rate, accuracy = 1), " reduced)"
      )
    )

  bind_rows(best, priority) |>
    group_by(section) |>
    arrange(value, .by_group = TRUE) |>
    mutate(
      row_id = row_number(),
      y = if_else(
        section == "Largest avoided losses",
        row_id + top_n + 1.8,
        row_id
      ),
      label_y = y,
      label_hjust = -0.10
    ) |>
    ungroup()
}

global_max <- max(
  all_city$mitigation_loss_musd,
  all_city$future_loss_musd,
  na.rm = TRUE
)
x_limit <- global_max * 5.00

plot_one <- function(scenario_code) {
  dat <- all_city |>
    filter(
      scenario == scenario_code,
      is.finite(baseline_loss_musd), baseline_loss_musd > 0,
      is.finite(future_loss_musd),
      is.finite(mitigation_loss_musd),
      is.finite(reduction_rate)
    ) |>
    select_dual_rank()

  write_csv(
    dat,
    file.path(out_dir, paste0("city_dual_rank_", scenario_code, "_2050.csv"))
  )

  label_dat <- dat |>
    distinct(y, city_label)
  section_dat <- tibble(
    x = 0,
    y = c(12.35, 5.55),
    label = c("Largest avoided losses", "Highest remaining losses"),
    colour = c("#52306D", "#A95642")
  )

  ggplot(dat, aes(x = value, y = y)) +
    geom_segment(
      aes(x = 0, xend = value, yend = y, colour = section),
      linewidth = 1.25, lineend = "round"
    ) +
    geom_point(
      aes(colour = section), size = 3.25
    ) +
    geom_label(
      aes(
        x = value, y = label_y, label = value_label, colour = section,
        hjust = label_hjust
      ),
      size = 3.50, family = "sans",
      fill = alpha("white", 0.90),
      label.size = 0,
      label.padding = grid::unit(0.05, "lines")
    ) +
    geom_text(
      data = section_dat,
      aes(x = x, y = y, label = label, colour = colour),
      inherit.aes = FALSE,
      hjust = 0, fontface = "bold", size = 3.85, family = "sans"
    ) +
    scale_colour_manual(
      values = c(
        "Largest avoided losses" = "#65417E",
        "Highest remaining losses" = "#B86650",
        "#52306D" = "#52306D",
        "#A95642" = "#A95642"
      ),
      guide = "none"
    ) +
    scale_y_continuous(
      breaks = label_dat$y,
      labels = label_dat$city_label,
      limits = c(0.45, 12.8),
      expand = c(0, 0)
    ) +
    scale_x_continuous(
      trans = pseudo_log_trans(base = 10, sigma = 0.5),
      limits = c(0, x_limit),
      breaks = c(0, 1, 10, 100, 300),
      labels = label_number(big.mark = ",", accuracy = 1),
      expand = expansion(mult = c(0, 0))
    ) +
    labs(
      x = paste0("Annual loss (M USD) | ", scenario_labels[[scenario_code]], " | 2050"),
      y = NULL
    ) +
    theme_classic(base_family = "sans", base_size = 11.5) +
    theme(
      axis.line.y = element_line(colour = "#777D7F", linewidth = 0.40),
      axis.ticks.y = element_blank(),
      axis.text.y = element_text(size = 9.5, colour = "#373B3D"),
      axis.text.x = element_text(size = 9.5, colour = "#505658"),
      axis.title.x = element_text(size = 10.7, face = "bold", margin = margin(t = 6)),
      panel.grid.major.y = element_line(colour = "#ECEEED", linewidth = 0.35),
      plot.margin = margin(8, 25, 5, 5)
    )
}

for (scenario_code in names(scenario_labels)) {
  p <- plot_one(scenario_code)
  stem <- file.path(out_dir, paste0("city_dual_rank_", scenario_code, "_2050"))
  ggsave(paste0(stem, ".svg"), p, width = 9.7, height = 6.4, units = "in")
  ggsave(paste0(stem, ".pdf"), p, width = 9.7, height = 6.4, units = "in")
  ggsave(paste0(stem, ".png"), p, width = 9.7, height = 6.4,
         units = "in", dpi = 300, bg = "white")
}

cat("Saved dual city rankings to:", out_dir, "\n")
