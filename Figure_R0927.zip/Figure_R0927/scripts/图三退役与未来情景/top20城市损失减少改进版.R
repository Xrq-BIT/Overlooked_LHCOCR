suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(scales)
  library(svglite)
  library(stringr)
  library(ggh4x)
})

# -------------------------
# 1) Configuration
# -------------------------
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/未来情景/coal_plant_future_result2.xlsx"
out_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图三退役与未来情景/city_top20_current_loss_waterfall_2050"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

CITY_COL <- "gadm_admin2"
ISO3_COL <- "gadm_iso3"
BASE_LOSS_COL <- "All_loss_annual_mean_LSM_10km"
INCLUDE_COL <- "future_loss_analysis_included_2021"

SCENARIOS <- c("SSP126", "SSP245", "SSP370")
YEAR_USE <- 2050
TOP_N <- 20
DISPLAY_MAX_CHARS <- 28

OUT_CSV <- file.path(out_dir, "city_current_loss_waterfall_all_2050.csv")
OUT_TOP_CSV <- file.path(out_dir, "city_current_loss_waterfall_top20_2050.csv")
OUT_SVG <- file.path(out_dir, "city_current_loss_waterfall_top20_2050.svg")
OUT_PDF <- file.path(out_dir, "city_current_loss_waterfall_top20_2050.pdf")

# -------------------------
# 2) Read and clean
# -------------------------
df_raw <- read_excel(excel_path)
future_cols <- paste0("loss_", SCENARIOS, "_", YEAR_USE)
need_cols <- c(CITY_COL, ISO3_COL, BASE_LOSS_COL, INCLUDE_COL, future_cols)

if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

df <- df_raw %>%
  transmute(
    city_raw = str_trim(as.character(.data[[CITY_COL]])),
    iso3_raw = str_to_upper(str_trim(as.character(.data[[ISO3_COL]]))),
    included = suppressWarnings(as.numeric(.data[[INCLUDE_COL]])),
    baseline_loss = suppressWarnings(as.numeric(.data[[BASE_LOSS_COL]])),
    loss_SSP126 = suppressWarnings(as.numeric(.data[[future_cols[1]]])),
    loss_SSP245 = suppressWarnings(as.numeric(.data[[future_cols[2]]])),
    loss_SSP370 = suppressWarnings(as.numeric(.data[[future_cols[3]]]))
  ) %>%
  mutate(
    city_raw = na_if(city_raw, ""),
    iso3_raw = na_if(iso3_raw, ""),
    iso3_raw = if_else(iso3_raw %in% c("TWN", "TWM", "HKG", "MAC"), "CHN", iso3_raw)
  ) %>%
  filter(
    included == 1,
    !is.na(city_raw),
    !is.na(iso3_raw),
    !is.na(baseline_loss),
    baseline_loss > 0,
    if_all(starts_with("loss_SSP"), ~ !is.na(.x))
  )

# -------------------------
# 3) GADM level-2 aggregation
# -------------------------
city_df <- df %>%
  group_by(city_raw, iso3_raw) %>%
  summarise(
    plant_count = n(),
    Current = sum(baseline_loss),
    SSP126 = sum(loss_SSP126),
    SSP245 = sum(loss_SSP245),
    SSP370 = sum(loss_SSP370),
    .groups = "drop"
  ) %>%
  mutate(
    across(all_of(SCENARIOS), ~ pmin(.x, Current)),
    Current_M = Current / 1e6,
    SSP126_M = SSP126 / 1e6,
    SSP245_M = SSP245 / 1e6,
    SSP370_M = SSP370 / 1e6,
    mitigation_SSP126_M = Current_M - SSP126_M,
    mitigation_SSP245_M = Current_M - SSP245_M,
    mitigation_SSP370_M = Current_M - SSP370_M,
    city_name_short = str_trunc(city_raw, width = DISPLAY_MAX_CHARS, side = "right"),
    city_label_plot = paste0(city_name_short, "_", iso3_raw)
  ) %>%
  arrange(desc(Current_M)) %>%
  mutate(rank = row_number())

write.csv(city_df, OUT_CSV, row.names = FALSE)

top_city <- city_df %>%
  slice_head(n = TOP_N) %>%
  mutate(
    panel_id = row_number(),
    panel_label = paste0(letters[panel_id], ". ", city_label_plot)
  )

write.csv(top_city, OUT_TOP_CSV, row.names = FALSE)

# -------------------------
# 4) Waterfall data
# -------------------------
stage_levels <- c("Current", "SSP126", "SSP245", "SSP370")

plot_df <- top_city %>%
  transmute(
    panel_label,
    city_label_plot,
    plant_count,
    Current = Current_M,
    SSP126 = SSP126_M,
    SSP245 = SSP245_M,
    SSP370 = SSP370_M
  ) %>%
  pivot_longer(
    cols = all_of(stage_levels),
    names_to = "stage",
    values_to = "end_value"
  ) %>%
  mutate(stage = factor(stage, levels = stage_levels)) %>%
  arrange(panel_label, stage) %>%
  group_by(panel_label) %>%
  mutate(
    x_id = row_number(),
    start_value = if_else(x_id == 1, 0, lag(end_value)),
    ymin = pmin(start_value, end_value),
    ymax = pmax(start_value, end_value),
    direction = case_when(
      stage == "Current" ~ "Current",
      end_value < start_value ~ "Residual reduction",
      end_value > start_value ~ "Residual increase",
      TRUE ~ "No change"
    )
  ) %>%
  ungroup()

level_line_df <- plot_df %>%
  transmute(
    panel_label,
    x = x_id - 0.36,
    xend = x_id + 0.36,
    y = end_value,
    yend = end_value
  )

connector_df <- plot_df %>%
  arrange(panel_label, x_id) %>%
  group_by(panel_label) %>%
  transmute(
    panel_label,
    x = x_id + 0.36,
    xend = lead(x_id) - 0.36,
    y = end_value,
    yend = end_value
  ) %>%
  filter(!is.na(xend)) %>%
  ungroup()

# -------------------------
# 5) Plot: original 5 x 4 small-multiple layout
# -------------------------
fill_pal <- c(
  "Current" = "#9CDCF4",
  "Residual reduction" = "#72C6AD",
  "Residual increase" = "#F4A582",
  "No change" = "#CFCFCF"
)

p <- ggplot(plot_df) +
  geom_rect(
    aes(
      xmin = x_id - 0.32,
      xmax = x_id + 0.32,
      ymin = ymin,
      ymax = ymax,
      fill = direction
    ),
    color = NA,
    alpha = 0.96
  ) +
  geom_segment(
    data = level_line_df,
    aes(x = x, xend = xend, y = y, yend = yend),
    inherit.aes = FALSE,
    color = "black",
    linewidth = 0.55
  ) +
  geom_segment(
    data = connector_df,
    aes(x = x, xend = xend, y = y, yend = yend),
    inherit.aes = FALSE,
    color = "black",
    linewidth = 0.55
  ) +
  ggh4x::facet_wrap2(
    ~ panel_label,
    ncol = 5,
    scales = "free_y",
    axes = "x"
  ) +
  scale_x_continuous(
    breaks = seq_along(stage_levels),
    labels = stage_levels,
    expand = expansion(mult = c(0.08, 0.08))
  ) +
  scale_y_continuous(
    labels = label_number(big.mark = ",", accuracy = 1),
    expand = expansion(mult = c(0, 0.10))
  ) +
  scale_fill_manual(
    values = fill_pal,
    breaks = names(fill_pal),
    name = NULL
  ) +
  labs(
    x = NULL,
    y = "Annual economic loss (million USD)"
  ) +
  theme_classic(base_family = "Helvetica", base_size = 12) +
  theme(
    panel.grid = element_blank(),
    panel.border = element_blank(),
    axis.line = element_line(color = "black", linewidth = 0.45),
    axis.ticks = element_line(color = "black", linewidth = 0.35),
    axis.ticks.length = unit(2, "mm"),
    strip.background = element_blank(),
    strip.text = element_text(
      size = 10,
      face = "bold",
      color = "black",
      margin = margin(b = 4)
    ),
    axis.text.x = element_text(
      size = 8.5,
      color = "black",
      angle = 90,
      hjust = 1,
      vjust = 0.5
    ),
    axis.text.y = element_text(size = 8, color = "black"),
    axis.title.y = element_text(size = 11.2, color = "black"),
    legend.position = "bottom",
    legend.direction = "horizontal",
    legend.text = element_text(size = 9),
    legend.key.width = unit(0.85, "cm"),
    legend.key.height = unit(0.35, "cm"),
    plot.margin = margin(6, 8, 6, 6)
  )

# -------------------------
# 6) Export
# -------------------------
ggsave(OUT_SVG, p, width = 12, height = 9.2, device = svglite::svglite)
ggsave(OUT_PDF, p, width = 12, height = 9.2, device = grDevices::pdf)

message(
  "Done\n",
  "Analysis plants: ", nrow(df), "\n",
  "Cities: ", nrow(city_df), "\n",
  "Top cities: ", nrow(top_city), "\n",
  OUT_PDF
)
