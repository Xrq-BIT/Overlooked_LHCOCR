suppressPackageStartupMessages({
  library(ggplot2)
  library(svglite)
})

base_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图二经济损失"
variant_dir <- file.path(base_dir, "Fig2_complete_composite", "source_variants")
dir.create(variant_dir, recursive = TRUE, showWarnings = FALSE)

stack_script <- file.path(base_dir, "堆积贡献图城市相关.R")
city_script <- file.path(base_dir, "城市级排序图.R")

# Run source scripts in isolated environments so their plotting objects can be
# re-exported at revised dimensions without changing the original scripts.
old_wd <- getwd()
on.exit(setwd(old_wd), add = TRUE)
setwd(tempdir())

stack_env <- new.env(parent = globalenv())
sys.source(stack_script, envir = stack_env)
ggsave(
  file.path(variant_dir, "48_smod4_flow_withLegend_narrow.svg"),
  stack_env$p_comb,
  width = 7.0,
  height = 5.8,
  device = svglite::svglite
)

city_env <- new.env(parent = globalenv())
sys.source(city_script, envir = city_env)
ggsave(
  file.path(variant_dir, "admin2_total_lifecycle_loss_top15_MUSD_wide.svg"),
  city_env$p,
  width = 6.8,
  height = 4.8,
  device = svglite::svglite
)

message("Saved source variants to: ", variant_dir)
