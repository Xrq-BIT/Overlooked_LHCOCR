suppressPackageStartupMessages({
  library(cowplot)
  library(svglite)
})

base_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图二经济损失"
out_dir <- file.path(base_dir, "Fig2_portrait_middle_sources")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

b_env <- new.env(parent = globalenv())
c_env <- new.env(parent = globalenv())
d_env <- new.env(parent = globalenv())

sys.source(file.path(base_dir, "图二空间类型贡献竖版.R"), envir = b_env)
sys.source(
  file.path(base_dir, "老幼比例和收入Q1Q4人均总损失箱线图_第二排竖版.R"),
  envir = c_env
)
sys.source(
  file.path(base_dir, "ExtraLoss_Q1Q4人均GDP箱线图_第二排竖版.R"),
  envir = d_env
)

strip <- plot_grid(
  b_env$p,
  c_env$p_loss_vulnerable,
  d_env$p,
  nrow = 1,
  align = "hv",
  axis = "tblr",
  rel_widths = c(1, 1, 1)
)

svg_path <- file.path(out_dir, "Fig2_bcd_portrait_strip.svg")
pdf_path <- file.path(out_dir, "Fig2_bcd_portrait_strip.pdf")
png_path <- file.path(out_dir, "Fig2_bcd_portrait_strip.png")

# Re-render on a shorter canvas instead of geometrically squeezing an existing
# SVG. Text sizes and line widths therefore remain unchanged.
ggsave(svg_path, strip, width = 11.4, height = 3.5, device = svglite::svglite)
rsvg::rsvg_pdf(svg_path, pdf_path)
rsvg::rsvg_png(svg_path, png_path, width = 2500)

cat("Saved:\n", svg_path, "\n", pdf_path, "\n", png_path, "\n", sep = "")
