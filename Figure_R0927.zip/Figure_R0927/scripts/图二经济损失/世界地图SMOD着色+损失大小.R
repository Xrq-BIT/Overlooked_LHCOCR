# =========================
# A1. Global map:
# color = aggregated spatial type
# size  = Total_loss
# export:
#   1) main svg/pdf
#   2) legend svg/pdf
#   3) combined svg/pdf
# =========================

# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(sf)
  library(ggplot2)
  library(rnaturalearth)
  library(scales)
  library(cowplot)
  library(svglite)
  library(grid)
})

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"

LON_COL  <- "Longitude"
LAT_COL  <- "Latitude"
LOSS_COL <- "All_loss_annual_mean_LSM_10km"
SMOD_COL <- "SMOD_2015_label"

OUT_MAIN_SVG <- "48_A1_smod4_map_main.svg"
OUT_MAIN_PDF <- "48_A1_smod4_map_main.pdf"
OUT_LEG_SVG  <- "48_A1_smod4_map_legend.svg"
OUT_LEG_PDF  <- "48_A1_smod4_map_legend.pdf"
OUT_COMB_SVG <- "48_A1_smod4_map_withLegend.svg"
OUT_COMB_PDF <- "48_A1_smod4_map_withLegend.pdf"

# =========================
# 2) Read & prepare
# =========================
df_raw <- read_excel(excel_path)

need_cols <- c(LON_COL, LAT_COL, LOSS_COL, SMOD_COL)
if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

df <- df_raw %>%
  mutate(
    lon  = as.numeric(.data[[LON_COL]]),
    lat  = as.numeric(.data[[LAT_COL]]),
    loss_raw = as.numeric(.data[[LOSS_COL]]),
    loss_musd = loss_raw / 1e6,
    smod_raw = as.character(.data[[SMOD_COL]])
  ) %>%
  filter(!is.na(lon), !is.na(lat), !is.na(loss_musd), !is.na(smod_raw), smod_raw != "")

# =========================
# 3) Recode SMOD -> 4 classes
# =========================
df <- df %>%
  mutate(
    smod_group = case_when(
      smod_raw %in% c("Urban centre") ~ "Urban core",
      smod_raw %in% c("Dense urban cluster",
                      "Semi-dense urban cluster",
                      "Suburban / peri-urban") ~ "Peri-urban",
      smod_raw %in% c("Rural cluster",
                      "Low density rural") ~ "Rural",
      smod_raw %in% c("Very low density rural",
                      "Water / no settlement") ~ "Remote",
      TRUE ~ "Remote"
    )
  )

smod_order <- c("Urban core", "Peri-urban", "Rural", "Remote")
df$smod_group <- factor(df$smod_group, levels = smod_order)

# =========================
# 4) 点大小：5%-95% 截取
# =========================
q05 <- as.numeric(quantile(df$loss_musd, 0.05, na.rm = TRUE))
q95 <- as.numeric(quantile(df$loss_musd, 0.95, na.rm = TRUE))

df <- df %>%
  mutate(
    loss_plot = pmin(pmax(loss_musd, q05), q95)
  )

# =========================
# 5) sf objects
# =========================
pts <- st_as_sf(df, coords = c("lon", "lat"), crs = 4326, remove = FALSE)
world <- ne_countries(scale = "medium", returnclass = "sf")

# =========================
# 6) Palette
# =========================
# 4类更稳、更清楚
smod_pal <- c(
  "Urban core" = "#2C7BB6",   # 蓝
  "Peri-urban" = "#1A9850",   # 绿
  "Rural"      = "#F46D43",   # 橙红
  "Remote"     = "#9E9E9E"    # 灰
)

# 点大小 breaks
size_breaks <- pretty(c(q05, q95), n = 4)
size_breaks <- size_breaks[size_breaks > 0]

# =========================
# 7) Main map (NO legend)
# =========================
p_main <- ggplot() +
  geom_sf(data = world, fill = "grey92", color = "grey72", linewidth = 0.25) +
  geom_sf(
    data = pts,
    aes(color = smod_group, size = loss_plot),
    alpha = 0.92
  ) +
  scale_color_manual(values = smod_pal, drop = FALSE, guide = "none") +
  scale_size_continuous(
    range = c(0.3, 1.5),   # ✅ 比之前略小
    breaks = size_breaks,
    labels = label_number(accuracy = 0.1),
    guide = "none"
  ) +
  coord_sf(expand = FALSE, xlim = c(-150, 150), ylim = c(-60, 80)) +
  scale_x_continuous(
    breaks = seq(-150, 150, by = 60),
    labels = function(x) paste0(ifelse(x == 0, "0", abs(x)), "°",
                                ifelse(x < 0, "W", ifelse(x > 0, "E", "")))
  ) +
  scale_y_continuous(
    breaks = seq(-30, 60, by = 30),
    labels = function(y) paste0(ifelse(y == 0, "0", abs(y)), "°",
                                ifelse(y < 0, "S", ifelse(y > 0, "N", "")))
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.background  = element_rect(fill = "white", color = NA),
    panel.grid.major  = element_blank(),
    panel.grid.minor  = element_blank(),
    axis.title        = element_blank(),
    axis.text         = element_text(color = "grey25", size = 9),
    axis.ticks        = element_line(color = "grey60", linewidth = 0.3),
    axis.ticks.length = unit(2.0, "mm"),
    panel.border      = element_rect(color = "grey40", fill = NA, linewidth = 0.6),
    plot.margin       = margin(5, 10, 5, 10)
  )

ggsave(OUT_MAIN_SVG, p_main, width = 12, height = 5.3, device = svglite::svglite)
ggsave(OUT_MAIN_PDF, p_main, width = 12, height = 5.3)

# =========================
# 8) Legend-only plot
# =========================
p_leg_src <- ggplot() +
  geom_sf(data = world, fill = "grey92", color = "grey72", linewidth = 0.25) +
  geom_sf(
    data = pts,
    aes(color = smod_group, size = loss_plot),
    alpha = 0.92
  ) +
  scale_color_manual(
    values = smod_pal,
    drop = FALSE,
    name = "Spatial type"
  ) +
  scale_size_continuous(
    range = c(0.25, 2.0),
    breaks = size_breaks,
    labels = label_number(accuracy = 0.1),
    name = "Total loss (M USD)"
  ) +
  guides(
    color = guide_legend(
      order = 1,
      override.aes = list(size = 4, alpha = 1)
    ),
    size = guide_legend(order = 2)
  ) +
  theme_void(base_size = 12) +
  theme(
    legend.position = "right",
    legend.box = "vertical",
    legend.title = element_text(size = 11),
    legend.text = element_text(size = 10)
  )

leg <- cowplot::get_legend(p_leg_src)

ggsave(OUT_LEG_SVG, leg, width = 3.3, height = 3.8, device = svglite::svglite)
ggsave(OUT_LEG_PDF, leg, width = 3.3, height = 3.8)

# =========================
# 9) Combined figure
# =========================
LEG_X <- 0.07
LEG_Y <- 0.02
LEG_W <- 0.18
LEG_H <- 0.55
LEG_SCALE <- 0.30

p_final <- cowplot::ggdraw() +
  cowplot::draw_plot(p_main, x = 0, y = 0, width = 1, height = 1) +
  cowplot::draw_grob(
    leg,
    x = LEG_X,
    y = LEG_Y,
    width = LEG_W,
    height = LEG_H,
    scale = LEG_SCALE,
    hjust = 0,
    vjust = 0
  )

ggsave(
  OUT_COMB_SVG,
  p_final,
  width = 12,
  height = 5.2,
  device = svglite::svglite
)

ggsave(
  OUT_COMB_PDF,
  p_final,
  width = 12,
  height = 5.2
)


# =========================
# 10) Print summary
# =========================
cat("\nSMOD groups used:\n")
print(table(df$smod_group, useNA = "ifany"))

cat("\nLoss summary (M USD, raw):\n")
print(summary(df$loss_musd))

cat("\nSize mapping range (after 5%-95% squish):\n")
cat("q05 =", q05, "\n")
cat("q95 =", q95, "\n")

cat("\n输出文件：\n",
    OUT_MAIN_SVG, "\n",
    OUT_LEG_SVG, "\n",
    OUT_COMB_SVG, "\n",
    OUT_COMB_PDF, "\n")