# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(svglite)
  library(stringr)
  library(forcats)
  library(scales)
  library(ggtext)
})

# =========================
# 1) File paths
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"

out_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图二经济损失/country_total_lifecycle_loss_ranking"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

OUT_CSV <- file.path(out_dir, "country_total_lifecycle_loss_ranking_all.csv")
OUT_TOP_CSV <- file.path(out_dir, "country_total_lifecycle_loss_ranking_top15.csv")
OUT_SVG <- file.path(out_dir, "country_total_lifecycle_loss_top15_MUSD.svg")
OUT_PDF <- file.path(out_dir, "country_total_lifecycle_loss_top15_MUSD.pdf")

# =========================
# 2) Config
# =========================
VAL_COL  <- "All_loss_lifecycle_60yr_LSM_10km"
TYPE_COL <- "Type"
ISO3_COL <- "gadm_iso3"

TOP_N <- 15

type_levels <- c("coal", "oil/gas", "bioenergy")

# =========================
# 2.1) Fixed country palette
# Keep this palette identical in city-level and country-level plots
# =========================
iso3_pal <- c(
  "CHN" = "#D73027",
  "IND" = "#4575B4",
  "THA" = "#F46D43",
  "BRA" = "#1A9850",
  "IDN" = "#984EA3",
  "PHL" = "#00A6D6",
  "ECU" = "#FDB863",
  "MEX" = "#66C2A5",
  "DOM" = "#B35806",
  "MYS" = "#5E4FA2",
  "SGP" = "#8DD3C7",
  "VEN" = "#A6761D",
  "CMR" = "#7F7F7F",
  "HND" = "#E7298A",
  "AGO" = "#A6CEE3",
  
  # 统一并入 CHN 后一般不会再出现在结果里；
  # 保留是为了防止其他代码复用时出现未匹配颜色
  "TWN" = "#D73027",
  "HKG" = "#D73027",
  "MAC" = "#D73027"
)

# =========================
# 3) Read
# =========================
df_raw <- read_excel(excel_path)

need_cols <- c(VAL_COL, TYPE_COL, ISO3_COL)

if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

df <- df_raw %>%
  transmute(
    iso3 = str_to_upper(str_trim(as.character(.data[[ISO3_COL]]))),
    Type = as.character(.data[[TYPE_COL]]),
    loss_usd = suppressWarnings(as.numeric(.data[[VAL_COL]])),
    loss_musd = loss_usd / 1e6
  ) %>%
  mutate(
    iso3 = ifelse(
      is.na(iso3) |
        iso3 == "" |
        str_to_lower(iso3) %in% c("unknown", "na", "n/a", "none", "null"),
      NA_character_,
      iso3
    ),
    
    # =========================
    # 将台湾、香港、澳门并入 CHN
    # =========================
    iso3 = case_when(
      iso3 %in% c("TWN", "HKG", "MAC") ~ "CHN",
      TRUE ~ iso3
    ),
    
    Type = ifelse(Type %in% type_levels, Type, "Other")
  ) %>%
  filter(
    !is.na(iso3),
    !is.na(loss_usd)
  )

# =========================
# 4) Country-level aggregation
# =========================
country_rank <- df %>%
  group_by(iso3) %>%
  summarise(
    total_loss_usd  = sum(loss_usd, na.rm = TRUE),
    total_loss_musd = sum(loss_musd, na.rm = TRUE),
    mean_loss_musd  = mean(loss_musd, na.rm = TRUE),
    
    plant_count     = n(),
    coal_count      = sum(Type == "coal", na.rm = TRUE),
    oilgas_count    = sum(Type == "oil/gas", na.rm = TRUE),
    bioenergy_count = sum(Type == "bioenergy", na.rm = TRUE),
    other_count     = sum(Type == "Other", na.rm = TRUE),
    
    .groups = "drop"
  ) %>%
  arrange(desc(total_loss_musd)) %>%
  mutate(rank = row_number())

write.csv(country_rank, OUT_CSV, row.names = FALSE)

top_country <- country_rank %>%
  slice_head(n = TOP_N) %>%
  mutate(
    iso3 = fct_reorder(iso3, total_loss_musd)
  )

# =========================

# 4.1) Add fixed country color marks

# =========================

top_country <- top_country %>%
  
  mutate(
    
    iso3_chr = as.character(iso3),
    
    country_color = ifelse(
      
      iso3_chr %in% names(iso3_pal),
      
      iso3_pal[iso3_chr],
      
      "grey40"
      
    )
    
  )

write.csv(top_country, OUT_TOP_CSV, row.names = FALSE)

cat("\nTop countries:\n")

print(
  
  top_country %>%
    
    select(
      
      rank, iso3_chr, total_loss_musd, plant_count,
      
      coal_count, oilgas_count, bioenergy_count, other_count
      
    ),
  
  n = TOP_N
  
)

# =========================
# 5) Plot
# =========================
x_max <- max(top_country$total_loss_musd, na.rm = TRUE)

# 左侧专门留一小块空间放“颜色方块 + ISO3”
x_left_lim <- -x_max * 0.18
x_square   <- -x_max * 0.145
x_label    <- -x_max * 0.120

p <- ggplot(top_country, aes(x = total_loss_musd, y = iso3)) +
  
  # 左侧国家颜色方块
  geom_point(
    data = top_country,
    aes(
      x = x_square,
      y = iso3,
      color = iso3_chr
    ),
    inherit.aes = FALSE,
    shape = 15,
    size = 3.2,
    show.legend = FALSE
  ) +
  
  # 左侧国家代码，作为普通文本，不再作为 y 轴标签
  geom_text(
    data = top_country,
    aes(
      x = x_label,
      y = iso3,
      label = iso3_chr
    ),
    inherit.aes = FALSE,
    hjust = 0,
    size = 3.8,
    color = "grey25"
  ) +
  
  geom_col(
    fill = "#D9895B",
    alpha = 0.75,
    width = 0.68
  ) +
  
  geom_point(
    aes(size = plant_count),
    color = "black",
    fill = "white",
    shape = 21,
    stroke = 0.45,
    alpha = 0.95
  ) +
  
  geom_text(
    aes(
      label = paste0(
        label_number(big.mark = ",", accuracy = 0.1)(total_loss_musd),
        " M"
      )
    ),
    hjust = -0.08,
    size = 2.8
  ) +
  
  geom_vline(
    xintercept = 0,
    color = "black",
    linewidth = 0.45
  ) +
  
  scale_color_manual(
    values = iso3_pal,
    na.value = "grey40",
    guide = "none"
  ) +
  
  scale_x_continuous(
    limits = c(x_left_lim, NA),
    breaks = pretty(c(0, x_max), n = 5),
    labels = label_number(big.mark = ",", accuracy = 0.1),
    expand = expansion(mult = c(0, 0.22))
  ) +
  
  scale_size_continuous(
    range = c(2.0, 6.0),
    breaks = c(10, 50, 100, 200, 500),
    name = "Plant count"
  ) +
  
  labs(
    x = "Total lifecycle loss (M USD)",
    y = NULL
  ) +
  
  coord_cartesian(clip = "off") +
  
  theme_bw(base_size = 12) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 0.8),
    
    # 关键：彻底去掉原始 y 轴文字和 y 轴刻度
    axis.text.y = element_blank(),
    axis.ticks.y = element_blank(),
    
    axis.text.x = element_text(size = 10, color = "grey25"),
    axis.title.x = element_text(size = 11.5),
    
    axis.ticks.x = element_line(color = "grey35", linewidth = 0.35),
    axis.ticks.length = unit(2, "mm"),
    
    legend.position = "inside",
    legend.position.inside = c(0.98, 0.03),
    legend.justification = c(1, 0),
    legend.background = element_rect(fill = "white", color = "black", linewidth = 0.4),
    legend.title = element_text(size = 8.8),
    legend.text = element_text(size = 8),
    
    plot.margin = margin(6, 24, 6, 6)
  )
# =========================
# 6) Export
# =========================
ggsave(
  OUT_SVG,
  p,
  width = 5.0,
  height = 4.8,
  device = svglite::svglite
)

ggsave(
  OUT_PDF,
  p,
  width = 5.0,
  height = 4.8
)

message(
  "Done!\n",
  "- ", OUT_CSV, "\n",
  "- ", OUT_TOP_CSV, "\n",
  "- ", OUT_SVG, "\n",
  "- ", OUT_PDF
)
