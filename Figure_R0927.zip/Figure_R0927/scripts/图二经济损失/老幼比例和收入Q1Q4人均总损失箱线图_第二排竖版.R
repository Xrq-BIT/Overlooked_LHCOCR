suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(scales)
  library(cowplot)
  library(svglite)
})

excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"
out_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图二经济损失/Fig2_portrait_middle_sources"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

raw <- read_excel(excel_path)
needed <- c(
  "All_loss_annual_mean_LSM_10km", "pop_10km_total_worldpop2020",
  "ratio_10km_child_0_4", "ratio_10km_old_worldpop2020",
  "GDP_per_capita_2019"
)
missing <- setdiff(needed, names(raw))
if (length(missing) > 0) stop("Missing columns: ", paste(missing, collapse = ", "))

dat <- raw %>%
  transmute(
    annual_total_loss = suppressWarnings(as.numeric(All_loss_annual_mean_LSM_10km)),
    pop_10km = suppressWarnings(as.numeric(pop_10km_total_worldpop2020)),
    child_share = suppressWarnings(as.numeric(ratio_10km_child_0_4)),
    old_share = suppressWarnings(as.numeric(ratio_10km_old_worldpop2020)),
    gdp_pc = suppressWarnings(as.numeric(GDP_per_capita_2019))
  ) %>%
  mutate(
    vulnerable_share = child_share + old_share,
    loss_per_capita = annual_total_loss / pop_10km
  ) %>%
  filter(
    is.finite(loss_per_capita), loss_per_capita >= 0,
    is.finite(pop_10km), pop_10km > 0,
    is.finite(vulnerable_share),
    is.finite(gdp_pc), gdp_pc > 0
  ) %>%
  mutate(
    vulnerable_quartile = ntile(vulnerable_share, 4),
    income_quartile = ntile(gdp_pc, 4),
    loss_quartile = ntile(loss_per_capita, 4)
  )

make_q1_q4_data <- function(quartile_col, dimension) {
  dat %>%
    filter(.data[[quartile_col]] %in% c(1, 4)) %>%
    transmute(
      dimension = dimension,
      group = factor(
        if_else(.data[[quartile_col]] == 1, "Q1\nlowest", "Q4\nhighest"),
        levels = c("Q1\nlowest", "Q4\nhighest")
      ),
      loss_per_capita
    )
}

vulnerable_dat <- make_q1_q4_data("vulnerable_quartile", "Vulnerability")
income_dat <- make_q1_q4_data("income_quartile", "Income")
plot_source <- bind_rows(vulnerable_dat, income_dat)

# Winsorize display values to P5-P95; statistical tests use uncapped raw values.
display_lower <- quantile(plot_source$loss_per_capita, 0.05, na.rm = TRUE)
display_upper <- quantile(plot_source$loss_per_capita, 0.95, na.rm = TRUE)
plot_source <- plot_source %>%
  mutate(loss_plot = pmin(pmax(loss_per_capita, display_lower), display_upper))

summary_table <- plot_source %>%
  group_by(dimension, group) %>%
  summarise(
    n = n(),
    mean_loss_per_capita = mean(loss_per_capita),
    median_loss_per_capita = median(loss_per_capita),
    q25_loss_per_capita = quantile(loss_per_capita, 0.25),
    q75_loss_per_capita = quantile(loss_per_capita, 0.75),
    .groups = "drop"
  )

test_dimension <- function(plot_dat) {
  q1 <- plot_dat %>% filter(group == "Q1\nlowest") %>% pull(loss_per_capita)
  q4 <- plot_dat %>% filter(group == "Q4\nhighest") %>% pull(loss_per_capita)
  test <- wilcox.test(q4, q1, exact = FALSE)
  data.frame(
    dimension = unique(plot_dat$dimension),
    n_q1 = length(q1),
    n_q4 = length(q4),
    median_q1 = median(q1),
    median_q4 = median(q4),
    median_ratio_q4_q1 = median(q4) / median(q1),
    p_value = test$p.value,
    significance = case_when(
      test$p.value < 0.001 ~ "***",
      test$p.value < 0.01 ~ "**",
      test$p.value < 0.05 ~ "*",
      TRUE ~ "ns"
    )
  )
}

tests <- bind_rows(
  test_dimension(vulnerable_dat),
  test_dimension(income_dat)
)

write.csv(summary_table, file.path(out_dir, "Q1_Q4_per_capita_loss_summary.csv"), row.names = FALSE)
write.csv(tests, file.path(out_dir, "Q1_Q4_per_capita_loss_tests.csv"), row.names = FALSE)

group_pal <- c("Q1\nlowest" = "#C9DCE6", "Q4\nhighest" = "#C97A62")

plot_box <- function(dimension, x_label) {
  plot_dat <- plot_source %>% filter(.data$dimension == .env$dimension)
  p_label <- tests %>% filter(.data$dimension == .env$dimension) %>% pull(significance)
  x_labels <- c(
    "Q1\nlowest" = "Q1 (lowest)",
    "Q4\nhighest" = "Q4 (highest)"
  )
  y_min <- min(plot_dat$loss_plot)
  y_max <- max(plot_dat$loss_plot)
  y_range <- y_max - y_min
  # Keep the P5-P95 display range; only tighten annotation headroom.
  y_sig <- y_max + 0.045 * y_range
  y_limit <- y_max + 0.105 * y_range

  ggplot(plot_dat, aes(group, loss_plot, fill = group)) +
    geom_point(
      position = position_jitter(width = 0.16, height = 0, seed = 123),
      size = 0.65, alpha = 0.10, color = "#333333", show.legend = FALSE
    ) +
    geom_boxplot(
      width = 0.46, outlier.shape = NA, color = "#303030", alpha = 0.88,
      linewidth = 0.62,
      show.legend = FALSE
    ) +
    annotate("segment", x = 1, xend = 2, y = y_sig, yend = y_sig, linewidth = 0.55) +
    annotate(
      "segment", x = 1, xend = 1,
      y = y_sig - 0.020 * y_range, yend = y_sig, linewidth = 0.55
    ) +
    annotate(
      "segment", x = 2, xend = 2,
      y = y_sig - 0.020 * y_range, yend = y_sig, linewidth = 0.55
    ) +
    annotate(
      "text", x = 1.5, y = y_sig + 0.022 * y_range,
      label = p_label, size = 4, fontface = "bold"
    ) +
    scale_fill_manual(values = group_pal, drop = FALSE) +
    scale_x_discrete(labels = x_labels) +
    scale_y_continuous(
      labels = label_number(big.mark = ",", accuracy = 1),
      limits = c(y_min, y_limit),
      expand = c(0, 0)
    ) +
    labs(
      x = x_label,
      y = "Annual loss per capita ($)"
    ) +
    theme_classic(base_size = 12) +
    theme(
      panel.grid = element_blank(),
      panel.border = element_rect(fill = NA, color = "#4C4C4C", linewidth = 0.45),
      axis.line = element_blank(),
      axis.ticks = element_line(color = "#666666", linewidth = 0.35),
      axis.text.x = element_text(size = 10.5, color = "#3F3F3F"),
      axis.text.y = element_text(size = 10, color = "#3F3F3F"),
      axis.title.x = element_text(size = 12),
      axis.title.y = element_text(size = 12),
      legend.position = "none",
      plot.margin = margin(6, 6, 6, 6)
    )
}

p_vulnerable <- plot_box("Vulnerability", "Vulnerable share")
p_income <- plot_box("Income", "Income")

# Reverse specification used in the final figure: loss quartiles on the x-axis.
loss_vulnerable_dat <- dat %>%
  filter(loss_quartile %in% c(1, 4)) %>%
  transmute(
    group = factor(
      if_else(loss_quartile == 1, "Loss Q1 (lowest)", "Loss Q4 (highest)"),
      levels = c("Loss Q1 (lowest)", "Loss Q4 (highest)")
    ),
    vulnerable_share
  )

loss_q1 <- loss_vulnerable_dat %>%
  filter(group == "Loss Q1 (lowest)") %>% pull(vulnerable_share)
loss_q4 <- loss_vulnerable_dat %>%
  filter(group == "Loss Q4 (highest)") %>% pull(vulnerable_share)
loss_vulnerable_test <- wilcox.test(loss_q4, loss_q1, exact = FALSE)
loss_vulnerable_sig <- case_when(
  loss_vulnerable_test$p.value < 0.001 ~ "***",
  loss_vulnerable_test$p.value < 0.01 ~ "**",
  loss_vulnerable_test$p.value < 0.05 ~ "*",
  TRUE ~ "ns"
)

write.csv(
  data.frame(
    q1_n = length(loss_q1), q4_n = length(loss_q4),
    q1_mean = mean(loss_q1), q4_mean = mean(loss_q4),
    q1_median = median(loss_q1), q4_median = median(loss_q4),
    p_value = loss_vulnerable_test$p.value,
    significance = loss_vulnerable_sig
  ),
  file.path(out_dir, "loss_Q1_Q4_vulnerability_test.csv"), row.names = FALSE
)

reverse_y_min <- min(loss_vulnerable_dat$vulnerable_share)
reverse_y_max <- max(loss_vulnerable_dat$vulnerable_share)
reverse_y_range <- reverse_y_max - reverse_y_min
reverse_sig_y <- reverse_y_max + 0.045 * reverse_y_range
reverse_limit <- reverse_y_max + 0.105 * reverse_y_range

p_loss_vulnerable <- ggplot(
  loss_vulnerable_dat,
  aes(group, vulnerable_share, fill = group)
) +
  geom_point(
    position = position_jitter(width = 0.16, height = 0, seed = 123),
    size = 0.65, alpha = 0.10, color = "#333333", show.legend = FALSE
  ) +
  geom_boxplot(
    width = 0.46, outlier.shape = NA, color = "#303030", alpha = 0.88,
    linewidth = 0.62, show.legend = FALSE
  ) +
  annotate("segment", x = 1, xend = 2, y = reverse_sig_y, yend = reverse_sig_y, linewidth = 0.55) +
  annotate("segment", x = 1, xend = 1,
           y = reverse_sig_y - 0.020 * reverse_y_range, yend = reverse_sig_y, linewidth = 0.55) +
  annotate("segment", x = 2, xend = 2,
           y = reverse_sig_y - 0.020 * reverse_y_range, yend = reverse_sig_y, linewidth = 0.55) +
  annotate("text", x = 1.5, y = reverse_sig_y + 0.022 * reverse_y_range,
           label = loss_vulnerable_sig, size = 4, fontface = "bold") +
  scale_fill_manual(values = c(
    "Loss Q1 (lowest)" = "#C9DCE6",
    "Loss Q4 (highest)" = "#C97A62"
  )) +
  scale_x_discrete(
    labels = c(
      "Loss Q1 (lowest)" = "Per-cap. loss Q1 (low)",
      "Loss Q4 (highest)" = "Per-cap. loss Q4 (high)"
    ),
    expand = expansion(add = 0.4)
  ) +
  scale_y_continuous(
    labels = percent_format(accuracy = 1),
    limits = c(reverse_y_min, reverse_limit), expand = c(0, 0)
  ) +
  labs(x = NULL, y = "Vulnerable population share") +
  theme_classic(base_size = 12) +
  theme(
    panel.grid = element_blank(),
    panel.border = element_rect(fill = NA, color = "#4C4C4C", linewidth = 0.45),
    axis.line = element_blank(),
    axis.ticks = element_line(color = "#666666", linewidth = 0.35),
    axis.text.x = element_text(size = 9.5, color = "#3F3F3F"),
    axis.text.y = element_text(size = 10, color = "#3F3F3F"),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12),
    legend.position = "none",
    plot.margin = margin(6, 6, 6, 6)
  )

combined <- plot_grid(p_vulnerable, p_income, nrow = 1, align = "hv", axis = "tblr")

ggsave(file.path(out_dir, "Q1_Q4_per_capita_loss_boxplots.pdf"), combined,
       width = 7.8, height = 4.2, device = grDevices::pdf)
ggsave(file.path(out_dir, "Q1_Q4_per_capita_loss_boxplots.svg"), combined,
       width = 7.8, height = 4.2, device = svglite::svglite)
ggsave(file.path(out_dir, "Q1_Q4_vulnerability_boxplot.pdf"), p_vulnerable,
       width = 3.67, height = 4.0, device = grDevices::pdf)
ggsave(file.path(out_dir, "Q1_Q4_vulnerability_boxplot.svg"), p_vulnerable,
       width = 3.67, height = 4.0, device = svglite::svglite)
ggsave(file.path(out_dir, "Q1_Q4_income_boxplot.pdf"), p_income,
       width = 3.67, height = 4.0, device = grDevices::pdf)
ggsave(file.path(out_dir, "Q1_Q4_income_boxplot.svg"), p_income,
       width = 3.67, height = 4.0, device = svglite::svglite)
ggsave(file.path(out_dir, "loss_Q1_Q4_vulnerability_boxplot.pdf"), p_loss_vulnerable,
       width = 4.0, height = 5.2, device = grDevices::pdf)
ggsave(file.path(out_dir, "loss_Q1_Q4_vulnerability_boxplot.svg"), p_loss_vulnerable,
       width = 4.0, height = 5.2, device = svglite::svglite)

cat("Complete rows: ", nrow(dat), "\n", sep = "")
print(summary_table)
print(tests)
