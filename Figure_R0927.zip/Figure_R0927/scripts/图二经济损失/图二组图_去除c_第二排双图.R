suppressPackageStartupMessages({library(xml2); library(rsvg)})
base <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图二经济损失/Fig2_complete_composite_portrait_middle"
src <- file.path(base, "Fig2_economic_loss_polished_portrait_middle.svg")
out <- file.path(base, "Fig2_abcde_no_vulnerability")
hash <- tools::md5sum(src)
d <- read_xml(src)
r <- xml_root(d)
p <- xml_find_all(r, "./*[local-name()='svg']")
stopifnot(length(p) == 5)
keep <- vapply(p[c(1,2,4,5)], as.character, character(1))
strip <- p[[3]]
g <- xml_find_first(strip, "./*[local-name()='g']")
children <- xml_children(g)
stopifnot(length(children) == 22)
# Remove only the middle panel's definitions, drawing and axis labels.
xml_remove(children[11:16])
scale <- as.numeric(xml_attr(strip, "width")) / 820.8
target_w <- (1076.81 - 109 - 76) / 2
new_w <- target_w / scale
left <- 56.16
second <- left + (target_w + 76) / scale
map_x <- function(v) {
  old_left <- ifelse(v < 410.4, 56.16, 603.36)
  new_left <- ifelse(v < 410.4, left, second)
  offset <- v - old_left
  new_left + ifelse(offset < 0, offset,
    ifelse(offset > 211.46, new_w + offset - 211.46, offset * new_w / 211.46))
}
fmt <- function(v) sprintf("%.4f", v)
for (n in xml_find_all(strip, ".//*")) {
  a <- xml_attrs(n)
  for (key in intersect(names(a), c("x", "x1", "x2", "cx")))
    xml_set_attr(n, key, fmt(map_x(as.numeric(a[[key]]))))
  if ("width" %in% names(a) && !grepl("%", a[["width"]])) {
    x <- if ("x" %in% names(a)) as.numeric(a[["x"]]) else 0
    xml_set_attr(n, "width", fmt(map_x(x + as.numeric(a[["width"]])) - map_x(x)))
  }
  if ("points" %in% names(a)) {
    pts <- matrix(as.numeric(strsplit(trimws(a[["points"]]), "[,[:space:]]+")[[1]]), ncol=2, byrow=TRUE)
    xml_set_attr(n, "points", paste(paste(fmt(map_x(pts[,1])), fmt(pts[,2]), sep=","), collapse=" "))
  }
  if ("transform" %in% names(a)) {
    tr <- a[["transform"]]
    h <- regmatches(tr, regexec("translate\\(([-0-9.]+),([-0-9.]+)\\)", tr))[[1]]
    stopifnot(length(h) == 3)
    xml_set_attr(n, "transform", sub("translate\\([^)]+\\)", paste0("translate(", fmt(map_x(as.numeric(h[2]))), ",", h[3], ")"), tr))
  }
}
# Keep the GDP boxes at their original visible width after widening the panel.
for (box in xml_find_all(strip, ".//*[local-name()='polygon']")) {
  pts <- matrix(as.numeric(strsplit(trimws(xml_attr(box, "points")), "[,[:space:]]+")[[1]]), ncol=2, byrow=TRUE)
  edges <- range(pts[,1])
  centre <- mean(edges)
  if (centre < second) next
  factor <- 211.46 / new_w
  pts[,1] <- centre + (pts[,1] - centre) * factor
  xml_set_attr(box, "points", paste(sprintf("%.4f,%.4f", pts[,1], pts[,2]), collapse=" "))
  for (line in xml_find_all(strip, ".//*[local-name()='line']")) {
    if (abs(as.numeric(xml_attr(line, "x1")) - edges[1]) < 0.001 &&
        abs(as.numeric(xml_attr(line, "x2")) - edges[2]) < 0.001) {
      xml_set_attr(line, "x1", fmt(centre + (edges[1] - centre) * factor))
      xml_set_attr(line, "x2", fmt(centre + (edges[2] - centre) * factor))
    }
  }
}
labels <- xml_find_all(r, "./*[local-name()='text']")
xml_remove(labels[xml_text(labels) == "c"])
for (old in c("d", "e", "f")) {
  node <- labels[xml_text(labels) == old]
  xml_set_text(node, c(d="c", e="d", f="e")[[old]])
  if (old == "d") xml_set_attr(node, "x", fmt(109 + target_w + 76 - 44))
}
stopifnot(identical(keep, vapply(p[c(1,2,4,5)], as.character, character(1))))
write_xml(d, paste0(out, ".svg"))
rsvg_pdf(paste0(out, ".svg"), paste0(out, ".pdf"))
rsvg_png(paste0(out, ".svg"), paste0(out, ".png"), width=3000)
stopifnot(identical(hash, tools::md5sum(src)))
cat("Saved", out, "\nOriginal unchanged; map and ranking panels unchanged.\n")
