# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(sf)
  library(ggplot2)
  library(scales)
  library(svglite)
  library(cowplot)
  library(stringr)
})

sf::sf_use_s2(FALSE)

# =========================
# 1) File paths
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"

gpkg_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/data/GHS_UCDB_GLOBE_R2024A_V1_1/GHS_UCDB_GLOBE_R2024A.gpkg"
layer_name <- "GHS_UCDB_THEME_CLIMATE_GLOBE_R2024A"

out_dir <- "city_level_loss_Q1_Q4_boxplots"
dir.create(out_dir, showWarnings = FALSE)

OUT_SVG  <- file.path(out_dir, "city_loss_Q1_Q4_vulnerable_gdp_boxplots.svg")
OUT_PDF  <- file.path(out_dir, "city_loss_Q1_Q4_vulnerable_gdp_boxplots.pdf")

# 单独导出两个子图
OUT_VUL_SVG <- file.path(out_dir, "city_loss_Q1_Q4_vulnerable_boxplot.svg")
OUT_VUL_PDF <- file.path(out_dir, "city_loss_Q1_Q4_vulnerable_boxplot.pdf")

OUT_GDP_SVG <- file.path(out_dir, "city_loss_Q1_Q4_gdp_boxplot.svg")
OUT_GDP_PDF <- file.path(out_dir, "city_loss_Q1_Q4_gdp_boxplot.pdf")

OUT_CSV  <- file.path(out_dir, "city_loss_Q1_Q4_summary.csv")
OUT_TEST <- file.path(out_dir, "city_loss_Q1_Q4_tests.csv")
OUT_ALL  <- file.path(out_dir, "city_level_loss_all.csv")

# =========================
# 2) Config
# =========================
LON_COL <- "Longitude"
LAT_COL <- "Latitude"

LOSS_COL  <- "All_loss_annual_mean_LSM_10km"
POP_COL   <- "pop_10km_total_worldpop2020"
CHILD_COL <- "ratio_10km_child_worldpop2020"
OLD_COL   <- "ratio_10km_old_worldpop2020"
GDP_COL   <- "GDP_per_capita_2019"

CITY_ID_COL <- "ID_UC_G0"

# =========================
# 3) Read plant data
# =========================
df_raw <- read_excel(excel_path)

need_cols <- c(
  LON_COL, LAT_COL,
  LOSS_COL, POP_COL, CHILD_COL, OLD_COL, GDP_COL
)

if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

plants_df <- df_raw %>%
  transmute(
    Longitude = suppressWarnings(as.numeric(.data[[LON_COL]])),
    Latitude  = suppressWarnings(as.numeric(.data[[LAT_COL]])),
    
    loss = suppressWarnings(as.numeric(.data[[LOSS_COL]])),
    pop  = suppressWarnings(as.numeric(.data[[POP_COL]])),
    
    child_ratio = suppressWarnings(as.numeric(.data[[CHILD_COL]])),
    old_ratio   = suppressWarnings(as.numeric(.data[[OLD_COL]])),
    gdp_pc      = suppressWarnings(as.numeric(.data[[GDP_COL]]))
  ) %>%
  mutate(
    vulnerable_ratio = child_ratio + old_ratio
  ) %>%
  filter(
    !is.na(Longitude),
    !is.na(Latitude),
    !is.na(loss),
    !is.na(pop), pop > 0,
    !is.na(vulnerable_ratio),
    !is.na(gdp_pc), gdp_pc > 0
  )

plants_sf <- st_as_sf(
  plants_df,
  coords = c("Longitude", "Latitude"),
  crs = 4326,
  remove = FALSE
)

# =========================
# 4) Read GHS city polygons
# =========================
cities <- st_read(gpkg_path, layer = layer_name, quiet = TRUE)
names(cities) <- sub("^X\\.", "", names(cities))

if (!(CITY_ID_COL %in% names(cities))) {
  stop(paste0("城市图层中不存在字段：", CITY_ID_COL))
}

# 尝试识别城市名称字段；没有也不影响统计
candidate_city_cols <- c(
  "UC_NM_MN", "UC_NM_LST", "UC_NM_MAJ", "UC_NM",
  "UC_NM_EN", "UC_NAME", "NAME", "Name", "name",
  "city", "City", "CITY", "CITY_NAME", "NAME_LATN",
  "GRGN_L1", "GRGN_L2", "GRGN_L3"
)

city_name_col <- candidate_city_cols[candidate_city_cols %in% names(cities)][1]

if (is.na(city_name_col)) {
  cities <- cities %>%
    mutate(city_name = as.character(.data[[CITY_ID_COL]]))
} else {
  cities <- cities %>%
    mutate(
      city_name = as.character(.data[[city_name_col]]),
      city_name = ifelse(
        is.na(city_name) | city_name == "",
        as.character(.data[[CITY_ID_COL]]),
        city_name
      )
    )
}

# 尝试识别 ISO3
candidate_iso3_cols <- c(
  "CTR_MN_ISO", "CTR_ISO", "ISO3", "iso3",
  "CNTR_ID", "COUNTRY_ISO3", "GID_0"
)

iso3_col <- candidate_iso3_cols[candidate_iso3_cols %in% names(cities)][1]

if (is.na(iso3_col)) {
  cities <- cities %>%
    mutate(iso3 = NA_character_)
} else {
  cities <- cities %>%
    mutate(iso3 = str_to_upper(as.character(.data[[iso3_col]])))
}

geom_col <- attr(cities, "sf_column")

# =========================
# 5) Spatial join: plant -> GHS city unit
# =========================
plants_sf_proj <- st_transform(plants_sf, st_crs(cities))

plants_joined <- st_join(
  plants_sf_proj,
  cities[, c(CITY_ID_COL, "city_name", "iso3", geom_col)],
  join = st_within,
  left = FALSE
)

cat("原始电厂数：", nrow(plants_sf), "\n")
cat("成功匹配到 GHS 城市单元的电厂数：", nrow(plants_joined), "\n")

# =========================
# 6) City-level aggregation
# =========================
# 注意：
# city_loss = 城市内电厂 Productivity_loss 总和
# city_gdp_pc = 城市内电厂周边 GDP per capita 的人口加权平均
# city_vulnerable_share = 城市内电厂周边脆弱人口比例的人口加权平均

city_df <- plants_joined %>%
  st_drop_geometry() %>%
  group_by(.data[[CITY_ID_COL]], city_name, iso3) %>%
  summarise(
    n_plants = n(),
    pop_sum = sum(pop, na.rm = TRUE),
    
    city_loss = sum(loss, na.rm = TRUE),
    city_loss_mean = mean(loss, na.rm = TRUE),
    city_loss_median = median(loss, na.rm = TRUE),
    
    city_gdp_pc = weighted.mean(gdp_pc, w = pop, na.rm = TRUE),
    city_vulnerable_share = weighted.mean(vulnerable_ratio, w = pop, na.rm = TRUE),
    
    .groups = "drop"
  ) %>%
  filter(
    !is.na(city_loss),
    !is.na(city_gdp_pc),
    !is.na(city_vulnerable_share),
    pop_sum > 0
  )

write.csv(city_df, OUT_ALL, row.names = FALSE)

cat("城市单元数量：", nrow(city_df), "\n")

# =========================
# 7) City-level loss Q1 / Q4
# =========================
city_df_q <- city_df %>%
  mutate(
    city_loss_group_raw = ntile(city_loss, 4)
  ) %>%
  filter(city_loss_group_raw %in% c(1, 4)) %>%
  mutate(
    city_loss_group = case_when(
      city_loss_group_raw == 1 ~ "Q1\nlowest",
      city_loss_group_raw == 4 ~ "Q4\nhighest",
      TRUE ~ NA_character_
    ),
    city_loss_group = factor(
      city_loss_group,
      levels = c("Q1\nlowest", "Q4\nhighest")
    )
  )

# =========================
# 8) Winsorize plotting variables
# =========================
q01_gdp <- quantile(city_df_q$city_gdp_pc, 0.01, na.rm = TRUE)
q99_gdp <- quantile(city_df_q$city_gdp_pc, 0.99, na.rm = TRUE)

q01_vul <- quantile(city_df_q$city_vulnerable_share, 0.01, na.rm = TRUE)
q99_vul <- quantile(city_df_q$city_vulnerable_share, 0.99, na.rm = TRUE)

city_df_q <- city_df_q %>%
  mutate(
    gdp_plot = pmin(pmax(city_gdp_pc, q01_gdp), q99_gdp),
    vulnerable_plot = pmin(pmax(city_vulnerable_share, q01_vul), q99_vul)
  )

# =========================
# 9) Summary
# =========================
summary_tab <- city_df_q %>%
  group_by(city_loss_group) %>%
  summarise(
    n_city = n(),
    mean_city_loss = mean(city_loss, na.rm = TRUE),
    median_city_loss = median(city_loss, na.rm = TRUE),
    mean_city_gdp_pc = mean(city_gdp_pc, na.rm = TRUE),
    median_city_gdp_pc = median(city_gdp_pc, na.rm = TRUE),
    mean_city_vulnerable_share = mean(city_vulnerable_share, na.rm = TRUE),
    median_city_vulnerable_share = median(city_vulnerable_share, na.rm = TRUE),
    mean_n_plants = mean(n_plants, na.rm = TRUE),
    median_n_plants = median(n_plants, na.rm = TRUE),
    mean_pop_sum = mean(pop_sum, na.rm = TRUE),
    median_pop_sum = median(pop_sum, na.rm = TRUE),
    .groups = "drop"
  )

write.csv(summary_tab, OUT_CSV, row.names = FALSE)
print(summary_tab)

# =========================
# 10) Tests: Q4 vs Q1
# =========================
test_gdp <- wilcox.test(city_gdp_pc ~ city_loss_group, data = city_df_q)
test_vul <- wilcox.test(city_vulnerable_share ~ city_loss_group, data = city_df_q)

test_tab <- data.frame(
  variable = c("City GDP per capita", "City vulnerable population share"),
  p_value = c(test_gdp$p.value, test_vul$p.value)
) %>%
  mutate(
    signif = case_when(
      p_value < 0.001 ~ "***",
      p_value < 0.01  ~ "**",
      p_value < 0.05  ~ "*",
      TRUE            ~ "ns"
    )
  )

write.csv(test_tab, OUT_TEST, row.names = FALSE)
print(test_tab)

# =========================
# 11) Plot function
# =========================
group_pal <- c(
  "Q1\nlowest"  = "#D9EAF7",
  "Q4\nhighest" = "#D94801"
)

plot_city_loss_box <- function(dat, y_col, y_lab, y_is_percent = FALSE, p_label = "ns") {
  
  y_vals <- dat[[y_col]]
  y_min <- min(y_vals, na.rm = TRUE)
  y_max <- max(y_vals, na.rm = TRUE)
  y_rng <- y_max - y_min
  
  y_sig <- y_max + 0.08 * y_rng
  y_lim_max <- y_max + 0.18 * y_rng
  
  ggplot(dat, aes(x = city_loss_group, y = .data[[y_col]], fill = city_loss_group)) +
    
    geom_point(
      aes(size = n_plants),
      position = position_jitter(width = 0.13, height = 0, seed = 123),
      alpha = 0.34,
      color = "black",
      show.legend = FALSE
    ) +
    
    geom_boxplot(
      width = 0.42,
      outlier.shape = NA,
      color = "black",
      fill = "white",
      linewidth = 0.8
    ) +
    
    geom_boxplot(
      width = 0.42,
      outlier.shape = NA,
      alpha = 0.58,
      color = NA,
      show.legend = FALSE
    ) +
    
    geom_segment(
      aes(x = 1, xend = 2, y = y_sig, yend = y_sig),
      inherit.aes = FALSE,
      linewidth = 0.55
    ) +
    
    geom_segment(
      aes(x = 1, xend = 1, y = y_sig - 0.025 * y_rng, yend = y_sig),
      inherit.aes = FALSE,
      linewidth = 0.55
    ) +
    
    geom_segment(
      aes(x = 2, xend = 2, y = y_sig - 0.025 * y_rng, yend = y_sig),
      inherit.aes = FALSE,
      linewidth = 0.55
    ) +
    
    geom_text(
      aes(x = 1.5, y = y_sig + 0.035 * y_rng, label = p_label),
      inherit.aes = FALSE,
      size = 4.0,
      fontface = "bold"
    ) +
    
    scale_fill_manual(values = group_pal, drop = FALSE) +
    
    scale_size_continuous(range = c(1.2, 5.5)) +
    
    scale_y_continuous(
      labels = if (y_is_percent) {
        percent_format(accuracy = 1)
      } else {
        label_number(big.mark = ",", accuracy = 1)
      },
      limits = c(y_min, y_lim_max),
      expand = c(0, 0)
    ) +
    
    labs(
      x = NULL,
      y = y_lab
    ) +
    
    theme_bw(base_size = 12) +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 1),
      
      axis.text.x = element_text(size = 11),
      axis.text.y = element_text(size = 10.5),
      axis.title.x = element_text(size = 12),
      axis.title.y = element_text(size = 12),
      
      legend.position = "none",
      plot.margin = margin(6, 6, 6, 6)
    )
}

# =========================
# 12) Make panels
# =========================
p_vul <- plot_city_loss_box(
  dat = city_df_q,
  y_col = "vulnerable_plot",
  y_lab = "City vulnerable population share",
  y_is_percent = TRUE,
  p_label = test_tab$signif[test_tab$variable == "City vulnerable population share"]
)

p_gdp <- plot_city_loss_box(
  dat = city_df_q,
  y_col = "gdp_plot",
  y_lab = "City GDP per capita, 2019",
  y_is_percent = FALSE,
  p_label = test_tab$signif[test_tab$variable == "City GDP per capita"]
)

# =========================
# 13) Export standalone panels
# =========================
ggsave(
  OUT_VUL_SVG,
  p_vul,
  width = 4.0,
  height = 3.9,
  device = svglite::svglite
)

ggsave(
  OUT_VUL_PDF,
  p_vul,
  width = 4.0,
  height = 3.9
)

ggsave(
  OUT_GDP_SVG,
  p_gdp,
  width = 4.0,
  height = 3.9,
  device = svglite::svglite
)

ggsave(
  OUT_GDP_PDF,
  p_gdp,
  width = 4.0,
  height = 3.9
)

# =========================
# 14) Combined plot
# =========================
combined <- cowplot::plot_grid(
  p_vul,
  p_gdp,
  nrow = 1,
  labels = c("A", "B"),
  label_size = 13,
  align = "hv",
  axis = "tblr"
)

# =========================
# 15) Export combined
# =========================
ggsave(
  OUT_SVG,
  combined,
  width = 7.6,
  height = 3.9,
  device = svglite::svglite
)

ggsave(
  OUT_PDF,
  combined,
  width = 7.6,
  height = 3.9
)

cat("\nOutput:\n")
cat(OUT_VUL_SVG, "\n")
cat(OUT_GDP_SVG, "\n")
cat(OUT_SVG, "\n")
cat(OUT_PDF, "\n")
cat(OUT_CSV, "\n")
cat(OUT_TEST, "\n")
cat(OUT_ALL, "\n")