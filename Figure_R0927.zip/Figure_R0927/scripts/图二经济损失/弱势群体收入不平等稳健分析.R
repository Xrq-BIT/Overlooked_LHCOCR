suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(scales)
  library(cowplot)
  library(svglite)
})

excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"
out_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图二经济损失/不平等稳健分析"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

needed <- c(
  "gem_id", "gadm_iso3", "gadm_country", "city_gid", "city",
  "All_loss_annual_mean_LSM_10km",
  "Productivity_loss_annual_10km_lsm_worldpop2020",
  "Deaths_mean_2011_2020_LSM_all_years",
  "pop_10km_total_worldpop2020",
  "ratio_10km_child_worldpop2020",
  "ratio_10km_old_worldpop2020",
  "GDP_per_capita_2019", "labsh_2011_2020_mean",
  "lsm_delta_t2_mean_c"
)

raw <- read_excel(excel_path)
missing <- setdiff(needed, names(raw))
if (length(missing) > 0) stop("Missing columns: ", paste(missing, collapse = ", "))

dat <- raw %>%
  transmute(
    gem_id = as.character(gem_id),
    country = as.character(gadm_iso3),
    country_name = as.character(gadm_country),
    city_id = as.character(city_gid),
    city_name = as.character(city),
    total_loss = suppressWarnings(as.numeric(All_loss_annual_mean_LSM_10km)),
    productivity_loss = suppressWarnings(as.numeric(Productivity_loss_annual_10km_lsm_worldpop2020)),
    deaths = suppressWarnings(as.numeric(Deaths_mean_2011_2020_LSM_all_years)),
    pop = suppressWarnings(as.numeric(pop_10km_total_worldpop2020)),
    child_share = suppressWarnings(as.numeric(ratio_10km_child_worldpop2020)),
    old_share = suppressWarnings(as.numeric(ratio_10km_old_worldpop2020)),
    gdp_pc = suppressWarnings(as.numeric(GDP_per_capita_2019)),
    labsh = suppressWarnings(as.numeric(labsh_2011_2020_mean)),
    delta_t = suppressWarnings(as.numeric(lsm_delta_t2_mean_c))
  ) %>%
  mutate(
    vulnerable_share = child_share + old_share,
    vulnerable_pop = pop * vulnerable_share,
    economic_base = pop * gdp_pc * labsh,
    total_loss_per_capita = total_loss / pop,
    productivity_loss_intensity = productivity_loss / economic_base,
    deaths_per_100k = deaths / pop * 100000
  ) %>%
  filter(
    is.finite(total_loss), is.finite(productivity_loss), is.finite(deaths),
    is.finite(pop), pop > 0,
    is.finite(vulnerable_share),
    is.finite(gdp_pc), gdp_pc > 0,
    is.finite(labsh), labsh > 0,
    is.finite(delta_t), delta_t >= 0,
    is.finite(productivity_loss_intensity),
    is.finite(deaths_per_100k)
  ) %>%
  mutate(
    vulnerable_percentile = percent_rank(vulnerable_share),
    income_disadvantage_percentile = 1 - percent_rank(gdp_pc),
    compound_vulnerability = (vulnerable_percentile + income_disadvantage_percentile) / 2,
    compound_quartile = ntile(compound_vulnerability, 4),
    compound_group = factor(
      compound_quartile,
      levels = 1:4,
      labels = c("Q1\nleast vulnerable", "Q2", "Q3", "Q4\nmost vulnerable")
    ),
    productivity_intensity_pct = productivity_loss_intensity * 100
  )

write.csv(dat, file.path(out_dir, "plant_inequality_analysis_data.csv"), row.names = FALSE)

metric_labels <- c(
  productivity_intensity_pct = "Productivity loss intensity (% of local labour income)",
  deaths_per_100k = "Plant-attributable excess deaths per 100,000 residents",
  delta_t = "LSM-estimated 10 km warming (°C)"
)

quartile_summary <- bind_rows(lapply(names(metric_labels), function(metric) {
  dat %>%
    group_by(compound_quartile, compound_group) %>%
    summarise(
      metric = metric,
      n = sum(!is.na(.data[[metric]])),
      q25 = quantile(.data[[metric]], 0.25, na.rm = TRUE),
      median = median(.data[[metric]], na.rm = TRUE),
      q75 = quantile(.data[[metric]], 0.75, na.rm = TRUE),
      mean = mean(.data[[metric]], na.rm = TRUE),
      .groups = "drop"
    )
}))
write.csv(quartile_summary, file.path(out_dir, "compound_vulnerability_quartile_summary.csv"), row.names = FALSE)

compound_tests <- bind_rows(lapply(names(metric_labels), function(metric) {
  test_dat <- dat %>% filter(compound_quartile %in% c(1, 4), !is.na(.data[[metric]]))
  q1 <- test_dat %>% filter(compound_quartile == 1) %>% pull(.data[[metric]])
  q4 <- test_dat %>% filter(compound_quartile == 4) %>% pull(.data[[metric]])
  test <- wilcox.test(q4, q1, exact = FALSE)
  data.frame(
    metric = metric,
    n_q1 = length(q1),
    n_q4 = length(q4),
    median_q1 = median(q1, na.rm = TRUE),
    median_q4 = median(q4, na.rm = TRUE),
    median_ratio_q4_q1 = ifelse(median(q1, na.rm = TRUE) == 0, NA_real_, median(q4, na.rm = TRUE) / median(q1, na.rm = TRUE)),
    p_value = test$p.value
  )
}))
write.csv(compound_tests, file.path(out_dir, "compound_vulnerability_Q1_Q4_tests.csv"), row.names = FALSE)

make_panel <- function(metric, panel_label, sigma_value) {
  panel_dat <- quartile_summary %>% filter(.data$metric == .env$metric)
  test_row <- compound_tests %>% filter(.data$metric == .env$metric)
  ratio_text <- if (is.finite(test_row$median_ratio_q4_q1) && test_row$median_ratio_q4_q1 < 100) {
    paste0("Q4/Q1 median = ", number(test_row$median_ratio_q4_q1, accuracy = 0.1), "×")
  } else {
    "Q4 median > Q1 median"
  }
  p_text <- if (test_row$p_value < 0.001) "p < 0.001" else paste0("p = ", number(test_row$p_value, accuracy = 0.001))
  break_values <- switch(
    metric,
    productivity_intensity_pct = c(0, 0.000001, 0.0001, 0.01, 0.1),
    deaths_per_100k = c(0, 0.02, 0.05, 0.1, 0.2),
    delta_t = c(0, 0.02, 0.04, 0.08),
    waiver()
  )

  ggplot(panel_dat, aes(compound_group, median, group = 1)) +
    geom_line(linewidth = 0.7, color = "#555555") +
    geom_linerange(aes(ymin = q25, ymax = q75), linewidth = 1.1, color = "#333333") +
    geom_point(aes(fill = compound_quartile), shape = 21, size = 4.0, color = "black", stroke = 0.65) +
    scale_fill_gradient(low = "#D9EAF7", high = "#D94801", guide = "none") +
    scale_y_continuous(
      trans = pseudo_log_trans(base = 10, sigma = sigma_value),
      breaks = break_values,
      labels = label_number(accuracy = 0.000001)
    ) +
    labs(title = panel_label, x = NULL, y = metric_labels[[metric]], subtitle = paste(ratio_text, p_text, sep = "; ")) +
    theme_bw(base_size = 11.5) +
    theme(
      panel.grid.minor = element_blank(),
      panel.grid.major.x = element_blank(),
      panel.border = element_rect(color = "black", linewidth = 0.8),
      axis.text.x = element_text(size = 9.5),
      axis.title.y = element_text(size = 10.5),
      plot.title = element_text(size = 16, face = "bold", hjust = 0),
      plot.subtitle = element_text(size = 9.5, color = "#444444"),
      plot.margin = margin(8, 8, 8, 8)
    )
}

p_a <- make_panel("productivity_intensity_pct", "A", 1e-7)
p_b <- make_panel("deaths_per_100k", "B", 0.001)
p_c <- make_panel("delta_t", "C", 0.001)

figure <- plot_grid(
  p_a, p_b, p_c,
  nrow = 1,
  rel_widths = c(1, 1, 1)
)

ggsave(file.path(out_dir, "compound_vulnerability_burden.pdf"), figure, width = 12.5, height = 4.2, device = grDevices::pdf)
ggsave(file.path(out_dir, "compound_vulnerability_burden.svg"), figure, width = 12.5, height = 4.2, device = svglite::svglite)

separate_tests <- bind_rows(lapply(c("vulnerable_share", "gdp_pc"), function(group_var) {
  group_dat <- dat %>% mutate(group_quartile = ntile(.data[[group_var]], 4))
  bind_rows(lapply(c(
    "total_loss", "total_loss_per_capita", "productivity_loss_intensity",
    "deaths", "deaths_per_100k", "delta_t"
  ), function(metric) {
    q1 <- group_dat %>% filter(group_quartile == 1) %>% pull(.data[[metric]])
    q4 <- group_dat %>% filter(group_quartile == 4) %>% pull(.data[[metric]])
    test <- wilcox.test(q4, q1, exact = FALSE)
    data.frame(
      grouping_variable = group_var,
      outcome = metric,
      q1_definition = ifelse(group_var == "gdp_pc", "lowest income quartile", "lowest vulnerable-share quartile"),
      q4_definition = ifelse(group_var == "gdp_pc", "highest income quartile", "highest vulnerable-share quartile"),
      n_q1 = length(q1), n_q4 = length(q4),
      median_q1 = median(q1, na.rm = TRUE),
      median_q4 = median(q4, na.rm = TRUE),
      p_value = test$p.value
    )
  }))
}))
write.csv(separate_tests, file.path(out_dir, "separate_income_vulnerability_Q1_Q4_tests.csv"), row.names = FALSE)

burden_shares <- bind_rows(
  dat %>% mutate(group = ntile(gdp_pc, 4), dimension = "income") %>%
    group_by(dimension, group) %>%
    summarise(n = n(), loss = sum(total_loss), deaths = sum(deaths), pop = sum(pop), vulnerable_pop = sum(vulnerable_pop), .groups = "drop"),
  dat %>% mutate(group = ntile(vulnerable_share, 4), dimension = "vulnerable_share") %>%
    group_by(dimension, group) %>%
    summarise(n = n(), loss = sum(total_loss), deaths = sum(deaths), pop = sum(pop), vulnerable_pop = sum(vulnerable_pop), .groups = "drop")
) %>%
  group_by(dimension) %>%
  mutate(
    loss_share = loss / sum(loss),
    death_share = deaths / sum(deaths),
    population_share = pop / sum(pop),
    vulnerable_population_share = vulnerable_pop / sum(vulnerable_pop)
  ) %>%
  ungroup()
write.csv(burden_shares, file.path(out_dir, "burden_shares_by_income_and_vulnerability_quartile.csv"), row.names = FALSE)

# City aggregation is facility-attributed: overlapping 10 km exposure areas are not deduplicated.
city_dat <- dat %>%
  filter(!is.na(city_id), city_id != "") %>%
  group_by(city_id, city_name, country) %>%
  summarise(
    n_plants = n(),
    pop_exposure_sum = sum(pop),
    economic_base_sum = sum(economic_base),
    productivity_loss_sum = sum(productivity_loss),
    deaths_sum = sum(deaths),
    total_loss_sum = sum(total_loss),
    vulnerable_share = weighted.mean(vulnerable_share, pop),
    gdp_pc = weighted.mean(gdp_pc, pop),
    delta_t = weighted.mean(delta_t, pop),
    .groups = "drop"
  ) %>%
  mutate(
    productivity_loss_intensity = productivity_loss_sum / economic_base_sum,
    deaths_per_100k = deaths_sum / pop_exposure_sum * 100000,
    vulnerable_percentile = percent_rank(vulnerable_share),
    income_disadvantage_percentile = 1 - percent_rank(gdp_pc),
    compound_vulnerability = (vulnerable_percentile + income_disadvantage_percentile) / 2,
    compound_quartile = ntile(compound_vulnerability, 4),
    aggregation_note = "Facility-attributed city aggregation; overlapping 10 km exposure areas are not deduplicated"
  )
write.csv(city_dat, file.path(out_dir, "city_facility_attributed_inequality_data.csv"), row.names = FALSE)

city_tests <- bind_rows(lapply(c("productivity_loss_intensity", "deaths_per_100k", "delta_t"), function(metric) {
  q1 <- city_dat %>% filter(compound_quartile == 1) %>% pull(.data[[metric]])
  q4 <- city_dat %>% filter(compound_quartile == 4) %>% pull(.data[[metric]])
  test <- wilcox.test(q4, q1, exact = FALSE)
  data.frame(
    metric = metric, n_q1 = length(q1), n_q4 = length(q4),
    median_q1 = median(q1, na.rm = TRUE), median_q4 = median(q4, na.rm = TRUE),
    p_value = test$p.value,
    aggregation_note = "Facility-attributed city aggregation; overlapping 10 km exposure areas are not deduplicated"
  )
}))
write.csv(city_tests, file.path(out_dir, "city_compound_vulnerability_Q1_Q4_tests.csv"), row.names = FALSE)

cat("plant_rows=", nrow(dat), "\n", sep = "")
cat("city_rows=", nrow(city_dat), "\n", sep = "")
print(compound_tests)
print(city_tests)
