# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(scales)
  library(svglite)
  library(cowplot)
})

# =========================
# 1) Config
# =========================
excel_path <- paste0(
  "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"
)

LOSS_COL  <- "All_loss_annual_mean_LSM_10km"
POP_COL   <- "pop_10km_total_worldpop2020"
CHILD_COL <- "ratio_10km_child_worldpop2020"
OLD_COL   <- "ratio_10km_old_worldpop2020"
GDP_COL   <- "GDP_per_capita_2019"

out_dir <- "plant_level_loss_Q1_Q4_boxplots"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

OUT_SVG <- file.path(
  out_dir,
  "plant_loss_Q1_Q4_vulnerable_gdp_boxplots.svg"
)

OUT_PDF <- file.path(
  out_dir,
  "plant_loss_Q1_Q4_vulnerable_gdp_boxplots.pdf"
)

# 单独导出两个子图
OUT_VUL_SVG <- file.path(
  out_dir,
  "plant_loss_Q1_Q4_vulnerable_boxplot.svg"
)

OUT_VUL_PDF <- file.path(
  out_dir,
  "plant_loss_Q1_Q4_vulnerable_boxplot.pdf"
)

OUT_GDP_SVG <- file.path(
  out_dir,
  "plant_loss_Q1_Q4_gdp_boxplot.svg"
)

OUT_GDP_PDF <- file.path(
  out_dir,
  "plant_loss_Q1_Q4_gdp_boxplot.pdf"
)

OUT_CSV <- file.path(
  out_dir,
  "plant_loss_Q1_Q4_summary.csv"
)

OUT_TEST <- file.path(
  out_dir,
  "plant_loss_Q1_Q4_tests.csv"
)

OUT_ALL <- file.path(
  out_dir,
  "plant_level_loss_all.csv"
)

# =========================
# 2) Read and prepare
# =========================
df_raw <- read_excel(excel_path)

need_cols <- c(
  LOSS_COL,
  POP_COL,
  CHILD_COL,
  OLD_COL,
  GDP_COL
)

if (!all(need_cols %in% names(df_raw))) {
  stop(
    "缺少必要列：",
    paste(
      setdiff(need_cols, names(df_raw)),
      collapse = ", "
    )
  )
}

df <- df_raw %>%
  transmute(
    loss = suppressWarnings(
      as.numeric(.data[[LOSS_COL]])
    ),
    
    pop = suppressWarnings(
      as.numeric(.data[[POP_COL]])
    ),
    
    child_ratio = suppressWarnings(
      as.numeric(.data[[CHILD_COL]])
    ),
    
    old_ratio = suppressWarnings(
      as.numeric(.data[[OLD_COL]])
    ),
    
    gdp_pc = suppressWarnings(
      as.numeric(.data[[GDP_COL]])
    )
  ) %>%
  mutate(
    vulnerable_ratio = child_ratio + old_ratio
  ) %>%
  filter(
    !is.na(loss),
    !is.na(pop),
    pop > 0,
    
    !is.na(vulnerable_ratio),
    
    !is.na(gdp_pc),
    gdp_pc > 0
  )

write.csv(
  df,
  OUT_ALL,
  row.names = FALSE
)

cat("有效电厂数：", nrow(df), "\n")

# =========================
# 3) Loss Q1 / Q4 groups
# =========================
df_q <- df %>%
  mutate(
    loss_group_raw = ntile(loss, 4)
  ) %>%
  filter(
    loss_group_raw %in% c(1, 4)
  ) %>%
  mutate(
    loss_group = case_when(
      loss_group_raw == 1 ~ "Q1\nlowest",
      loss_group_raw == 4 ~ "Q4\nhighest",
      TRUE ~ NA_character_
    ),
    
    loss_group = factor(
      loss_group,
      levels = c(
        "Q1\nlowest",
        "Q4\nhighest"
      )
    )
  )

cat(
  "Q1 和 Q4 电厂总数：",
  nrow(df_q),
  "\n"
)

print(
  table(df_q$loss_group)
)

# =========================
# 4) Winsorize plotting variables
# =========================
# 这里只处理作图变量。
# 统计检验仍然使用原始变量。

q01_gdp <- quantile(
  df_q$gdp_pc,
  probs = 0.01,
  na.rm = TRUE
)

q99_gdp <- quantile(
  df_q$gdp_pc,
  probs = 0.99,
  na.rm = TRUE
)

q01_vul <- quantile(
  df_q$vulnerable_ratio,
  probs = 0.01,
  na.rm = TRUE
)

q99_vul <- quantile(
  df_q$vulnerable_ratio,
  probs = 0.99,
  na.rm = TRUE
)

df_q <- df_q %>%
  mutate(
    gdp_plot = pmin(
      pmax(gdp_pc, q01_gdp),
      q99_gdp
    ),
    
    vulnerable_plot = pmin(
      pmax(vulnerable_ratio, q01_vul),
      q99_vul
    )
  )

# =========================
# 5) Summary
# =========================
summary_tab <- df_q %>%
  group_by(loss_group) %>%
  summarise(
    n_plant = n(),
    
    mean_loss = mean(
      loss,
      na.rm = TRUE
    ),
    
    median_loss = median(
      loss,
      na.rm = TRUE
    ),
    
    mean_gdp_pc = mean(
      gdp_pc,
      na.rm = TRUE
    ),
    
    median_gdp_pc = median(
      gdp_pc,
      na.rm = TRUE
    ),
    
    mean_vulnerable_share = mean(
      vulnerable_ratio,
      na.rm = TRUE
    ),
    
    median_vulnerable_share = median(
      vulnerable_ratio,
      na.rm = TRUE
    ),
    
    mean_pop = mean(
      pop,
      na.rm = TRUE
    ),
    
    median_pop = median(
      pop,
      na.rm = TRUE
    ),
    
    .groups = "drop"
  )

write.csv(
  summary_tab,
  OUT_CSV,
  row.names = FALSE
)

print(summary_tab)

# =========================
# 6) Tests: Q4 versus Q1
# =========================
test_gdp <- wilcox.test(
  gdp_pc ~ loss_group,
  data = df_q,
  exact = FALSE
)

test_vul <- wilcox.test(
  vulnerable_ratio ~ loss_group,
  data = df_q,
  exact = FALSE
)

test_tab <- data.frame(
  variable = c(
    "GDP per capita",
    "Vulnerable population share"
  ),
  
  p_value = c(
    test_gdp$p.value,
    test_vul$p.value
  )
) %>%
  mutate(
    signif = case_when(
      p_value < 0.001 ~ "***",
      p_value < 0.01  ~ "**",
      p_value < 0.05  ~ "*",
      TRUE            ~ "ns"
    )
  )

write.csv(
  test_tab,
  OUT_TEST,
  row.names = FALSE
)

print(test_tab)

# =========================
# 7) Plot settings
# =========================
group_pal <- c(
  "Q1\nlowest"  = "#D9EAF7",
  "Q4\nhighest" = "#E97F5F"
)

# 散点参数
POINT_SIZE  <- 0.70
POINT_ALPHA <- 0.10
POINT_COLOR <- "grey20"
JITTER_W    <- 0.16

# 箱线图参数
BOX_WIDTH <- 0.42

# =========================
# 8) Plot function
# =========================
plot_loss_box <- function(
    dat,
    y_col,
    y_lab,
    y_is_percent = FALSE,
    p_label = "ns"
) {
  
  y_vals <- dat[[y_col]]
  
  y_min <- min(
    y_vals,
    na.rm = TRUE
  )
  
  y_max <- max(
    y_vals,
    na.rm = TRUE
  )
  
  y_rng <- y_max - y_min
  
  # 防止所有数值相同导致纵轴范围为 0
  if (
    !is.finite(y_rng) ||
    y_rng <= 0
  ) {
    y_rng <- max(
      abs(y_max),
      1
    ) * 0.1
  }
  
  # 显著性标记位置
  y_sig <- y_max + 0.08 * y_rng
  
  y_tick_bottom <- y_sig - 0.025 * y_rng
  
  y_text <- y_sig + 0.035 * y_rng
  
  y_lim_max <- y_max + 0.18 * y_rng
  
  ggplot(
    dat,
    aes(
      x = loss_group,
      y = .data[[y_col]],
      fill = loss_group
    )
  ) +
    
    # -------------------------
  # 1. 原始电厂散点
  # -------------------------
  geom_point(
    position = position_jitter(
      width = JITTER_W,
      height = 0,
      seed = 123
    ),
    
    size = POINT_SIZE,
    alpha = POINT_ALPHA,
    color = POINT_COLOR,
    shape = 16,
    stroke = 0,
    show.legend = FALSE
  ) +
    
    # -------------------------
  # 2. 箱线图白色底层
  # -------------------------
  geom_boxplot(
    width = BOX_WIDTH,
    outlier.shape = NA,
    color = "black",
    fill = "white",
    linewidth = 0.75
  ) +
    
    # -------------------------
  # 3. 箱线图彩色填充层
  # -------------------------
  geom_boxplot(
    width = BOX_WIDTH,
    outlier.shape = NA,
    alpha = 0.62,
    color = NA,
    linewidth = 0,
    show.legend = FALSE
  ) +
    
    # -------------------------
  # 4. 显著性横线
  # -------------------------
  geom_segment(
    data = data.frame(
      x = 1,
      xend = 2,
      y = y_sig,
      yend = y_sig
    ),
    
    aes(
      x = x,
      xend = xend,
      y = y,
      yend = yend
    ),
    
    inherit.aes = FALSE,
    linewidth = 0.55,
    color = "black"
  ) +
    
    # 显著性左侧短竖线
    geom_segment(
      data = data.frame(
        x = 1,
        xend = 1,
        y = y_tick_bottom,
        yend = y_sig
      ),
      
      aes(
        x = x,
        xend = xend,
        y = y,
        yend = yend
      ),
      
      inherit.aes = FALSE,
      linewidth = 0.55,
      color = "black"
    ) +
    
    # 显著性右侧短竖线
    geom_segment(
      data = data.frame(
        x = 2,
        xend = 2,
        y = y_tick_bottom,
        yend = y_sig
      ),
      
      aes(
        x = x,
        xend = xend,
        y = y,
        yend = yend
      ),
      
      inherit.aes = FALSE,
      linewidth = 0.55,
      color = "black"
    ) +
    
    # 显著性文字
    annotate(
      geom = "text",
      x = 1.5,
      y = y_text,
      label = p_label,
      size = 4.0,
      fontface = "bold",
      color = "black"
    ) +
    
    # -------------------------
  # 5. Color scale
  # -------------------------
  scale_fill_manual(
    values = group_pal,
    drop = FALSE
  ) +
    
    # -------------------------
  # 6. Y axis
  # -------------------------
  scale_y_continuous(
    labels = if (y_is_percent) {
      
      percent_format(
        accuracy = 1
      )
      
    } else {
      
      label_number(
        big.mark = ",",
        accuracy = 1
      )
    },
    
    limits = c(
      y_min,
      y_lim_max
    ),
    
    expand = expansion(
      mult = c(0, 0)
    )
  ) +
    
    # -------------------------
  # 7. Labels
  # -------------------------
  labs(
    x = NULL,
    y = y_lab
  ) +
    
    # -------------------------
  # 8. Theme
  # -------------------------
  theme_bw(
    base_size = 12
  ) +
    
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      
      panel.border = element_rect(
        color = "black",
        fill = NA,
        linewidth = 0.85
      ),
      
      axis.line = element_blank(),
      
      axis.ticks = element_line(
        color = "grey30",
        linewidth = 0.45
      ),
      
      axis.ticks.length = unit(
        1.8,
        "mm"
      ),
      
      axis.text.x = element_text(
        size = 11,
        color = "grey25",
        lineheight = 0.95,
        margin = margin(
          t = 4
        )
      ),
      
      axis.text.y = element_text(
        size = 10.5,
        color = "grey25"
      ),
      
      axis.title.x = element_blank(),
      
      axis.title.y = element_text(
        size = 12,
        color = "black",
        margin = margin(
          r = 7
        )
      ),
      
      legend.position = "none",
      
      plot.margin = margin(
        t = 7,
        r = 7,
        b = 7,
        l = 7
      )
    )
}

# =========================
# 9) Make panels
# =========================
p_vul <- plot_loss_box(
  dat = df_q,
  y_col = "vulnerable_plot",
  y_lab = "Vulnerable population share",
  y_is_percent = TRUE,
  
  p_label = test_tab$signif[
    test_tab$variable ==
      "Vulnerable population share"
  ]
)

p_gdp <- plot_loss_box(
  dat = df_q,
  y_col = "gdp_plot",
  y_lab = "GDP per capita, 2019",
  y_is_percent = FALSE,
  
  p_label = test_tab$signif[
    test_tab$variable ==
      "GDP per capita"
  ]
)

# =========================
# 10) Export standalone panels
# =========================
ggsave(
  filename = OUT_VUL_SVG,
  plot = p_vul,
  width = 4.0,
  height = 3.9,
  device = svglite::svglite
)

ggsave(
  filename = OUT_VUL_PDF,
  plot = p_vul,
  width = 4.0,
  height = 3.9
)

ggsave(
  filename = OUT_GDP_SVG,
  plot = p_gdp,
  width = 4.0,
  height = 3.9,
  device = svglite::svglite
)

ggsave(
  filename = OUT_GDP_PDF,
  plot = p_gdp,
  width = 4.0,
  height = 3.9
)

# =========================
# 11) Combined plot
# =========================
combined <- cowplot::plot_grid(
  p_vul,
  p_gdp,
  
  nrow = 1,
  
  labels = c(
    "A",
    "B"
  ),
  
  label_size = 13,
  label_fontface = "bold",
  
  align = "hv",
  axis = "tblr",
  
  rel_widths = c(
    1,
    1
  )
)

# =========================
# 12) Export combined
# =========================
ggsave(
  filename = OUT_SVG,
  plot = combined,
  width = 7.6,
  height = 3.9,
  device = svglite::svglite
)

ggsave(
  filename = OUT_PDF,
  plot = combined,
  width = 7.6,
  height = 3.9
)

# =========================
# 13) Output paths
# =========================
cat("\n输出完成：\n")

cat(
  "Vulnerable SVG:\n",
  OUT_VUL_SVG,
  "\n\n"
)

cat(
  "Vulnerable PDF:\n",
  OUT_VUL_PDF,
  "\n\n"
)

cat(
  "GDP SVG:\n",
  OUT_GDP_SVG,
  "\n\n"
)

cat(
  "GDP PDF:\n",
  OUT_GDP_PDF,
  "\n\n"
)

cat(
  "Combined SVG:\n",
  OUT_SVG,
  "\n\n"
)

cat(
  "Combined PDF:\n",
  OUT_PDF,
  "\n\n"
)

cat(
  "Summary CSV:\n",
  OUT_CSV,
  "\n\n"
)

cat(
  "Test CSV:\n",
  OUT_TEST,
  "\n\n"
)

cat(
  "All valid observations CSV:\n",
  OUT_ALL,
  "\n"
)