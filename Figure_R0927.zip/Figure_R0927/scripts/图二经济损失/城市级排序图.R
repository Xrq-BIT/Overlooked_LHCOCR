suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(svglite)
  library(stringr)
  library(forcats)
  library(scales)
})

excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"
out_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图二经济损失/admin2_total_lifecycle_loss_ranking"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

OUT_CSV <- file.path(out_dir, "admin2_total_lifecycle_loss_ranking_all.csv")
OUT_TOP_CSV <- file.path(out_dir, "admin2_total_lifecycle_loss_ranking_top15.csv")
OUT_SVG <- file.path(out_dir, "admin2_total_lifecycle_loss_top15_MUSD.svg")
OUT_PDF <- file.path(out_dir, "admin2_total_lifecycle_loss_top15_MUSD.pdf")

VAL_COL <- "All_loss_lifecycle_60yr_LSM_10km"
CITY_COL <- "gadm_admin2"
ISO3_COL <- "gadm_iso3"
TOP_N <- 15
DISPLAY_MAX_CHARS <- 25

df_raw <- read_excel(excel_path)
need_cols <- c(VAL_COL, CITY_COL, ISO3_COL)
if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

df <- df_raw %>%
  transmute(
    admin2_raw = str_squish(as.character(.data[[CITY_COL]])),
    iso3 = str_to_upper(str_trim(as.character(.data[[ISO3_COL]]))),
    loss_usd = suppressWarnings(as.numeric(.data[[VAL_COL]]))
  ) %>%
  mutate(
    admin2_raw = ifelse(
      is.na(admin2_raw) | admin2_raw == "" |
        str_to_lower(admin2_raw) %in% c("unknown", "na", "n/a", "none", "null"),
      NA_character_, admin2_raw
    ),
    iso3 = ifelse(
      is.na(iso3) | iso3 == "" |
        str_to_lower(iso3) %in% c("unknown", "na", "n/a", "none", "null"),
      NA_character_, iso3
    ),
    # Follow the project convention used by the mitigation city ranking.
    iso3 = ifelse(iso3 %in% c("TWN", "TWM", "HKG", "MAC"), "CHN", iso3)
  ) %>%
  filter(!is.na(admin2_raw), !is.na(iso3), is.finite(loss_usd))

city_rank <- df %>%
  group_by(admin2_raw, iso3) %>%
  summarise(
    total_loss_usd = sum(loss_usd, na.rm = TRUE),
    total_loss_musd = total_loss_usd / 1e6,
    mean_plant_loss_musd = mean(loss_usd, na.rm = TRUE) / 1e6,
    plant_count = n(),
    .groups = "drop"
  ) %>%
  mutate(
    admin2_short = str_trunc(admin2_raw, width = DISPLAY_MAX_CHARS, side = "right"),
    city_label = paste0(admin2_short, ", ", iso3)
  ) %>%
  arrange(desc(total_loss_musd)) %>%
  mutate(rank = row_number())

write.csv(city_rank, OUT_CSV, row.names = FALSE)

top_city <- city_rank %>%
  slice_head(n = TOP_N) %>%
  mutate(city_plot = fct_reorder(city_label, total_loss_musd))

write.csv(top_city, OUT_TOP_CSV, row.names = FALSE)

cat("有效电厂记录数：", nrow(df), "\n")
cat("唯一 GADM admin2 单元数：", nrow(city_rank), "\n")
cat("\nTop admin2 units:\n")
print(
  top_city %>%
    select(rank, admin2_raw, iso3, total_loss_musd, plant_count),
  n = TOP_N
)

p <- ggplot(top_city, aes(total_loss_musd, city_plot)) +
  geom_col(fill = "#C75D3A", alpha = 0.85, width = 0.68) +
  geom_point(
    aes(size = plant_count), color = "black", fill = "white",
    shape = 21, stroke = 0.45, alpha = 0.95
  ) +
  geom_text(
    aes(label = paste0(label_number(big.mark = ",", accuracy = 0.1)(total_loss_musd), " M")),
    hjust = -0.08, size = 2.8
  ) +
  scale_x_continuous(
    labels = label_number(big.mark = ",", accuracy = 0.1),
    expand = expansion(mult = c(0, 0.22))
  ) +
  scale_size_continuous(
    range = c(2.0, 6.0),
    breaks = c(1, 5, 10, 20, 50, 100),
    name = "Plant count"
  ) +
  labs(x = "Total lifecycle loss (M USD)", y = NULL) +
  theme_bw(base_size = 12) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 0.8),
    axis.text.y = element_text(size = 8.8, color = "grey25"),
    axis.text.x = element_text(size = 10, color = "grey25"),
    axis.title.x = element_text(size = 11.5),
    axis.ticks = element_line(color = "grey35", linewidth = 0.35),
    axis.ticks.length = unit(2, "mm"),
    legend.position = "inside",
    legend.position.inside = c(0.98, 0.03),
    legend.justification = c(1, 0),
    legend.background = element_rect(fill = "white", color = "black", linewidth = 0.4),
    legend.title = element_text(size = 8.8),
    legend.text = element_text(size = 8),
    plot.margin = margin(6, 26, 6, 6)
  )

ggsave(OUT_SVG, p, width = 5.4, height = 4.8, device = svglite::svglite)
ggsave(OUT_PDF, p, width = 5.4, height = 4.8)

message(
  "Done!\n",
  "- ", OUT_CSV, "\n",
  "- ", OUT_TOP_CSV, "\n",
  "- ", OUT_SVG, "\n",
  "- ", OUT_PDF
)
