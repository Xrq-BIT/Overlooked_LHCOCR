# Plant-level Q1/Q4 comparison based on LSM 10-km local warming.
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(scales)
  library(svglite)
  library(cowplot)
})

excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"
out_dir <- paste0(
  "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图一温差统计/",
  "plant_level_vulnerability_income_Q1_Q4_deltT_welch"
)
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

DT_COL <- "lsm_delta_t2_mean_c"
CHILD_COL <- "ratio_10km_child_worldpop2020"
OLD_COL <- "ratio_10km_old_worldpop2020"
GDP_COL <- "GDP_per_capita_2019"

df_raw <- read_excel(excel_path)
need_cols <- c(DT_COL, CHILD_COL, OLD_COL, GDP_COL)
if (!all(need_cols %in% names(df_raw))) {
  stop("Missing columns: ", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

# Define Delta T quartiles before outcome-specific missing-value exclusion.
df <- df_raw %>%
  transmute(
    deltT = suppressWarnings(as.numeric(.data[[DT_COL]])),
    child_ratio = suppressWarnings(as.numeric(.data[[CHILD_COL]])),
    old_ratio = suppressWarnings(as.numeric(.data[[OLD_COL]])),
    gdp_pc = suppressWarnings(as.numeric(.data[[GDP_COL]]))
  ) %>%
  filter(is.finite(deltT)) %>%
  mutate(
    vulnerable_ratio = child_ratio + old_ratio,
    quartile = ntile(deltT, 4),
    deltT_group = case_when(
      quartile == 1L ~ "ΔT Q1 (lowest)",
      quartile == 4L ~ "ΔT Q4 (highest)",
      TRUE ~ NA_character_
    ),
    deltT_group = factor(deltT_group, levels = c("ΔT Q1 (lowest)", "ΔT Q4 (highest)"))
  ) %>%
  filter(quartile %in% c(1L, 4L))

df_vul <- df %>% filter(is.finite(vulnerable_ratio))
df_gdp <- df %>% filter(is.finite(gdp_pc), gdp_pc > 0)

welch_result <- function(dat, outcome, label) {
  f <- reformulate("deltT_group", response = outcome)
  test <- t.test(f, data = dat, var.equal = FALSE, alternative = "two.sided")
  values <- split(dat[[outcome]], dat$deltT_group)
  p <- unname(test$p.value)
  data.frame(
    variable = label,
    test = "Two-sided Welch t-test",
    q1_n = length(values[["ΔT Q1 (lowest)"]]),
    q4_n = length(values[["ΔT Q4 (highest)"]]),
    q1_mean = mean(values[["ΔT Q1 (lowest)"]]),
    q4_mean = mean(values[["ΔT Q4 (highest)"]]),
    q4_minus_q1 = mean(values[["ΔT Q4 (highest)"]]) - mean(values[["ΔT Q1 (lowest)"]]),
    # t.test reports Q1 - Q4 because of the factor order; reverse to Q4 - Q1.
    ci_low = -unname(test$conf.int[2]),
    ci_high = -unname(test$conf.int[1]),
    statistic = -unname(test$statistic),
    df = unname(test$parameter),
    p_value = p,
    significance = case_when(
      p < 0.001 ~ "***",
      p < 0.01 ~ "**",
      p < 0.05 ~ "*",
      TRUE ~ "ns"
    )
  )
}

tests <- bind_rows(
  welch_result(df_vul, "vulnerable_ratio", "Vulnerable population share"),
  welch_result(df_gdp, "gdp_pc", "GDP per capita")
)

summary_table <- bind_rows(
  df_vul %>%
    group_by(deltT_group) %>%
    summarise(variable = "Vulnerable population share", n = n(), mean = mean(vulnerable_ratio),
              median = median(vulnerable_ratio), q25 = quantile(vulnerable_ratio, 0.25),
              q75 = quantile(vulnerable_ratio, 0.75), .groups = "drop"),
  df_gdp %>%
    group_by(deltT_group) %>%
    summarise(variable = "GDP per capita", n = n(), mean = mean(gdp_pc), median = median(gdp_pc),
              q25 = quantile(gdp_pc, 0.25), q75 = quantile(gdp_pc, 0.75), .groups = "drop")
)

write.csv(tests, file.path(out_dir, "plant_Q1_Q4_deltT_welch_tests.csv"), row.names = FALSE)
write.csv(summary_table, file.path(out_dir, "plant_Q1_Q4_deltT_summary.csv"), row.names = FALSE)

group_pal <- c("ΔT Q1 (lowest)" = "#C9DCE6", "ΔT Q4 (highest)" = "#C97A62")

plot_box <- function(dat, outcome, y_label, percent_axis, sig_label,
                     display_upper = NULL, display_breaks = waiver()) {
  y <- dat[[outcome]]
  y_min <- min(y)
  y_max <- max(y)
  if (is.null(display_upper)) {
    y_range <- y_max - y_min
    bracket_y <- y_max + 0.055 * y_range
    upper_y <- y_max + 0.145 * y_range
  } else {
    y_min <- 0
    y_range <- display_upper - y_min
    bracket_y <- display_upper - 0.105 * y_range
    upper_y <- display_upper
  }

  ggplot(dat, aes(x = deltT_group, y = .data[[outcome]], fill = deltT_group)) +
    geom_point(
      position = position_jitter(width = 0.16, height = 0, seed = 123),
      size = 0.65, alpha = 0.10, color = "#333333", show.legend = FALSE
    ) +
    geom_boxplot(width = 0.45, outlier.shape = NA, alpha = 0.88,
                 color = "#303030", linewidth = 0.62, show.legend = FALSE) +
    annotate("segment", x = 1, xend = 2, y = bracket_y, yend = bracket_y, linewidth = 0.55) +
    annotate("segment", x = 1, xend = 1, y = bracket_y - 0.02 * y_range,
             yend = bracket_y, linewidth = 0.55) +
    annotate("segment", x = 2, xend = 2, y = bracket_y - 0.02 * y_range,
             yend = bracket_y, linewidth = 0.55) +
    annotate("text", x = 1.5, y = bracket_y + 0.025 * y_range,
             label = sig_label, size = 4, fontface = "bold") +
    scale_fill_manual(values = group_pal) +
    scale_y_continuous(
      labels = if (percent_axis) percent_format(accuracy = 1) else label_number(big.mark = ","),
      breaks = display_breaks,
      limits = if (is.null(display_upper)) c(y_min, upper_y) else NULL,
      expand = expansion(mult = c(0, 0))
    ) +
    coord_cartesian(
      ylim = if (is.null(display_upper)) NULL else c(y_min, upper_y),
      clip = "on"
    ) +
    labs(x = NULL, y = y_label) +
    theme_classic(base_size = 12) +
    theme(
      panel.grid = element_blank(),
      panel.border = element_rect(fill = NA, color = "#4C4C4C", linewidth = 0.45),
      axis.line = element_blank(),
      axis.ticks = element_line(color = "#666666", linewidth = 0.35),
      axis.text.x = element_text(size = 11, color = "#3F3F3F"),
      axis.text.y = element_text(size = 10.5, color = "#3F3F3F"),
      axis.title = element_text(size = 12),
      legend.position = "none",
      plot.margin = margin(6, 6, 6, 6)
    )
}

p_vul <- plot_box(
  df_vul, "vulnerable_ratio", "Vulnerable population share", TRUE,
  tests$significance[tests$variable == "Vulnerable population share"]
)
p_gdp <- plot_box(
  df_gdp, "gdp_pc", "GDP per capita", FALSE,
  tests$significance[tests$variable == "GDP per capita"],
  display_upper = 120000,
  display_breaks = seq(0, 120000, by = 40000)
)
combined <- plot_grid(p_vul, p_gdp, nrow = 1, align = "hv", axis = "tblr")

save_plot <- function(filename, plot, width, height) {
  ggsave(file.path(out_dir, paste0(filename, ".svg")), plot, width = width, height = height,
         device = svglite::svglite)
  ggsave(file.path(out_dir, paste0(filename, ".pdf")), plot, width = width, height = height)
}

save_plot("plant_vulnerability_Q1_Q4_deltT_welch_boxplot", p_vul, 4, 3.6)
save_plot("plant_income_Q1_Q4_deltT_welch_boxplot", p_gdp, 4, 3.6)
save_plot("plant_vulnerability_income_Q1_Q4_deltT_welch_boxplots", combined, 7.4, 3.9)

print(tests)
cat("\nOutputs written to: ", normalizePath(out_dir), "\n", sep = "")
