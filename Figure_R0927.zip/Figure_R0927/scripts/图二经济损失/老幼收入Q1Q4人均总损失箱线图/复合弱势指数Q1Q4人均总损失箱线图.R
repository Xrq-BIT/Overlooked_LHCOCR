suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(scales)
  library(svglite)
})

excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"
out_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图二经济损失/老幼收入Q1Q4人均总损失箱线图"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

OUT_PDF <- file.path(out_dir, "composite_vulnerability_Q1_Q4_per_capita_loss_boxplot.pdf")
OUT_SVG <- file.path(out_dir, "composite_vulnerability_Q1_Q4_per_capita_loss_boxplot.svg")
OUT_SUMMARY <- file.path(out_dir, "composite_vulnerability_Q1_Q4_summary.csv")
OUT_TEST <- file.path(out_dir, "composite_vulnerability_Q1_Q4_test.csv")
OUT_DATA <- file.path(out_dir, "composite_vulnerability_analysis_data.csv")

raw <- read_excel(excel_path)
needed <- c(
  "All_loss_annual_mean_LSM_10km", "pop_10km_total_worldpop2020",
  "ratio_10km_child_worldpop2020", "ratio_10km_old_worldpop2020",
  "GDP_per_capita_2019"
)
missing <- setdiff(needed, names(raw))
if (length(missing) > 0) stop("Missing columns: ", paste(missing, collapse = ", "))

dat <- raw %>%
  transmute(
    annual_total_loss = suppressWarnings(as.numeric(All_loss_annual_mean_LSM_10km)),
    pop_10km = suppressWarnings(as.numeric(pop_10km_total_worldpop2020)),
    child_share = suppressWarnings(as.numeric(ratio_10km_child_worldpop2020)),
    old_share = suppressWarnings(as.numeric(ratio_10km_old_worldpop2020)),
    gdp_pc = suppressWarnings(as.numeric(GDP_per_capita_2019))
  ) %>%
  mutate(
    vulnerable_share = child_share + old_share,
    loss_per_capita = annual_total_loss / pop_10km
  ) %>%
  filter(
    is.finite(loss_per_capita), loss_per_capita >= 0,
    is.finite(pop_10km), pop_10km > 0,
    is.finite(vulnerable_share),
    is.finite(gdp_pc), gdp_pc > 0
  ) %>%
  mutate(
    vulnerable_percentile = percent_rank(vulnerable_share),
    income_percentile = percent_rank(gdp_pc),
    inverse_income_percentile = 1 - income_percentile,
    composite_vulnerability = (
      vulnerable_percentile + inverse_income_percentile
    ) / 2,
    composite_quartile = ntile(composite_vulnerability, 4)
  )

plot_dat <- dat %>%
  filter(composite_quartile %in% c(1, 4)) %>%
  mutate(
    group = factor(
      if_else(composite_quartile == 1, "Q1 (lowest)", "Q4 (highest)"),
      levels = c("Q1 (lowest)", "Q4 (highest)")
    )
  )

# P5-P95 winsorization affects display only.
display_lower <- quantile(plot_dat$loss_per_capita, 0.05, na.rm = TRUE)
display_upper <- quantile(plot_dat$loss_per_capita, 0.95, na.rm = TRUE)
plot_dat <- plot_dat %>%
  mutate(loss_plot = pmin(pmax(loss_per_capita, display_lower), display_upper))

summary_table <- plot_dat %>%
  group_by(group) %>%
  summarise(
    n = n(),
    mean_composite_vulnerability = mean(composite_vulnerability),
    median_composite_vulnerability = median(composite_vulnerability),
    mean_loss_per_capita = mean(loss_per_capita),
    median_loss_per_capita = median(loss_per_capita),
    q25_loss_per_capita = quantile(loss_per_capita, 0.25),
    q75_loss_per_capita = quantile(loss_per_capita, 0.75),
    .groups = "drop"
  )

q1 <- plot_dat %>% filter(group == "Q1 (lowest)") %>% pull(loss_per_capita)
q4 <- plot_dat %>% filter(group == "Q4 (highest)") %>% pull(loss_per_capita)
test <- wilcox.test(q4, q1, exact = FALSE)
significance <- case_when(
  test$p.value < 0.001 ~ "***",
  test$p.value < 0.01 ~ "**",
  test$p.value < 0.05 ~ "*",
  TRUE ~ "ns"
)

test_table <- data.frame(
  n_q1 = length(q1),
  n_q4 = length(q4),
  median_q1 = median(q1),
  median_q4 = median(q4),
  median_ratio_q4_q1 = median(q4) / median(q1),
  p_value = test$p.value,
  significance = significance
)

write.csv(summary_table, OUT_SUMMARY, row.names = FALSE)
write.csv(test_table, OUT_TEST, row.names = FALSE)
write.csv(dat, OUT_DATA, row.names = FALSE)

group_pal <- c("Q1 (lowest)" = "#D9EAF7", "Q4 (highest)" = "#D94801")
y_min <- min(plot_dat$loss_plot)
y_max <- max(plot_dat$loss_plot)
y_range <- y_max - y_min
y_sig <- y_max + 0.08 * y_range
y_limit <- y_max + 0.18 * y_range

p <- ggplot(plot_dat, aes(group, loss_plot, fill = group)) +
  geom_point(
    position = position_jitter(width = 0.16, height = 0, seed = 123),
    size = 0.85, alpha = 0.16, color = "black", show.legend = FALSE
  ) +
  geom_boxplot(
    width = 0.45, outlier.shape = NA, color = "black", fill = "white",
    linewidth = 0.75
  ) +
  geom_boxplot(
    width = 0.45, outlier.shape = NA, alpha = 0.58, color = NA,
    show.legend = FALSE
  ) +
  annotate("segment", x = 1, xend = 2, y = y_sig, yend = y_sig, linewidth = 0.55) +
  annotate(
    "segment", x = 1, xend = 1,
    y = y_sig - 0.025 * y_range, yend = y_sig, linewidth = 0.55
  ) +
  annotate(
    "segment", x = 2, xend = 2,
    y = y_sig - 0.025 * y_range, yend = y_sig, linewidth = 0.55
  ) +
  annotate(
    "text", x = 1.5, y = y_sig + 0.035 * y_range,
    label = significance, size = 4, fontface = "bold"
  ) +
  scale_fill_manual(values = group_pal, drop = FALSE) +
  scale_y_continuous(
    labels = label_number(big.mark = ",", accuracy = 1),
    limits = c(y_min, y_limit), expand = c(0, 0)
  ) +
  labs(
    x = "Composite vulnerability",
    y = "Annual loss per capita ($)"
  ) +
  theme_bw(base_size = 12) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1),
    axis.text.x = element_text(size = 11),
    axis.text.y = element_text(size = 10.5),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12),
    legend.position = "none",
    plot.margin = margin(6, 6, 6, 6)
  )

ggsave(OUT_PDF, p, width = 4.0, height = 4.2, device = grDevices::pdf)
ggsave(OUT_SVG, p, width = 4.0, height = 4.2, device = svglite::svglite)

cat("Complete rows: ", nrow(dat), "\n", sep = "")
print(summary_table)
print(test_table)
