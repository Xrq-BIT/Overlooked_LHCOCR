# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(scales)
  library(svglite)
  library(cowplot)
  library(grid)
})

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"

SMOD_CODE_COL  <- "SMOD_2015_code"
SMOD_LABEL_COL <- "SMOD_2015_label"
LOSS_COL       <- "All_loss_annual_mean_LSM_10km"
POP_COL        <- "pop_10km_total_worldpop2020"

OUT_MAIN_SVG   <- "48_smod4_flow_main.svg"
OUT_MAIN_PDF   <- "48_smod4_flow_main.pdf"
OUT_LEG_SVG    <- "48_smod4_flow_legend.svg"
OUT_LEG_PDF    <- "48_smod4_flow_legend.pdf"
OUT_COMB_SVG   <- "48_smod4_flow_withLegend.svg"
OUT_COMB_PDF   <- "48_smod4_flow_withLegend.pdf"

# 微调 1：柱子更窄
bar_w <- 0.45

# =========================
# 2) Read
# =========================
df_raw <- read_excel(excel_path)

need_cols <- c(SMOD_CODE_COL, SMOD_LABEL_COL, LOSS_COL, POP_COL)
if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

# =========================
# 3) Prepare
# =========================
df <- df_raw %>%
  mutate(
    smod_code = suppressWarnings(as.numeric(.data[[SMOD_CODE_COL]])),
    smod_raw  = as.character(.data[[SMOD_LABEL_COL]]),
    loss      = as.numeric(.data[[LOSS_COL]]),
    pop       = as.numeric(.data[[POP_COL]])
  ) %>%
  filter(!is.na(smod_code), !is.na(smod_raw), smod_raw != "") %>%
  mutate(
    smod_group = case_when(
      smod_raw %in% c("Urban centre") ~ "Urban core",
      smod_raw %in% c("Dense urban cluster",
                      "Semi-dense urban cluster",
                      "Suburban / peri-urban") ~ "Peri-urban",
      smod_raw %in% c("Rural cluster",
                      "Low density rural") ~ "Rural",
      smod_raw %in% c("Very low density rural",
                      "Water / no settlement") ~ "Remote",
      TRUE ~ "Remote"
    )
  )

legend_levels <- c("Urban core", "Peri-urban", "Rural", "Remote")

# 堆叠顺序（底到顶）
stack_levels <- legend_levels

df$smod_group <- factor(df$smod_group, levels = stack_levels)

# =========================
# 4) Summarise
# =========================
sum_count <- df %>%
  group_by(smod_group) %>%
  summarise(value = n(), .groups = "drop") %>%
  mutate(indicator = "Plant count")

sum_pop <- df %>%
  group_by(smod_group) %>%
  summarise(value = sum(pop, na.rm = TRUE), .groups = "drop") %>%
  mutate(indicator = "Exposed population")

sum_loss <- df %>%
  group_by(smod_group) %>%
  summarise(value = sum(loss, na.rm = TRUE), .groups = "drop") %>%
  mutate(indicator = "Total loss")

plot_df <- bind_rows(sum_count, sum_pop, sum_loss) %>%
  group_by(indicator) %>%
  mutate(share = value / sum(value, na.rm = TRUE)) %>%
  ungroup()

plot_df$indicator <- factor(
  plot_df$indicator,
  levels = c("Plant count", "Exposed population", "Total loss")
)

# 微调 2：三根柱子整体向右移，给左侧图例留出空间
x_map <- c(
  "Plant count" = 1.3,
  "Exposed population" = 2.3,
  "Total loss" = 3.3
)

plot_df$x <- unname(x_map[as.character(plot_df$indicator)])

# =========================
# 5) Stack positions + labels
# =========================
plot_df <- plot_df %>%
  group_by(indicator) %>%
  arrange(indicator, smod_group) %>%
  mutate(
    ymin  = lag(cumsum(share), default = 0),
    ymax  = cumsum(share),
    ypos  = (ymin + ymax) / 2,
    label = ifelse(share >= 0.15, percent(share, accuracy = 1), "")
  ) %>%
  ungroup()

# 深色块白字，浅色块黑字
dark_levels <- c("Urban core", "Peri-urban")

plot_df <- plot_df %>%
  mutate(
    label_color = ifelse(as.character(smod_group) %in% dark_levels, "white", "black")
  )

# =========================
# 6) Build flow ribbons
# =========================
make_flow_df <- function(df, left_name, right_name, bar_w = 0.52) {
  left_df  <- df %>% filter(indicator == left_name)
  right_df <- df %>% filter(indicator == right_name)
  
  cats <- intersect(as.character(left_df$smod_group), as.character(right_df$smod_group))
  
  out <- lapply(seq_along(cats), function(i) {
    lab <- cats[i]
    
    lrow <- left_df  %>% filter(as.character(smod_group) == lab)
    rrow <- right_df %>% filter(as.character(smod_group) == lab)
    
    data.frame(
      smod_group = lab,
      group_id   = paste(left_name, right_name, lab, sep = "_"),
      x = c(lrow$x + bar_w/2, rrow$x - bar_w/2, rrow$x - bar_w/2, lrow$x + bar_w/2),
      y = c(lrow$ymin,        rrow$ymin,        rrow$ymax,        lrow$ymax)
    )
  })
  
  bind_rows(out)
}

flow12 <- make_flow_df(plot_df, "Plant count", "Exposed population", bar_w = bar_w)
flow23 <- make_flow_df(plot_df, "Exposed population", "Total loss", bar_w = bar_w)

flow_df <- bind_rows(flow12, flow23)
flow_df$smod_group <- factor(flow_df$smod_group, levels = stack_levels)

# =========================
# 7) Palette
# =========================
smod_pal <- c(
  "Urban core" = "#2C7BB6",   # 蓝
  "Peri-urban" = "#1A9850",   # 绿
  "Rural"      = "#F46D43",   # 橙红
  "Remote"     = "#9E9E9E"    # 灰
)

smod_pal_use <- smod_pal[names(smod_pal) %in% legend_levels]

# =========================
# 7.5) Build dashed boundary connector lines
# =========================
make_boundary_line_df <- function(df, left_name, right_name, bar_w = 0.45) {
  
  left_df <- df %>%
    filter(indicator == left_name) %>%
    arrange(smod_group)
  
  right_df <- df %>%
    filter(indicator == right_name) %>%
    arrange(smod_group)
  
  # 只连接内部边界：4个类别对应3条分界线
  boundary_groups <- stack_levels[-length(stack_levels)]
  
  out <- lapply(boundary_groups, function(lab) {
    
    lrow <- left_df %>% filter(as.character(smod_group) == lab)
    rrow <- right_df %>% filter(as.character(smod_group) == lab)
    
    if (nrow(lrow) == 0 || nrow(rrow) == 0) {
      return(NULL)
    }
    
    data.frame(
      boundary_group = lab,
      x_start = lrow$x + bar_w / 2,
      x_end   = rrow$x - bar_w / 2,
      y_start = lrow$ymax,
      y_end   = rrow$ymax
    )
  })
  
  bind_rows(out)
}

line12 <- make_boundary_line_df(
  plot_df,
  "Plant count",
  "Exposed population",
  bar_w = bar_w
)

line23 <- make_boundary_line_df(
  plot_df,
  "Exposed population",
  "Total loss",
  bar_w = bar_w
)

line_df <- bind_rows(line12, line23)

# =========================
# 8) Main plot (no legend)
# =========================
p_main <- ggplot() +
  geom_segment(
    data = line_df,
    aes(
      x = x_start,
      xend = x_end,
      y = y_start,
      yend = y_end
    ),
    linewidth = 0.45,
    linetype = "dashed",
    color = "grey55",
    alpha = 0.85,
    show.legend = FALSE
  ) +
  geom_rect(
    data = plot_df,
    aes(
      xmin = x - bar_w/2,
      xmax = x + bar_w/2,
      ymin = ymin,
      ymax = ymax,
      fill = smod_group
    ),
    color = "white",
    linewidth = 0.55
  ) +
  geom_text(
    data = plot_df,
    aes(x = x, y = ypos, label = label, color = label_color),
    size = 5.0,
    fontface = "bold",
    show.legend = FALSE
  ) +
  scale_color_identity() +
  scale_x_continuous(
    breaks = unname(x_map),
    labels = c("Plant count", "Exposed population", "Total loss"),
    expand = c(0.03, 0.05)
  ) +
  scale_y_continuous(
    labels = percent_format(accuracy = 1),
    expand = c(0, 0)
  ) +
  scale_fill_manual(
    values = smod_pal_use,
    breaks = legend_levels,
    na.translate = FALSE
  ) +
  labs(
    x = NULL,
    y = "Share"
  ) +
  coord_cartesian(
    xlim = c(0.62, 3.68),
    clip = "off"
  ) +
  theme_minimal(base_size = 15) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "grey40", fill = NA, linewidth = 0.7),
    axis.text.x = element_text(size = 14, color = "grey15"),
    axis.text.y = element_text(size = 13, color = "grey15"),
    axis.title.y = element_text(size = 15),
    axis.ticks = element_line(color = "grey40"),
    axis.ticks.length = unit(2.2, "mm"),
    legend.position = "none",
    plot.margin = margin(8, 12, 8, 8)
  )

ggsave(OUT_MAIN_SVG, p_main, width = 8.6, height = 5.8, device = svglite::svglite)
ggsave(OUT_MAIN_PDF, p_main, width = 8.6, height = 5.8)

# =========================
# 9) Separate legend
# =========================
p_leg_src <- ggplot(plot_df, aes(x = indicator, y = share, fill = smod_group)) +
  geom_col() +
  scale_fill_manual(
    values = smod_pal_use,
    breaks = legend_levels,
    na.translate = FALSE
  ) +
  theme_void(base_size = 14) +
  theme(
    legend.position = "right",
    legend.title = element_blank(),
    legend.text = element_text(size = 13)
  )

leg <- cowplot::get_legend(p_leg_src)

ggsave(OUT_LEG_SVG, leg, width = 2.8, height = 2.8, device = svglite::svglite)
ggsave(OUT_LEG_PDF, leg, width = 2.8, height = 2.8)

# =========================
# 10) Combined
# =========================
p_comb <- cowplot::ggdraw() +
  cowplot::draw_plot(p_main, x = 0, y = 0, width = 1, height = 1) +
  cowplot::draw_grob(
    leg,
    # 微调 3：图例右移，避开 y 轴；同时位于 Plant count 左侧空隙内
    x = 0.088,
    y = 0.000,
    width = 0.20,
    height = 0.36
  )

ggsave(OUT_COMB_SVG, p_comb, width = 8.8, height = 5.8, device = svglite::svglite)
ggsave(OUT_COMB_PDF, p_comb, width = 8.8, height = 5.8)

# =========================
# 11) Print summary
# =========================
cat("\nComposition summary:\n")
print(plot_df %>% select(indicator, smod_group, value, share))

cat("\n输出文件：\n",
    OUT_MAIN_SVG, "\n",
    OUT_LEG_SVG, "\n",
    OUT_COMB_SVG, "\n")