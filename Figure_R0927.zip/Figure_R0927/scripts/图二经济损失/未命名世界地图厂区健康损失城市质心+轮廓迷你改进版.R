# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(tidyr)
  library(sf)
  library(ggplot2)
  library(rnaturalearth)
  library(scales)
  library(svglite)
  library(stringr)
  library(cowplot)
  library(grid)
})

# =========================
# 1) File paths
# =========================
excel_path <- paste0(
  "/Users/xuruiqing/Desktop/文章试验整体流程/",
  "612健康热浪影响/",
  "48plants_with_ERA5_HWN_2011_2020_",
  "water_proximity_all_nonnegative_deaths_2020_VSL_lifetime.xlsx"
)

out_dir <- "health_VSL_delta_HWN_city_map_top10_trend"
dir.create(out_dir, showWarnings = FALSE)

OUT_MAP_SVG <- file.path(
  out_dir,
  "health_VSL_delta_HWN_map_top10_trend.svg"
)

OUT_MAP_PDF <- file.path(
  out_dir,
  "health_VSL_delta_HWN_map_top10_trend.pdf"
)

OUT_COLOR_LEG_SVG <- file.path(
  out_dir,
  "health_VSL_color_legend.svg"
)

OUT_COLOR_LEG_PDF <- file.path(
  out_dir,
  "health_VSL_color_legend.pdf"
)

OUT_SIZE_LEG_SVG <- file.path(
  out_dir,
  "health_delta_HWN_size_legend.svg"
)

OUT_SIZE_LEG_PDF <- file.path(
  out_dir,
  "health_delta_HWN_size_legend.pdf"
)

OUT_FINAL_SVG <- file.path(
  out_dir,
  "health_VSL_delta_HWN_top10_trend_withLegend.svg"
)

OUT_FINAL_PDF <- file.path(
  out_dir,
  "health_VSL_delta_HWN_top10_trend_withLegend.pdf"
)

OUT_CSV <- file.path(
  out_dir,
  "health_VSL_delta_HWN_city_summary.csv"
)

OUT_TOP10_CSV <- file.path(
  out_dir,
  "health_top10_VSL_city_summary.csv"
)

OUT_TOP10_YEAR_CSV <- file.path(
  out_dir,
  "health_top10_city_annual_delta_HWN.csv"
)

# =========================
# 2) Config
# =========================
LON_COL <- "Longitude"
LAT_COL <- "Latitude"

ISO3_COL <- "gadm_iso3"
ADMIN1_COL <- "gadm_admin1"
ADMIN2_COL <- "gadm_admin2"

VSL_COL <- "VSL_loss"

YEARS <- 2011:2020
HWN_COLS <- paste0("Delta_HWN_", YEARS)

# 每个地图点代表一个 GADM admin2 行政单元。
# 点大小使用行政区内各电厂十年累计 Delta HWN 的平均值。
SIZE_AGG <- "mean"

# =========================
# 2.1) VSL color breaks
# =========================
# 单位：M USD
# 真实断点在图例上等距显示。
VSL_BREAKS_REAL <- c(
  0,
  0.5,
  1,
  5,
  10,
  50
)

VSL_UPPER_CAP <- max(VSL_BREAKS_REAL)

# =========================
# 2.2) Delta HWN size breaks
# =========================
HWN_SCALE_REAL <- c(
  0,
  10,
  50,
  100
)

HWN_SCALE_SCORE <- seq_along(
  HWN_SCALE_REAL
)

HWN_LEGEND_REAL <- c(
  10,
  50,
  100
)

HWN_LEGEND_SCORE <- HWN_SCALE_SCORE[
  match(
    HWN_LEGEND_REAL,
    HWN_SCALE_REAL
  )
]

POINT_SIZE_MIN <- 0.18
POINT_SIZE_MAX <- 2.30

# =========================
# 2.3) Final legend positions
# =========================
# X 增大：向右
# Y 增大：向上
# W 增大：变宽
# H 增大：变高

COLOR_LEG_X <- 0.090
COLOR_LEG_Y <- 0.225
COLOR_LEG_W <- 0.125
COLOR_LEG_H <- 0.310

SIZE_LEG_X <- 0.080
SIZE_LEG_Y <- 0.065
SIZE_LEG_W <- 0.155
SIZE_LEG_H <- 0.135

# =========================
# 2.4) Top10 trend config
# =========================
# 按城市健康经济损失排序选前 10
TOP_TREND_N <- 10

# 城市逐年 Delta HWN 聚合方式：
# "mean"：城市内电厂逐年平均值，单位为 days
# "sum"：城市内电厂逐年总和，单位为 plant-days
TREND_AGG <- "mean"

# 小型趋势图的经纬度宽度和高度
TREND_BOX_W <- 11
TREND_BOX_H <- 7

# 趋势图内部留白
TREND_PAD_X <- 0.8
TREND_PAD_Y <- 0.7

# 在城市附近搜索趋势图位置
TREND_SEARCH_RADIUS <- c(
  5,
  7,
  9,
  11,
  13
)

TREND_SEARCH_ANGLE <- seq(
  0,
  330,
  by = 30
)

# 两个趋势图中心之间的最小避让距离
TREND_SAFE_W <- 12
TREND_SAFE_H <- 9

# 趋势图风格
TREND_LINE_COLOR <- "#176FA6"
TREND_POINT_COLOR <- "#176FA6"
TREND_BOX_COLOR <- "grey35"

# 是否显示城市名
SHOW_TREND_CITY_NAME <- TRUE

# 城市名最大长度
TREND_NAME_MAX_CHARS <- 18

# =========================
# 3) Helper functions
# =========================
clean_name <- function(x) {
  x %>%
    as.character() %>%
    str_trim() %>%
    str_squish()
}

lon_label <- function(x) {
  paste0(
    ifelse(x == 0, "0", abs(x)),
    "°",
    ifelse(
      x < 0,
      "W",
      ifelse(x > 0, "E", "")
    )
  )
}

lat_label <- function(y) {
  paste0(
    ifelse(y == 0, "0", abs(y)),
    "°",
    ifelse(
      y < 0,
      "S",
      ifelse(y > 0, "N", "")
    )
  )
}

trend_density_penalty <- function(
    x,
    y,
    pts_lon,
    pts_lat,
    rx = 5,
    ry = 4
) {
  sum(
    abs(pts_lon - x) <= rx &
      abs(pts_lat - y) <= ry,
    na.rm = TRUE
  )
}

trend_has_overlap <- function(
    x,
    y,
    used_df,
    safe_w = TREND_SAFE_W,
    safe_h = TREND_SAFE_H
) {
  if (nrow(used_df) == 0) {
    return(FALSE)
  }
  
  any(
    abs(used_df$x_center - x) < safe_w &
      abs(used_df$y_center - y) < safe_h
  )
}

make_trend_candidates <- function(
    lon,
    lat,
    rank_id
) {
  expand.grid(
    radius = TREND_SEARCH_RADIUS,
    angle = TREND_SEARCH_ANGLE
  ) %>%
    mutate(
      trend_rank = rank_id,
      
      x_center =
        lon +
        radius *
        cos(angle * pi / 180),
      
      y_center =
        lat +
        radius *
        sin(angle * pi / 180),
      
      x_center = pmin(
        pmax(
          x_center,
          -145 + TREND_BOX_W / 2
        ),
        145 - TREND_BOX_W / 2
      ),
      
      y_center = pmin(
        pmax(
          y_center,
          -50 + TREND_BOX_H / 2
        ),
        68 - TREND_BOX_H / 2
      ),
      
      distance = sqrt(
        (x_center - lon)^2 +
          (y_center - lat)^2
      )
    )
}

# =========================
# 4) Read Excel
# =========================
df_raw <- read_excel(
  excel_path
)

need_cols <- c(
  LON_COL,
  LAT_COL,
  ISO3_COL,
  ADMIN1_COL,
  ADMIN2_COL,
  VSL_COL,
  HWN_COLS
)

if (!all(need_cols %in% names(df_raw))) {
  stop(
    "缺少必要列：",
    paste(
      setdiff(
        need_cols,
        names(df_raw)
      ),
      collapse = ", "
    )
  )
}

# =========================
# 5) Clean plant-level data
# =========================
df <- df_raw %>%
  transmute(
    lon = suppressWarnings(
      as.numeric(
        .data[[LON_COL]]
      )
    ),
    
    lat = suppressWarnings(
      as.numeric(
        .data[[LAT_COL]]
      )
    ),
    
    iso3 = str_to_upper(
      clean_name(
        .data[[ISO3_COL]]
      )
    ),
    
    admin1 = clean_name(
      .data[[ADMIN1_COL]]
    ),
    
    admin2 = clean_name(
      .data[[ADMIN2_COL]]
    ),
    
    VSL_loss = suppressWarnings(
      as.numeric(
        .data[[VSL_COL]]
      )
    ),
    
    across(
      all_of(HWN_COLS),
      ~ suppressWarnings(
        as.numeric(.x)
      )
    )
  ) %>%
  mutate(
    iso3 = case_when(
      iso3 %in% c(
        "TWN",
        "TWM",
        "HKG",
        "MAC"
      ) ~ "CHN",
      
      TRUE ~ iso3
    ),
    
    across(
      all_of(HWN_COLS),
      ~ ifelse(
        is.na(.x),
        0,
        pmax(.x, 0)
      )
    )
  ) %>%
  filter(
    !is.na(lon),
    !is.na(lat),
    !is.na(VSL_loss),
    !is.na(iso3),
    !is.na(admin1),
    !is.na(admin2),
    iso3 != "",
    admin1 != "",
    admin2 != ""
  ) %>%
  mutate(
    plant_id_temp = row_number()
  )

# =========================
# 6) Plant-level cumulative Delta HWN
# =========================
df <- df %>%
  rowwise() %>%
  mutate(
    delta_hwn_10yr_plant = sum(
      c_across(
        all_of(HWN_COLS)
      ),
      na.rm = TRUE
    )
  ) %>%
  ungroup()

# =========================
# 7) Aggregate to GADM admin2
# =========================
city_summary <- df %>%
  group_by(
    iso3,
    admin1,
    admin2
  ) %>%
  summarise(
    lon = mean(
      lon,
      na.rm = TRUE
    ),
    
    lat = mean(
      lat,
      na.rm = TRUE
    ),
    
    plant_count = n(),
    
    VSL_loss_annual_USD = sum(
      VSL_loss,
      na.rm = TRUE
    ),
    
    VSL_loss_annual_MUSD =
      VSL_loss_annual_USD / 1e6,
    
    delta_hwn_10yr_sum = sum(
      delta_hwn_10yr_plant,
      na.rm = TRUE
    ),
    
    delta_hwn_10yr_mean = mean(
      delta_hwn_10yr_plant,
      na.rm = TRUE
    ),
    
    .groups = "drop"
  ) %>%
  mutate(
    city_label = paste0(
      admin2,
      "_",
      iso3
    ),
    
    delta_hwn_size = case_when(
      SIZE_AGG == "sum" ~
        delta_hwn_10yr_sum,
      
      TRUE ~
        delta_hwn_10yr_mean
    )
  )

write.csv(
  city_summary %>%
    arrange(
      desc(
        VSL_loss_annual_MUSD
      )
    ),
  OUT_CSV,
  row.names = FALSE
)

# =========================
# 7.1) Plant-year long data
# =========================
plant_year_df <- df %>%
  pivot_longer(
    cols = all_of(
      HWN_COLS
    ),
    names_to = "year_raw",
    values_to = "delta_hwn"
  ) %>%
  mutate(
    year = as.integer(
      str_extract(
        year_raw,
        "\\d{4}"
      )
    )
  )

# =========================
# 7.2) City-year Delta HWN
# =========================
city_year_hwn <- plant_year_df %>%
  group_by(
    iso3,
    admin1,
    admin2,
    year
  ) %>%
  summarise(
    delta_hwn_mean = mean(
      delta_hwn,
      na.rm = TRUE
    ),
    
    delta_hwn_sum = sum(
      delta_hwn,
      na.rm = TRUE
    ),
    
    plant_count_year = n_distinct(
      plant_id_temp
    ),
    
    .groups = "drop"
  ) %>%
  mutate(
    delta_hwn_plot = case_when(
      TREND_AGG == "sum" ~
        delta_hwn_sum,
      
      TRUE ~
        delta_hwn_mean
    )
  )

# =========================
# 7.3) Select Top10 VSL cities
# =========================
top_trend_city <- city_summary %>%
  arrange(
    desc(
      VSL_loss_annual_MUSD
    )
  ) %>%
  slice_head(
    n = TOP_TREND_N
  ) %>%
  mutate(
    trend_rank = row_number(),
    
    city_name_short = str_trunc(
      admin2,
      width = TREND_NAME_MAX_CHARS,
      side = "right"
    ),
    
    trend_label = case_when(
      SHOW_TREND_CITY_NAME ~
        paste0(
          trend_rank,
          ". ",
          city_name_short
        ),
      
      TRUE ~
        as.character(
          trend_rank
        )
    )
  )

write.csv(
  top_trend_city,
  OUT_TOP10_CSV,
  row.names = FALSE
)

# =========================
# 7.4) Generate candidate positions
# =========================
candidate_list <- vector(
  "list",
  nrow(top_trend_city)
)

for (
  ii in seq_len(
    nrow(top_trend_city)
  )
) {
  candidate_list[[ii]] <- make_trend_candidates(
    lon = top_trend_city$lon[ii],
    lat = top_trend_city$lat[ii],
    rank_id = top_trend_city$trend_rank[ii]
  )
}

trend_candidates <- bind_rows(
  candidate_list
) %>%
  rowwise() %>%
  mutate(
    density = trend_density_penalty(
      x = x_center,
      y = y_center,
      pts_lon = city_summary$lon,
      pts_lat = city_summary$lat
    ),
    
    score =
      distance * 5 +
      density * 1.2
  ) %>%
  ungroup() %>%
  arrange(
    trend_rank,
    score
  )

# =========================
# 7.5) Select non-overlapping positions
# =========================
used_trend_positions <- data.frame(
  trend_rank = integer(),
  x_center = numeric(),
  y_center = numeric()
)

selected_trend_list <- list()

for (rr in sort(unique(trend_candidates$trend_rank))) {
  
  cand_rr <- trend_candidates %>%
    filter(trend_rank == rr) %>%
    arrange(score)
  
  selected <- NULL
  
  for (jj in seq_len(nrow(cand_rr))) {
    
    xx <- cand_rr$x_center[jj]
    yy <- cand_rr$y_center[jj]
    
    if (
      !trend_has_overlap(
        x = xx,
        y = yy,
        used_df = used_trend_positions
      )
    ) {
      selected <- cand_rr[jj, ]
      break
    }
  }
  
  if (is.null(selected)) {
    selected <- cand_rr[1, ]
  }
  
  # 关键修正：双中括号必须完整写在一起
  selected_trend_list[[as.character(rr)]] <- selected
  
  used_trend_positions <- bind_rows(
    used_trend_positions,
    data.frame(
      trend_rank = rr,
      x_center = selected$x_center,
      y_center = selected$y_center
    )
  )
}

selected_trend_positions <- bind_rows(
  selected_trend_list
) %>%
  select(
    trend_rank,
    x_center,
    y_center
  )

top_trend_city <- top_trend_city %>%
  left_join(
    selected_trend_positions,
    by = "trend_rank"
  ) %>%
  mutate(
    box_xmin = x_center - TREND_BOX_W / 2,
    box_xmax = x_center + TREND_BOX_W / 2,
    box_ymin = y_center - TREND_BOX_H / 2,
    box_ymax = y_center + TREND_BOX_H / 2,
    
    label_x = x_center,
    label_y = box_ymax + 0.7
  )

# =========================
# 7.6) Join Top10 annual data
# =========================
top_trend_year <- city_year_hwn %>%
  inner_join(
    top_trend_city %>%
      select(
        iso3,
        admin1,
        admin2,
        trend_rank,
        trend_label,
        lon,
        lat,
        x_center,
        y_center,
        box_xmin,
        box_xmax,
        box_ymin,
        box_ymax,
        label_x,
        label_y
      ),
    by = c(
      "iso3",
      "admin1",
      "admin2"
    )
  )

write.csv(
  top_trend_year %>%
    arrange(
      trend_rank,
      year
    ),
  OUT_TOP10_YEAR_CSV,
  row.names = FALSE
)

# =========================
# 7.7) Normalize within each city
# =========================
# 每个城市单独缩放到 0–1，
# 迷你图只突出2011–2020年的相对变化趋势。
# 注意：标准化后，各城市折线高度不能用于比较绝对Delta HWN大小；
# 绝对大小仍由地图气泡表达。

top_trend_year <- top_trend_year %>%
  group_by(trend_rank) %>%
  arrange(year, .by_group = TRUE) %>%
  mutate(
    city_hwn_min = min(delta_hwn_plot, na.rm = TRUE),
    city_hwn_max = max(delta_hwn_plot, na.rm = TRUE),
    city_hwn_range = city_hwn_max - city_hwn_min,
    
    trend_norm = case_when(
      is.finite(city_hwn_range) & city_hwn_range > 0 ~
        (delta_hwn_plot - city_hwn_min) / city_hwn_range,
      
      # 十年数值完全相同时，画在中部
      TRUE ~ 0.5
    )
  ) %>%
  ungroup()

# =========================
# 7.8) Convert normalized trends
#      to map coordinates
# =========================
trend_point_df <- top_trend_year %>%
  mutate(
    year_index = match(year, YEARS),
    
    trend_x =
      box_xmin +
      TREND_PAD_X +
      (year_index - 1) /
      (length(YEARS) - 1) *
      (TREND_BOX_W - 2 * TREND_PAD_X),
    
    trend_y =
      box_ymin +
      TREND_PAD_Y +
      trend_norm *
      (TREND_BOX_H - 2 * TREND_PAD_Y)
  )

trend_segment_df <- trend_point_df %>%
  arrange(trend_rank, year) %>%
  group_by(trend_rank) %>%
  mutate(
    xend = lead(trend_x),
    yend = lead(trend_y)
  ) %>%
  filter(
    !is.na(xend),
    !is.na(yend)
  ) %>%
  ungroup()

# =========================
# 7.9) City-to-trend connectors
# =========================
trend_connector_df <- top_trend_city %>%
  mutate(
    connector_xend = case_when(
      lon < box_xmin ~ box_xmin,
      lon > box_xmax ~ box_xmax,
      TRUE ~ x_center
    ),
    
    connector_yend = case_when(
      lat < box_ymin ~ box_ymin,
      lat > box_ymax ~ box_ymax,
      TRUE ~ y_center
    )
  )

# =========================
# 7.10) Year labels
# =========================
trend_year_label_df <- bind_rows(
  top_trend_city %>%
    transmute(
      trend_rank,
      label_x =
        box_xmin +
        TREND_PAD_X,
      
      label_y =
        box_ymin -
        0.35,
      
      label = "2011"
    ),
  
  top_trend_city %>%
    transmute(
      trend_rank,
      label_x =
        box_xmax -
        TREND_PAD_X,
      
      label_y =
        box_ymin -
        0.35,
      
      label = "2020"
    )
)

# =========================
# 8) Convert city points to sf
# =========================
city_pts <- st_as_sf(
  city_summary,
  coords = c(
    "lon",
    "lat"
  ),
  crs = 4326,
  remove = FALSE
)

world <- ne_countries(
  scale = "medium",
  returnclass = "sf"
)

# =========================
# 9) VSL pseudo-continuous
#    color scale
# =========================
vsl_breaks_score <- seq_along(
  VSL_BREAKS_REAL
)

city_pts <- city_pts %>%
  mutate(
    VSL_loss_cap = pmin(
      pmax(
        VSL_loss_annual_MUSD,
        0
      ),
      VSL_UPPER_CAP
    ),
    
    VSL_color_score = approx(
      x = VSL_BREAKS_REAL,
      y = vsl_breaks_score,
      xout = VSL_loss_cap,
      rule = 2
    )$y
  )

vsl_cols <- c(
  "#FFF0E0",
  "#FDD0A2",
  "#FDAE6B",
  "#FD8D3C",
  "#F03B20",
  "#D00000"
)

vsl_color_limits <- range(
  vsl_breaks_score
)

vsl_color_values <- rescale(
  vsl_breaks_score,
  to = c(0, 1),
  from = vsl_color_limits
)

vsl_color_labels <- c(
  "0",
  "0.5",
  "1",
  "5",
  "10",
  "50"
)

# =========================
# 10) Delta HWN pseudo-size
# =========================
city_pts <- city_pts %>%
  mutate(
    delta_hwn_cap = pmin(
      pmax(
        delta_hwn_size,
        min(HWN_SCALE_REAL)
      ),
      max(HWN_SCALE_REAL)
    ),
    
    delta_hwn_size_score = approx(
      x = HWN_SCALE_REAL,
      y = HWN_SCALE_SCORE,
      xout = delta_hwn_cap,
      rule = 2
    )$y
  )

# =========================
# 11) Main map with Top10 trends
# =========================
p_map <- ggplot() +
  
  # 世界底图
  geom_sf(
    data = world,
    fill = "grey88",
    color = "grey70",
    linewidth = 0.25
  ) +
  
  # 城市级健康损失点
  geom_sf(
    data = city_pts,
    aes(
      color = VSL_color_score,
      size = delta_hwn_size_score
    ),
    alpha = 0.90,
    stroke = 0
  ) +
  
  # 城市与趋势图之间的连接线
  geom_segment(
    data = trend_connector_df,
    aes(
      x = lon,
      y = lat,
      xend = connector_xend,
      yend = connector_yend
    ),
    inherit.aes = FALSE,
    color = "grey40",
    linewidth = 0.30,
    alpha = 0.80
  ) +
  
  # 迷你趋势图背景
  geom_rect(
    data = top_trend_city,
    aes(
      xmin = box_xmin,
      xmax = box_xmax,
      ymin = box_ymin,
      ymax = box_ymax
    ),
    inherit.aes = FALSE,
    fill = scales::alpha(
      "white",
      0.82
    ),
    color = TREND_BOX_COLOR,
    linewidth = 0.25
  ) +
  
  # 趋势折线
  geom_segment(
    data = trend_segment_df,
    aes(
      x = trend_x,
      y = trend_y,
      xend = xend,
      yend = yend
    ),
    inherit.aes = FALSE,
    color = TREND_LINE_COLOR,
    linewidth = 0.55
  ) +
  
  # 年度节点
  geom_point(
    data = trend_point_df,
    aes(
      x = trend_x,
      y = trend_y
    ),
    inherit.aes = FALSE,
    color = TREND_POINT_COLOR,
    size = 0.80
  ) +
  
  # 城市名称
  geom_text(
    data = top_trend_city,
    aes(
      x = label_x,
      y = label_y,
      label = trend_label
    ),
    inherit.aes = FALSE,
    size = 2.20,
    fontface = "bold",
    hjust = 0.5,
    vjust = 0,
    color = "black"
  ) +
  
  # 2011、2020 标识
  geom_text(
    data = trend_year_label_df,
    aes(
      x = label_x,
      y = label_y,
      label = label
    ),
    inherit.aes = FALSE,
    size = 1.65,
    color = "grey30",
    hjust = 0.5,
    vjust = 1
  ) +
  
  scale_color_gradientn(
    colours = vsl_cols,
    values = vsl_color_values,
    limits = vsl_color_limits,
    oob = scales::squish,
    breaks = vsl_breaks_score,
    labels = vsl_color_labels,
    guide = "none"
  ) +
  
  scale_size_continuous(
    range = c(
      POINT_SIZE_MIN,
      POINT_SIZE_MAX
    ),
    
    limits = range(
      HWN_SCALE_SCORE
    ),
    
    breaks = HWN_LEGEND_SCORE,
    
    labels = HWN_LEGEND_REAL,
    
    guide = "none"
  ) +
  
  coord_sf(
    xlim = c(
      -150,
      150
    ),
    ylim = c(
      -60,
      80
    ),
    expand = FALSE,
    clip = "on"
  ) +
  
  scale_x_continuous(
    breaks = seq(
      -150,
      150,
      by = 60
    ),
    labels = lon_label
  ) +
  
  scale_y_continuous(
    breaks = seq(
      -30,
      60,
      by = 30
    ),
    labels = lat_label
  ) +
  
  labs(
    x = NULL,
    y = NULL
  ) +
  
  theme_minimal(
    base_size = 12
  ) +
  
  theme(
    panel.background = element_rect(
      fill = "white",
      color = NA
    ),
    
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    
    panel.border = element_rect(
      fill = NA,
      color = "grey40",
      linewidth = 0.6
    ),
    
    axis.text = element_text(
      size = 9,
      color = "grey25"
    ),
    
    axis.ticks = element_line(
      color = "grey55",
      linewidth = 0.3
    ),
    
    axis.ticks.length = unit(
      2,
      "mm"
    ),
    
    plot.margin = margin(
      5,
      10,
      5,
      10
    )
  )

ggsave(
  OUT_MAP_SVG,
  p_map,
  width = 12,
  height = 5.2,
  device = svglite::svglite
)

ggsave(
  OUT_MAP_PDF,
  p_map,
  width = 12,
  height = 5.2
)

# =========================
# 12) Separate VSL color legend
# =========================
color_legend_df <- data.frame(
  x = seq(
    min(
      vsl_color_limits
    ),
    max(
      vsl_color_limits
    ),
    length.out = 100
  ),
  
  y = 1
)

p_color_legend_src <- ggplot(
  color_legend_df,
  aes(
    x = x,
    y = y,
    color = x
  )
) +
  
  geom_point(
    size = 1
  ) +
  
  scale_color_gradientn(
    colours = vsl_cols,
    values = vsl_color_values,
    limits = vsl_color_limits,
    oob = scales::squish,
    breaks = vsl_breaks_score,
    labels = vsl_color_labels,
    
    name = "Health loss (M USD)",
    
    guide = guide_colorbar(
      direction = "vertical",
      
      barheight = unit(
        34,
        "mm"
      ),
      
      barwidth = unit(
        5.0,
        "mm"
      ),
      
      ticks.colour = "grey30",
      frame.colour = "grey30",
      
      title.position = "top",
      title.hjust = 0
    )
  ) +
  
  theme_void(
    base_size = 12
  ) +
  
  theme(
    legend.position = "right",
    
    legend.title = element_text(
      size = 9.0,
      color = "black",
      lineheight = 0.92,
      
      margin = margin(
        b = 6
      )
    ),
    
    legend.text = element_text(
      size = 8.2,
      color = "grey25"
    ),
    
    legend.background = element_blank(),
    
    legend.box.background = element_blank(),
    
    plot.background = element_rect(
      fill = "transparent",
      color = NA
    ),
    
    plot.margin = margin(
      0,
      0,
      0,
      0
    )
  )

leg_color <- cowplot::get_legend(
  p_color_legend_src
)

ggsave(
  OUT_COLOR_LEG_SVG,
  leg_color,
  width = 1.35,
  height = 2.25,
  device = svglite::svglite,
  bg = "transparent"
)

ggsave(
  OUT_COLOR_LEG_PDF,
  leg_color,
  width = 1.35,
  height = 2.25,
  bg = "transparent"
)

# =========================
# 13) Separate Delta HWN size legend
# =========================
size_legend_df <- data.frame(
  x = seq_along(
    HWN_LEGEND_SCORE
  ),
  
  y = 1,
  
  size_score = HWN_LEGEND_SCORE
)

p_size_legend_src <- ggplot(
  size_legend_df,
  aes(
    x = x,
    y = y,
    size = size_score
  )
) +
  
  geom_point(
    color = "grey25",
    alpha = 0.90
  ) +
  
  scale_size_continuous(
    range = c(
      POINT_SIZE_MIN,
      POINT_SIZE_MAX
    ),
    
    limits = range(
      HWN_SCALE_SCORE
    ),
    
    breaks = HWN_LEGEND_SCORE,
    
    labels = c(
      "10",
      "50",
      "100"
    ),
    
    name = "HWN_dT per plant (days)",
    
    guide = guide_legend(
      title.position = "top",
      title.hjust = 0,
      label.position = "right"
    )
  ) +
  
  theme_void(
    base_size = 12
  ) +
  
  theme(
    legend.position = "right",
    
    legend.title = element_text(
      size = 8.8,
      color = "black",
      lineheight = 0.92,
      
      margin = margin(
        b = 3
      )
    ),
    
    legend.text = element_text(
      size = 8.2,
      color = "grey25"
    ),
    
    legend.background = element_blank(),
    
    legend.box.background = element_blank(),
    
    plot.background = element_rect(
      fill = "transparent",
      color = NA
    ),
    
    plot.margin = margin(
      0,
      0,
      0,
      0
    )
  )

leg_size <- cowplot::get_legend(
  p_size_legend_src
)

ggsave(
  OUT_SIZE_LEG_SVG,
  leg_size,
  width = 1.65,
  height = 1.20,
  device = svglite::svglite,
  bg = "transparent"
)

ggsave(
  OUT_SIZE_LEG_PDF,
  leg_size,
  width = 1.65,
  height = 1.20,
  bg = "transparent"
)

# =========================
# 14) Final map with legends
# =========================
p_final <- cowplot::ggdraw() +
  
  cowplot::draw_plot(
    p_map,
    x = 0,
    y = 0,
    width = 1,
    height = 1
  ) +
  
  cowplot::draw_grob(
    leg_color,
    x = COLOR_LEG_X,
    y = COLOR_LEG_Y,
    width = COLOR_LEG_W,
    height = COLOR_LEG_H,
    hjust = 0,
    vjust = 0
  ) +
  
  cowplot::draw_grob(
    leg_size,
    x = SIZE_LEG_X,
    y = SIZE_LEG_Y,
    width = SIZE_LEG_W,
    height = SIZE_LEG_H,
    hjust = 0,
    vjust = 0
  )

ggsave(
  OUT_FINAL_SVG,
  p_final,
  width = 12,
  height = 5.2,
  device = svglite::svglite
)

ggsave(
  OUT_FINAL_PDF,
  p_final,
  width = 12,
  height = 5.2
)