suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(scales)
  library(svglite)
  library(cowplot)
})

# -------------------------
# 1) Configuration
# -------------------------
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"
out_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图二经济损失/plant_level_vulnerability_income_Q1_Q4_deltT"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

DT_COL <- "delt_warm_min"
CHILD_COL <- "ratio_10km_child_worldpop2020"
OLD_COL <- "ratio_10km_old_worldpop2020"
GDP_COL <- "GDP_per_capita_2019"

OUT_COMBINED_SVG <- file.path(out_dir, "plant_Q1_Q4_vulnerability_income_deltT_boxplots.svg")
OUT_COMBINED_PDF <- file.path(out_dir, "plant_Q1_Q4_vulnerability_income_deltT_boxplots.pdf")
OUT_VUL_SVG <- file.path(out_dir, "plant_vulnerability_Q1_Q4_deltT_boxplot.svg")
OUT_VUL_PDF <- file.path(out_dir, "plant_vulnerability_Q1_Q4_deltT_boxplot.pdf")
OUT_GDP_SVG <- file.path(out_dir, "plant_income_Q1_Q4_deltT_boxplot.svg")
OUT_GDP_PDF <- file.path(out_dir, "plant_income_Q1_Q4_deltT_boxplot.pdf")
OUT_SUMMARY <- file.path(out_dir, "plant_Q1_Q4_deltT_summary.csv")
OUT_TEST <- file.path(out_dir, "plant_Q1_Q4_deltT_tests.csv")

# -------------------------
# 2) Read and prepare
# -------------------------
df_raw <- read_excel(excel_path)
need_cols <- c(DT_COL, CHILD_COL, OLD_COL, GDP_COL)
if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

df <- df_raw %>%
  transmute(
    deltT = suppressWarnings(as.numeric(.data[[DT_COL]])),
    child_ratio = suppressWarnings(as.numeric(.data[[CHILD_COL]])),
    old_ratio = suppressWarnings(as.numeric(.data[[OLD_COL]])),
    gdp_pc = suppressWarnings(as.numeric(.data[[GDP_COL]]))
  ) %>%
  mutate(vulnerable_ratio = child_ratio + old_ratio) %>%
  filter(
    !is.na(deltT),
    !is.na(vulnerable_ratio),
    !is.na(gdp_pc),
    gdp_pc > 0
  )

cat("有效电厂数：", nrow(df), "\n")

# Plotting only: winsorize dT to its 5th and 95th percentiles.
dt_lo <- quantile(df$deltT, 0.05, na.rm = TRUE)
dt_hi <- quantile(df$deltT, 0.95, na.rm = TRUE)
df <- df %>% mutate(deltT_plot = pmin(pmax(deltT, dt_lo), dt_hi))

group_labels <- c("Q1 (lowest)", "Q4 (highest)")

make_q14_data <- function(data, grouping_col, grouping_name) {
  data %>%
    mutate(q_raw = ntile(.data[[grouping_col]], 4)) %>%
    filter(q_raw %in% c(1, 4)) %>%
    mutate(
      q_group = if_else(q_raw == 1, group_labels[1], group_labels[2]),
      q_group = factor(q_group, levels = group_labels),
      grouping = grouping_name
    )
}

df_vul <- make_q14_data(df, "vulnerable_ratio", "Vulnerable share")
df_gdp <- make_q14_data(df, "gdp_pc", "Income")

# -------------------------
# 3) Summary and tests
# -------------------------
summary_tab <- bind_rows(df_vul, df_gdp) %>%
  group_by(grouping, q_group) %>%
  summarise(
    n = n(),
    mean_deltT = mean(deltT),
    sd_deltT = sd(deltT),
    median_deltT = median(deltT),
    q25_deltT = quantile(deltT, 0.25),
    q75_deltT = quantile(deltT, 0.75),
    mean_vulnerable_share = mean(vulnerable_ratio),
    mean_gdp_pc = mean(gdp_pc),
    .groups = "drop"
  )
write.csv(summary_tab, OUT_SUMMARY, row.names = FALSE)

test_vul <- wilcox.test(deltT ~ q_group, data = df_vul, exact = FALSE)
test_gdp <- wilcox.test(deltT ~ q_group, data = df_gdp, exact = FALSE)

significance_label <- function(p) {
  case_when(
    p < 0.001 ~ "***",
    p < 0.01 ~ "**",
    p < 0.05 ~ "*",
    TRUE ~ "ns"
  )
}

test_tab <- data.frame(
  grouping = c("Vulnerable share", "Income"),
  p_value = c(test_vul$p.value, test_gdp$p.value)
) %>%
  mutate(signif = significance_label(p_value))
write.csv(test_tab, OUT_TEST, row.names = FALSE)

print(summary_tab)
print(test_tab)

# -------------------------
# 4) Plot function
# -------------------------
group_pal <- c(
  "Q1 (lowest)" = "#D9EAF7",
  "Q4 (highest)" = "#E97F5F"
)

plot_deltT_box <- function(dat, x_title, p_label) {
  y_min <- min(dat$deltT_plot)
  y_max <- max(dat$deltT_plot)
  y_rng <- y_max - y_min
  if (!is.finite(y_rng) || y_rng <= 0) y_rng <- 0.1

  y_sig <- y_max + 0.08 * y_rng
  y_tick <- y_sig - 0.025 * y_rng
  y_text <- y_sig + 0.035 * y_rng
  y_lim <- y_max + 0.18 * y_rng

  ggplot(dat, aes(x = q_group, y = deltT_plot, fill = q_group)) +
    geom_point(
      position = position_jitter(width = 0.16, height = 0, seed = 123),
      size = 0.70,
      alpha = 0.10,
      color = "grey20",
      shape = 16,
      show.legend = FALSE
    ) +
    geom_boxplot(
      width = 0.42,
      outlier.shape = NA,
      color = "black",
      fill = "white",
      linewidth = 0.75
    ) +
    geom_boxplot(
      width = 0.42,
      outlier.shape = NA,
      alpha = 0.62,
      color = NA,
      linewidth = 0,
      show.legend = FALSE
    ) +
    geom_segment(
      data = data.frame(x = 1, xend = 2, y = y_sig, yend = y_sig),
      aes(x = x, xend = xend, y = y, yend = yend),
      inherit.aes = FALSE,
      linewidth = 0.55
    ) +
    geom_segment(
      data = data.frame(x = c(1, 2), xend = c(1, 2), y = y_tick, yend = y_sig),
      aes(x = x, xend = xend, y = y, yend = yend),
      inherit.aes = FALSE,
      linewidth = 0.55
    ) +
    annotate("text", x = 1.5, y = y_text, label = p_label, size = 4, fontface = "bold") +
    scale_fill_manual(values = group_pal, drop = FALSE) +
    scale_y_continuous(
      labels = label_number(accuracy = 0.1),
      limits = c(y_min, y_lim),
      expand = expansion(mult = c(0, 0))
    ) +
    labs(
      x = x_title,
      y = "Local temperature difference (degC)"
    ) +
    theme_bw(base_size = 12) +
    theme(
      panel.grid = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 0.85),
      axis.line = element_blank(),
      axis.ticks = element_line(color = "grey30", linewidth = 0.45),
      axis.ticks.length = unit(1.8, "mm"),
      axis.text.x = element_text(size = 10.5, color = "grey25", margin = margin(t = 4)),
      axis.text.y = element_text(size = 10.5, color = "grey25"),
      axis.title.x = element_text(size = 11.5, color = "black", margin = margin(t = 6)),
      axis.title.y = element_text(size = 11.5, color = "black", margin = margin(r = 7)),
      legend.position = "none",
      plot.margin = margin(7, 7, 7, 7)
    )
}

p_vul <- plot_deltT_box(
  df_vul,
  "Vulnerable share",
  test_tab$signif[test_tab$grouping == "Vulnerable share"]
)

p_gdp <- plot_deltT_box(
  df_gdp,
  "Income",
  test_tab$signif[test_tab$grouping == "Income"]
)

combined <- plot_grid(
  p_vul,
  p_gdp,
  nrow = 1,
  labels = c("A", "B"),
  label_size = 13,
  label_fontface = "bold",
  align = "hv",
  axis = "tblr"
)

# -------------------------
# 5) Export
# -------------------------
ggsave(OUT_VUL_SVG, p_vul, width = 4.0, height = 3.9, device = svglite::svglite)
ggsave(OUT_VUL_PDF, p_vul, width = 4.0, height = 3.9, device = grDevices::pdf)
ggsave(OUT_GDP_SVG, p_gdp, width = 4.0, height = 3.9, device = svglite::svglite)
ggsave(OUT_GDP_PDF, p_gdp, width = 4.0, height = 3.9, device = grDevices::pdf)
ggsave(OUT_COMBINED_SVG, combined, width = 7.6, height = 3.9, device = svglite::svglite)
ggsave(OUT_COMBINED_PDF, combined, width = 7.6, height = 3.9, device = grDevices::pdf)

message(
  "Done\n",
  "- ", OUT_COMBINED_PDF, "\n",
  "- ", OUT_COMBINED_SVG, "\n",
  "- ", OUT_SUMMARY, "\n",
  "- ", OUT_TEST
)
