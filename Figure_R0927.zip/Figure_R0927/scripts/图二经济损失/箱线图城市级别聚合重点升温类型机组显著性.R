# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(sf)
  library(ggplot2)
  library(scales)
  library(svglite)
  library(cowplot)
  library(stringr)
})

sf::sf_use_s2(FALSE)

# =========================
# 1) File paths
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/48/410优化/48plants_MR_pop_GDP2加SMOD_with_child_ratio.xlsx"

gpkg_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/data/GHS_UCDB_GLOBE_R2024A_V1_1/GHS_UCDB_GLOBE_R2024A.gpkg"
layer_name <- "GHS_UCDB_THEME_CLIMATE_GLOBE_R2024A"

out_dir <- "city_level_highrisk_socioeconomic_boxplots"
dir.create(out_dir, showWarnings = FALSE)

OUT_SVG  <- file.path(out_dir, "city_highrisk_gdp_vulnerable_boxplots.svg")
OUT_PDF  <- file.path(out_dir, "city_highrisk_gdp_vulnerable_boxplots.pdf")

# 单独导出两个子图
OUT_GDP_SVG <- file.path(out_dir, "city_highrisk_gdp_boxplot.svg")
OUT_GDP_PDF <- file.path(out_dir, "city_highrisk_gdp_boxplot.pdf")

OUT_VUL_SVG <- file.path(out_dir, "city_highrisk_vulnerable_boxplot.svg")
OUT_VUL_PDF <- file.path(out_dir, "city_highrisk_vulnerable_boxplot.pdf")

OUT_CSV  <- file.path(out_dir, "city_highrisk_summary.csv")
OUT_TEST <- file.path(out_dir, "city_highrisk_tests.csv")

# =========================
# 2) Config
# =========================
LON_COL  <- "Longitude"
LAT_COL  <- "Latitude"
TYPE_COL <- "Type"
TECH_COL <- "Technology"
FUEL_COL <- "Fuel"
CAP_COL  <- "Plant_Capacity"

DT_COL   <- "delt_mean_min"
POP_COL  <- "pop_poly_0_2km"

CHILD_COL <- "ratio_ring0_2_child_0_4"
OLD_COL   <- "ratio_ring0_2_old"
GDP_COL   <- "GDP_per_capita_2019"

CITY_ID_COL <- "ID_UC_G0"

# =========================
# 3) Read plant data
# =========================
df_raw <- read_excel(excel_path)

need_cols <- c(
  LON_COL, LAT_COL,
  TYPE_COL, TECH_COL, FUEL_COL, CAP_COL,
  DT_COL, POP_COL, CHILD_COL, OLD_COL, GDP_COL
)

if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

plants_df <- df_raw %>%
  transmute(
    Longitude = suppressWarnings(as.numeric(.data[[LON_COL]])),
    Latitude  = suppressWarnings(as.numeric(.data[[LAT_COL]])),
    
    Type = as.character(.data[[TYPE_COL]]),
    Technology = as.character(.data[[TECH_COL]]),
    Fuel = as.character(.data[[FUEL_COL]]),
    cap = suppressWarnings(as.numeric(.data[[CAP_COL]])),
    
    deltT = suppressWarnings(as.numeric(.data[[DT_COL]])),
    pop = suppressWarnings(as.numeric(.data[[POP_COL]])),
    
    child_ratio = suppressWarnings(as.numeric(.data[[CHILD_COL]])),
    old_ratio   = suppressWarnings(as.numeric(.data[[OLD_COL]])),
    gdp_pc      = suppressWarnings(as.numeric(.data[[GDP_COL]]))
  ) %>%
  mutate(
    Type = str_trim(Type),
    tech_lower = str_to_lower(str_trim(Technology)),
    fuel_lower = str_to_lower(str_trim(Fuel)),
    vulnerable_ratio = child_ratio + old_ratio
  ) %>%
  filter(
    !is.na(Longitude),
    !is.na(Latitude),
    !is.na(Type),
    !is.na(cap),
    !is.na(deltT),
    !is.na(pop), pop > 0,
    !is.na(vulnerable_ratio),
    !is.na(gdp_pc), gdp_pc > 0
  ) %>%
  mutate(
    # =========================
    # 重点 / 高温升特征机组定义
    # =========================
    # 1) 亚临界煤电
    risk_subcritical_coal =
      Type == "coal" & str_detect(tech_lower, "subcritical"),
    
    # 2) 中型煤电：400–600 MW
    risk_medium_coal =
      Type == "coal" & cap >= 400 & cap < 600,
    
    # 3) 褐煤煤电
    risk_lignite =
      Type == "coal" & str_detect(fuel_lower, "lignite"),
    
    # 4) Wood biomass 生物质电厂
    risk_wood_biomass =
      Type == "bioenergy" & str_detect(fuel_lower, "wood|biomass"),
    
    # 5) Steam turbine 燃油燃气电厂
    risk_oilgas_steam =
      Type == "oil/gas" & str_detect(tech_lower, "steam turbine"),
    
    # 合并为重点机组
    highrisk_plant =
      risk_subcritical_coal |
      risk_medium_coal |
      risk_lignite |
      risk_wood_biomass |
      risk_oilgas_steam
  )

plants_sf <- st_as_sf(
  plants_df,
  coords = c("Longitude", "Latitude"),
  crs = 4326,
  remove = FALSE
)

# =========================
# 4) Read GHS city polygons
# =========================
cities <- st_read(gpkg_path, layer = layer_name, quiet = TRUE)
names(cities) <- sub("^X\\.", "", names(cities))

if (!(CITY_ID_COL %in% names(cities))) {
  stop(paste0("城市图层中不存在字段：", CITY_ID_COL))
}

# 尝试识别城市名字段；没有也不影响箱线图
candidate_city_cols <- c(
  "UC_NM_MN", "UC_NM_LST", "UC_NM_MAJ", "UC_NM",
  "UC_NM_EN", "UC_NAME", "NAME", "Name", "name",
  "city", "City", "CITY", "CITY_NAME", "NAME_LATN",
  "GRGN_L1", "GRGN_L2", "GRGN_L3"
)

city_name_col <- candidate_city_cols[candidate_city_cols %in% names(cities)][1]

if (is.na(city_name_col)) {
  cities <- cities %>%
    mutate(city_name = as.character(.data[[CITY_ID_COL]]))
} else {
  cities <- cities %>%
    mutate(
      city_name = as.character(.data[[city_name_col]]),
      city_name = ifelse(
        is.na(city_name) | city_name == "",
        as.character(.data[[CITY_ID_COL]]),
        city_name
      )
    )
}

# 尝试识别 ISO3 字段
candidate_iso3_cols <- c(
  "CTR_MN_ISO", "CTR_ISO", "ISO3", "iso3",
  "CNTR_ID", "COUNTRY_ISO3", "GID_0"
)

iso3_col <- candidate_iso3_cols[candidate_iso3_cols %in% names(cities)][1]

if (is.na(iso3_col)) {
  cities <- cities %>%
    mutate(iso3 = NA_character_)
} else {
  cities <- cities %>%
    mutate(iso3 = str_to_upper(as.character(.data[[iso3_col]])))
}

geom_col <- attr(cities, "sf_column")

# =========================
# 5) Spatial join: plant -> GHS city unit
# =========================
plants_sf_proj <- st_transform(plants_sf, st_crs(cities))

plants_joined <- st_join(
  plants_sf_proj,
  cities[, c(CITY_ID_COL, "city_name", "iso3", geom_col)],
  join = st_within,
  left = FALSE
)

cat("原始电厂数：", nrow(plants_sf), "\n")
cat("成功匹配到 GHS 城市单元的电厂数：", nrow(plants_joined), "\n")

# =========================
# 6) City-level aggregation
# =========================
city_df <- plants_joined %>%
  st_drop_geometry() %>%
  group_by(.data[[CITY_ID_COL]], city_name, iso3) %>%
  summarise(
    n_plants = n(),
    n_highrisk = sum(highrisk_plant, na.rm = TRUE),
    highrisk_share = n_highrisk / n_plants,
    
    # 城市层面 GDP：按电厂周边人口加权
    city_gdp_pc = weighted.mean(gdp_pc, w = pop, na.rm = TRUE),
    
    # 城市层面脆弱人口比例：按电厂周边人口加权
    city_vulnerable_share = weighted.mean(vulnerable_ratio, w = pop, na.rm = TRUE),
    
    city_deltT_mean = weighted.mean(deltT, w = pop, na.rm = TRUE),
    city_deltT_median = median(deltT, na.rm = TRUE),
    
    pop_sum = sum(pop, na.rm = TRUE),
    
    n_subcritical_coal = sum(risk_subcritical_coal, na.rm = TRUE),
    n_medium_coal = sum(risk_medium_coal, na.rm = TRUE),
    n_lignite = sum(risk_lignite, na.rm = TRUE),
    n_wood_biomass = sum(risk_wood_biomass, na.rm = TRUE),
    n_oilgas_steam = sum(risk_oilgas_steam, na.rm = TRUE),
    
    .groups = "drop"
  ) %>%
  mutate(
    city_highrisk = ifelse(n_highrisk > 0, "With key plants", "Others"),
    city_highrisk = factor(
      city_highrisk,
      levels = c("Others", "With key plants")
    )
  )

write.csv(city_df, OUT_CSV, row.names = FALSE)

cat("城市单元数量：", nrow(city_df), "\n")
print(
  city_df %>%
    count(city_highrisk)
)

# =========================
# 7) Tests
# =========================
test_gdp <- wilcox.test(city_gdp_pc ~ city_highrisk, data = city_df)
test_vul <- wilcox.test(city_vulnerable_share ~ city_highrisk, data = city_df)

test_tab <- data.frame(
  variable = c("City GDP per capita", "City vulnerable population share"),
  p_value = c(test_gdp$p.value, test_vul$p.value)
) %>%
  mutate(
    signif = case_when(
      p_value < 0.001 ~ "***",
      p_value < 0.01  ~ "**",
      p_value < 0.05  ~ "*",
      TRUE            ~ "ns"
    )
  )

write.csv(test_tab, OUT_TEST, row.names = FALSE)
print(test_tab)

# =========================
# 8) Winsorize for plotting
# =========================
q01_gdp <- quantile(city_df$city_gdp_pc, 0.01, na.rm = TRUE)
q99_gdp <- quantile(city_df$city_gdp_pc, 0.99, na.rm = TRUE)

q01_vul <- quantile(city_df$city_vulnerable_share, 0.01, na.rm = TRUE)
q99_vul <- quantile(city_df$city_vulnerable_share, 0.99, na.rm = TRUE)

city_df <- city_df %>%
  mutate(
    gdp_plot = pmin(pmax(city_gdp_pc, q01_gdp), q99_gdp),
    vulnerable_plot = pmin(pmax(city_vulnerable_share, q01_vul), q99_vul)
  )

# =========================
# 9) Plot function
# =========================
group_pal <- c(
  "Others" = "grey75",
  "With key plants" = "#D94801"
)

plot_city_box <- function(dat, y_col, y_lab, y_is_percent = FALSE, p_label = "ns") {
  
  y_vals <- dat[[y_col]]
  y_min <- min(y_vals, na.rm = TRUE)
  y_max <- max(y_vals, na.rm = TRUE)
  y_rng <- y_max - y_min
  
  y_sig <- y_max + 0.08 * y_rng
  y_lim_max <- y_max + 0.18 * y_rng
  
  ggplot(dat, aes(x = city_highrisk, y = .data[[y_col]], fill = city_highrisk)) +
    
    geom_point(
      aes(size = n_plants),
      position = position_jitter(width = 0.13, height = 0, seed = 123),
      alpha = 0.32,
      color = "black",
      show.legend = FALSE
    ) +
    
    geom_boxplot(
      width = 0.42,
      outlier.shape = NA,
      color = "black",
      fill = "white",
      linewidth = 0.8
    ) +
    
    geom_boxplot(
      width = 0.42,
      outlier.shape = NA,
      alpha = 0.58,
      color = NA,
      show.legend = FALSE
    ) +
    
    geom_segment(
      aes(x = 1, xend = 2, y = y_sig, yend = y_sig),
      inherit.aes = FALSE,
      linewidth = 0.55
    ) +
    geom_segment(
      aes(x = 1, xend = 1, y = y_sig - 0.025 * y_rng, yend = y_sig),
      inherit.aes = FALSE,
      linewidth = 0.55
    ) +
    geom_segment(
      aes(x = 2, xend = 2, y = y_sig - 0.025 * y_rng, yend = y_sig),
      inherit.aes = FALSE,
      linewidth = 0.55
    ) +
    geom_text(
      aes(x = 1.5, y = y_sig + 0.035 * y_rng, label = p_label),
      inherit.aes = FALSE,
      size = 4.0,
      fontface = "bold"
    ) +
    
    scale_fill_manual(values = group_pal, drop = FALSE) +
    
    scale_size_continuous(range = c(1.2, 5.5)) +
    
    scale_y_continuous(
      labels = if (y_is_percent) {
        percent_format(accuracy = 1)
      } else {
        label_number(big.mark = ",", accuracy = 1)
      },
      limits = c(y_min, y_lim_max),
      expand = c(0, 0)
    ) +
    
    labs(
      x = NULL,
      y = y_lab
    ) +
    
    theme_bw(base_size = 12) +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 1),
      
      axis.text.x = element_text(size = 10.5, angle = 10, hjust = 0.5),
      axis.text.y = element_text(size = 10.5),
      axis.title.y = element_text(size = 12),
      
      legend.position = "none",
      plot.margin = margin(6, 6, 6, 6)
    )
}

# =========================
# 10) Make panels
# =========================
p_gdp <- plot_city_box(
  dat = city_df,
  y_col = "gdp_plot",
  y_lab = "City GDP per capita, 2019",
  y_is_percent = FALSE,
  p_label = test_tab$signif[test_tab$variable == "City GDP per capita"]
)

p_vul <- plot_city_box(
  dat = city_df,
  y_col = "vulnerable_plot",
  y_lab = "City vulnerable population share",
  y_is_percent = TRUE,
  p_label = test_tab$signif[test_tab$variable == "City vulnerable population share"]
)

# =========================
# 10.5) Export standalone panels
# =========================
ggsave(
  OUT_GDP_SVG,
  p_gdp,
  width = 4.0,
  height = 3.9,
  device = svglite::svglite
)

ggsave(
  OUT_GDP_PDF,
  p_gdp,
  width = 4.0,
  height = 3.9
)

ggsave(
  OUT_VUL_SVG,
  p_vul,
  width = 4.0,
  height = 3.9,
  device = svglite::svglite
)

ggsave(
  OUT_VUL_PDF,
  p_vul,
  width = 4.0,
  height = 3.9
)

# =========================
# 11) Combined plot
# =========================
combined <- cowplot::plot_grid(
  p_gdp,
  p_vul,
  nrow = 1,
  labels = c("A", "B"),
  label_size = 13,
  align = "hv",
  axis = "tblr"
)

# =========================
# 12) Export combined
# =========================
ggsave(
  OUT_SVG,
  combined,
  width = 7.8,
  height = 3.9,
  device = svglite::svglite
)

ggsave(
  OUT_PDF,
  combined,
  width = 7.8,
  height = 3.9
)

cat("\nKey plant definition:\n")
cat("- Subcritical coal\n")
cat("- Medium coal: 400–600 MW\n")
cat("- Lignite coal\n")
cat("- Wood biomass bioenergy\n")
cat("- Oil/gas steam turbine\n")

cat(
  "\nOutput:\n",
  OUT_GDP_SVG, "\n",
  OUT_VUL_SVG, "\n",
  OUT_SVG, "\n",
  OUT_PDF, "\n",
  OUT_CSV, "\n",
  OUT_TEST, "\n"
)