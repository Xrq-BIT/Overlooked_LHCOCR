suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(sf)
  library(ggplot2)
  library(rnaturalearth)
  library(scales)
  library(cowplot)
  library(svglite)
  library(grid)
  library(stringr)
  library(DBI)
  library(RSQLite)
})

sf::sf_use_s2(FALSE)

excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"
gadm_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/data/gadm_410.gpkg"
gadm_layer <- "gadm_410"

out_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图二经济损失/gadm_admin2_annual_total_loss_map"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

OUT_MAP_SVG <- file.path(out_dir, "gadm_admin2_annual_total_loss_map.svg")
OUT_MAP_PDF <- file.path(out_dir, "gadm_admin2_annual_total_loss_map.pdf")
OUT_LEG_SVG <- file.path(out_dir, "gadm_admin2_annual_total_loss_legend.svg")
OUT_LEG_PDF <- file.path(out_dir, "gadm_admin2_annual_total_loss_legend.pdf")
OUT_SIZE_LEG_SVG <- file.path(out_dir, "gadm_admin2_plant_count_legend.svg")
OUT_SIZE_LEG_PDF <- file.path(out_dir, "gadm_admin2_plant_count_legend.pdf")
OUT_FINAL_SVG <- file.path(out_dir, "gadm_admin2_annual_total_loss_withLegend.svg")
OUT_FINAL_PDF <- file.path(out_dir, "gadm_admin2_annual_total_loss_withLegend.pdf")
OUT_CSV <- file.path(out_dir, "gadm_admin2_annual_total_loss_summary.csv")

LON_COL <- "Longitude"
LAT_COL <- "Latitude"
VAL_COL <- "All_loss_annual_mean_LSM_10km"
ISO3_COL <- "gadm_iso3"
ADMIN1_COL <- "gadm_admin1"
ADMIN2_COL <- "gadm_admin2"

LOSS_BREAKS_REAL <- c(0, 1, 2, 10, 50, 150, 300)
LOSS_UPPER_CAP <- max(LOSS_BREAKS_REAL)

clean_name <- function(x) str_squish(str_trim(as.character(x)))
valid_name <- function(x) {
  !is.na(x) & x != "" & !str_to_lower(x) %in% c("unknown", "na", "n/a", "none", "null")
}
lon_label <- function(x) paste0(ifelse(x == 0, "0", abs(x)), "°", ifelse(x < 0, "W", ifelse(x > 0, "E", "")))
lat_label <- function(y) paste0(ifelse(y == 0, "0", abs(y)), "°", ifelse(y < 0, "S", ifelse(y > 0, "N", "")))

# Plant-level annual total loss and existing GADM assignment.
df_raw <- read_excel(excel_path)
need_cols <- c(LON_COL, LAT_COL, VAL_COL, ISO3_COL, ADMIN1_COL, ADMIN2_COL)
if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

df <- df_raw %>%
  transmute(
    lon = suppressWarnings(as.numeric(.data[[LON_COL]])),
    lat = suppressWarnings(as.numeric(.data[[LAT_COL]])),
    annual_loss_usd = suppressWarnings(as.numeric(.data[[VAL_COL]])),
    iso3_original = str_to_upper(clean_name(.data[[ISO3_COL]])),
    admin1 = clean_name(.data[[ADMIN1_COL]]),
    admin2 = clean_name(.data[[ADMIN2_COL]])
  ) %>%
  filter(
    is.finite(lon), is.finite(lat), is.finite(annual_loss_usd),
    valid_name(iso3_original), valid_name(admin1), valid_name(admin2)
  ) %>%
  mutate(
    # Keep the original GADM key; GADM 4.1 stores Hong Kong under GID_0 = CHN.
    geometry_iso3 = iso3_original,
    display_iso3 = ifelse(iso3_original %in% c("TWN", "TWM", "HKG", "MAC"), "CHN", iso3_original)
  )

city_stat <- df %>%
  group_by(geometry_iso3, display_iso3, admin1, admin2) %>%
  summarise(
    fallback_lon = mean(lon, na.rm = TRUE),
    fallback_lat = mean(lat, na.rm = TRUE),
    annual_total_loss_usd = sum(annual_loss_usd, na.rm = TRUE),
    annual_total_loss_musd = annual_total_loss_usd / 1e6,
    mean_plant_loss_musd = mean(annual_loss_usd, na.rm = TRUE) / 1e6,
    plant_count = n(),
    .groups = "drop"
  )

# Match Excel names to GADM GID_2 without loading all 356k geometries.
con <- dbConnect(SQLite(), gadm_path)
gadm_index <- dbGetQuery(
  con,
  paste(
    "SELECT DISTINCT GID_0, NAME_1, GID_2, NAME_2",
    "FROM gadm_410 WHERE GID_2 IS NOT NULL AND GID_2 <> ''"
  )
) %>%
  transmute(
    geometry_iso3 = str_to_upper(clean_name(GID_0)),
    admin1 = clean_name(NAME_1),
    admin2 = clean_name(NAME_2),
    GID_2 = as.character(GID_2)
  )

exact_index <- gadm_index %>% distinct(geometry_iso3, admin1, admin2, .keep_all = TRUE)
admin2_unique_index <- gadm_index %>%
  group_by(geometry_iso3, admin2) %>%
  filter(n_distinct(GID_2) == 1) %>%
  slice(1) %>%
  ungroup() %>%
  select(geometry_iso3, admin2, GID_2_fallback = GID_2)

city_stat <- city_stat %>%
  left_join(exact_index, by = c("geometry_iso3", "admin1", "admin2")) %>%
  left_join(admin2_unique_index, by = c("geometry_iso3", "admin2")) %>%
  mutate(
    GID_2 = coalesce(GID_2, GID_2_fallback),
    geometry_match = ifelse(is.na(GID_2), "fallback_plant_mean", "gadm_gid2")
  ) %>%
  select(-GID_2_fallback)

matched_gids <- sort(unique(na.omit(city_stat$GID_2)))
if (length(matched_gids) == 0) stop("没有任何 admin2 名称成功匹配到 GADM GID_2")

quoted_gids <- dbQuoteString(con, matched_gids)
geometry_query <- paste0(
  "SELECT GID_2, geom FROM gadm_410 WHERE GID_2 IN (",
  paste(quoted_gids, collapse = ","), ")"
)
dbDisconnect(con)

gadm_parts <- st_read(gadm_path, query = geometry_query, quiet = TRUE)
gadm_admin2 <- gadm_parts %>%
  group_by(GID_2) %>%
  summarise(do_union = TRUE, .groups = "drop") %>%
  st_make_valid() %>%
  st_transform(4326) %>%
  st_simplify(dTolerance = 0.02, preserveTopology = TRUE)

city_polygons <- gadm_admin2 %>%
  inner_join(city_stat %>% filter(!is.na(GID_2)), by = "GID_2")

matched_pts <- city_polygons %>%
  st_transform(3857) %>%
  st_point_on_surface() %>%
  st_transform(4326)
fallback_stat <- city_stat %>% filter(is.na(GID_2))
if (nrow(fallback_stat) > 0) {
  fallback_pts <- st_as_sf(
    fallback_stat,
    coords = c("fallback_lon", "fallback_lat"), crs = 4326, remove = FALSE
  )
  city_pts <- bind_rows(matched_pts, fallback_pts)
} else {
  city_pts <- matched_pts
}

write.csv(
  city_stat %>% arrange(desc(annual_total_loss_musd)),
  OUT_CSV, row.names = FALSE
)

cat("有效电厂记录数：", nrow(df), "\n")
cat("GADM admin2 聚合单元数：", nrow(city_stat), "\n")
cat("成功匹配 GADM 轮廓：", sum(city_stat$geometry_match == "gadm_gid2"), "\n")
cat("使用电厂平均坐标回退：", sum(city_stat$geometry_match != "gadm_gid2"), "\n")

# Pseudo-continuous color scale in annual M USD.
loss_breaks_score <- seq_along(LOSS_BREAKS_REAL)
city_pts <- city_pts %>%
  mutate(
    loss_cap = pmin(pmax(annual_total_loss_musd, 0), LOSS_UPPER_CAP),
    loss_color_score = approx(
      x = LOSS_BREAKS_REAL, y = loss_breaks_score,
      xout = loss_cap, rule = 2
    )$y
  )

loss_cols <- c("#FFF0E0", "#FDD0A2", "#FDAE6B", "#FD8D3C", "#F03B20", "#EF1A1A", "#D00000")
color_limits <- range(loss_breaks_score)
color_values <- rescale(loss_breaks_score, to = c(0, 1), from = color_limits)
world <- ne_countries(scale = "medium", returnclass = "sf")

p_map <- ggplot() +
  geom_sf(data = world, fill = "grey88", color = "grey70", linewidth = 0.25) +
  geom_sf(data = city_pts, aes(color = loss_color_score, size = plant_count), alpha = 0.92) +
  scale_color_gradientn(
    colours = loss_cols, values = color_values, limits = color_limits,
    oob = scales::squish, breaks = loss_breaks_score,
    labels = LOSS_BREAKS_REAL, guide = "none"
  ) +
  scale_size_continuous(range = c(0.55, 3), breaks = c(1, 2, 5, 10, 20), guide = "none") +
  coord_sf(expand = FALSE, xlim = c(-150, 150), ylim = c(-60, 80)) +
  scale_x_continuous(breaks = seq(-150, 150, by = 60), labels = lon_label) +
  scale_y_continuous(breaks = seq(-30, 60, by = 30), labels = lat_label) +
  theme_minimal(base_size = 12) +
  theme(
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
    axis.title = element_blank(), axis.text = element_text(color = "grey25", size = 9),
    axis.ticks = element_line(color = "grey60", linewidth = 0.3),
    axis.ticks.length = unit(2, "mm"),
    panel.border = element_rect(color = "grey40", fill = NA, linewidth = 0.6),
    plot.margin = margin(5, 10, 5, 10)
  )

ggsave(OUT_MAP_SVG, p_map, width = 12, height = 5.2, device = svglite::svglite)
ggsave(OUT_MAP_PDF, p_map, width = 12, height = 5.2)

p_leg_color_src <- ggplot() +
  geom_sf(data = world, fill = "grey88", color = "grey70", linewidth = 0.25) +
  geom_sf(data = city_pts, aes(color = loss_color_score), size = 2.5, alpha = 0.92) +
  scale_color_gradientn(
    colours = loss_cols, values = color_values, limits = color_limits,
    oob = scales::squish, breaks = loss_breaks_score,
    labels = LOSS_BREAKS_REAL,
    name = "Annual total loss\n(M USD)",
    guide = guide_colorbar(
      barheight = unit(50, "mm"), barwidth = unit(6, "mm"),
      ticks.colour = "grey30", frame.colour = "grey30"
    )
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
    legend.position = "left", legend.title = element_text(size = 10),
    legend.text = element_text(size = 9)
  )

leg_color <- cowplot::get_legend(p_leg_color_src)
ggsave(OUT_LEG_SVG, leg_color, width = 1.8, height = 2.8, device = svglite::svglite)
ggsave(OUT_LEG_PDF, leg_color, width = 1.8, height = 2.8)

size_df <- data.frame(x = 1:5, y = 1, plant_count = c(1, 2, 5, 10, 20))
p_leg_size_src <- ggplot(size_df, aes(x, y, size = plant_count)) +
  geom_point(color = "grey20", alpha = 0.92) +
  scale_size_continuous(
    range = c(0.65, 3.2), breaks = c(1, 2, 5, 10, 20), name = "Plant count"
  ) +
  theme_void(base_size = 12) +
  theme(
    legend.position = "left", legend.title = element_text(size = 10),
    legend.text = element_text(size = 9)
  )

leg_size <- cowplot::get_legend(p_leg_size_src)
ggsave(OUT_SIZE_LEG_SVG, leg_size, width = 1.6, height = 2.0, device = svglite::svglite)
ggsave(OUT_SIZE_LEG_PDF, leg_size, width = 1.6, height = 2.0)

p_final <- cowplot::ggdraw() +
  cowplot::draw_plot(p_map, x = 0, y = 0, width = 1, height = 1) +
  cowplot::draw_grob(
    leg_color, x = 0.06, y = 0.04, width = 0.18, height = 0.52,
    scale = 0.32, hjust = 0, vjust = 0
  )

ggsave(OUT_FINAL_SVG, p_final, width = 12, height = 5.2, device = svglite::svglite)
ggsave(OUT_FINAL_PDF, p_final, width = 12, height = 5.2)

cat("\nAnnual admin2 total loss summary (M USD):\n")
print(summary(city_stat$annual_total_loss_musd))
message(
  "Done!\n",
  "- ", OUT_MAP_SVG, "\n",
  "- ", OUT_FINAL_SVG, "\n",
  "- ", OUT_CSV
)
