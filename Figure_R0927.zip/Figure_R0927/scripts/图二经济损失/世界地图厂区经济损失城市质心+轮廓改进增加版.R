# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(tidyr)
  library(sf)
  library(ggplot2)
  library(rnaturalearth)
  library(scales)
  library(cowplot)
  library(svglite)
  library(grid)
  library(stringr)
})

sf::sf_use_s2(FALSE)

# =========================
# 1) File paths
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/612健康热浪影响/48plants_with_ERA5_HWN_2011_2020_water_proximity_all_nonnegative_deaths_2020_VSL_lifetime.xlsx"

out_dir <- "gadm_admin2_fast_point_map_num_only"
dir.create(out_dir, showWarnings = FALSE)

OUT_MAP_SVG      <- file.path(out_dir, "gadm_admin2_fast_Productivity_loss_map.svg")
OUT_MAP_PDF      <- file.path(out_dir, "gadm_admin2_fast_Productivity_loss_map.pdf")
OUT_FINAL_SVG    <- file.path(out_dir, "gadm_admin2_fast_Productivity_loss_withLegend.svg")
OUT_FINAL_PDF    <- file.path(out_dir, "gadm_admin2_fast_Productivity_loss_withLegend.pdf")
OUT_LEG_SVG      <- file.path(out_dir, "gadm_admin2_fast_Productivity_loss_legend.svg")
OUT_LEG_PDF      <- file.path(out_dir, "gadm_admin2_fast_Productivity_loss_legend.pdf")
OUT_SIZE_LEG_SVG <- file.path(out_dir, "gadm_admin2_fast_Productivity_loss_size_legend.svg")
OUT_SIZE_LEG_PDF <- file.path(out_dir, "gadm_admin2_fast_Productivity_loss_size_legend.pdf")
OUT_CSV          <- file.path(out_dir, "gadm_admin2_fast_summary.csv")
OUT_CALLOUT_CSV  <- file.path(out_dir, "gadm_admin2_fast_top_callout_summary.csv")

# =========================
# 2) Config
# =========================
LON_COL <- "Longitude"
LAT_COL <- "Latitude"
VAL_COL <- "Productivity_lossall"
TYPE_COL <- "Type"

ISO3_COL <- "gadm_iso3"
ADMIN1_COL <- "gadm_admin1"
ADMIN2_COL <- "gadm_admin2"

# top 几个城市标柱子
TOP_CALLOUT_N <- 10

type_levels <- c("coal", "oil/gas", "bioenergy")

type_pal <- c(
  
  "coal"      = "#d40d8c",
  
  "oil/gas"   = "#0070b8",
  
  "bioenergy" = "#00b3b0"
  
)
# 堆叠柱尺寸，单位是经纬度
CALLOUT_BAR_H <- 13
CALLOUT_BAR_W <- 2.1

# near-position search 参数
BAR_SEARCH_RADIUS <- c(3, 4.5, 6, 7.5, 9)
BAR_SEARCH_ANGLE  <- seq(0, 330, by = 30)

CALLOUT_SAFE_W <- 8
CALLOUT_SAFE_H <- 6

# =========================
# 3) Helper
# =========================
clean_name <- function(x) {
  x %>%
    as.character() %>%
    str_trim() %>%
    str_squish()
}

lon_label <- function(x) {
  paste0(
    ifelse(x == 0, "0", abs(x)), "°",
    ifelse(x < 0, "W", ifelse(x > 0, "E", ""))
  )
}

lat_label <- function(y) {
  paste0(
    ifelse(y == 0, "0", abs(y)), "°",
    ifelse(y < 0, "S", ifelse(y > 0, "N", ""))
  )
}

density_penalty <- function(x, y, pts_lon, pts_lat, rx = 4, ry = 3) {
  sum(abs(pts_lon - x) <= rx & abs(pts_lat - y) <= ry, na.rm = TRUE)
}

overlap_penalty <- function(x, y, used_df, box_w = CALLOUT_SAFE_W, box_h = CALLOUT_SAFE_H) {
  if (nrow(used_df) == 0) return(FALSE)
  any(abs(used_df$x_text - x) <= box_w & abs(used_df$y_text - y) <= box_h)
}

make_near_candidates <- function(lon, lat, rank_id) {
  expand.grid(
    r = BAR_SEARCH_RADIUS,
    angle = BAR_SEARCH_ANGLE
  ) %>%
    mutate(
      callout_rank = rank_id,
      x_text = lon + r * cos(angle * pi / 180),
      y_text = lat + r * sin(angle * pi / 180),
      x_text = pmin(pmax(x_text, -145), 145),
      y_text = pmin(pmax(y_text, -52), 68),
      dist = sqrt((x_text - lon)^2 + (y_text - lat)^2)
    )
}

# =========================
# 4) Read Excel
# =========================
df_raw <- read_excel(excel_path)

need_cols <- c(
  LON_COL, LAT_COL, VAL_COL, TYPE_COL,
  ISO3_COL, ADMIN1_COL, ADMIN2_COL
)

if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

df <- df_raw %>%
  transmute(
    lon = suppressWarnings(as.numeric(.data[[LON_COL]])),
    lat = suppressWarnings(as.numeric(.data[[LAT_COL]])),
    loss_musd = suppressWarnings(as.numeric(.data[[VAL_COL]])) / 1e6,
    
    Type = as.character(.data[[TYPE_COL]]),
    
    iso3 = str_to_upper(clean_name(.data[[ISO3_COL]])),
    admin1 = clean_name(.data[[ADMIN1_COL]]),
    admin2 = clean_name(.data[[ADMIN2_COL]])
  ) %>%
  mutate(
    iso3 = case_when(
      iso3 %in% c("TWN", "HKG", "MAC") ~ "CHN",
      TRUE ~ iso3
    ),
    Type = ifelse(Type %in% type_levels, Type, NA_character_)
  ) %>%
  filter(
    !is.na(lon),
    !is.na(lat),
    !is.na(loss_musd),
    !is.na(Type),
    !is.na(iso3),
    !is.na(admin1),
    !is.na(admin2),
    iso3 != "",
    admin1 != "",
    admin2 != ""
  )

# =========================
# 5) Aggregate to GADM admin2
# =========================
city_stat <- df %>%
  group_by(iso3, admin1, admin2) %>%
  summarise(
    lon = mean(lon, na.rm = TRUE),
    lat = mean(lat, na.rm = TRUE),
    
    sum_loss_musd = sum(loss_musd, na.rm = TRUE),
    mean_loss_musd = mean(loss_musd, na.rm = TRUE),
    plant_count = n(),
    
    coal_count = sum(Type == "coal", na.rm = TRUE),
    oilgas_count = sum(Type == "oil/gas", na.rm = TRUE),
    bioenergy_count = sum(Type == "bioenergy", na.rm = TRUE),
    
    coal_loss = sum(ifelse(Type == "coal", loss_musd, 0), na.rm = TRUE),
    oilgas_loss = sum(ifelse(Type == "oil/gas", loss_musd, 0), na.rm = TRUE),
    bioenergy_loss = sum(ifelse(Type == "bioenergy", loss_musd, 0), na.rm = TRUE),
    
    .groups = "drop"
  ) %>%
  mutate(
    city_name_final = paste0(admin2, "_", iso3)
  )

write.csv(
  city_stat %>% arrange(desc(sum_loss_musd)),
  OUT_CSV,
  row.names = FALSE
)

# =========================
# 6) Convert city points to sf
# =========================
city_pts_wgs84 <- st_as_sf(
  city_stat,
  coords = c("lon", "lat"),
  crs = 4326,
  remove = FALSE
)

world <- ne_countries(scale = "medium", returnclass = "sf")

# =========================
# 7) Color scale
# =========================
loss_breaks_real <- c(0, 1, 2, 10, 50, 150, 300)
loss_breaks_score <- seq_along(loss_breaks_real)

loss_upper_cap <- max(loss_breaks_real)

city_pts_wgs84 <- city_pts_wgs84 %>%
  mutate(
    sum_loss_musd_cap = pmin(sum_loss_musd, loss_upper_cap),
    loss_color_score = approx(
      x = loss_breaks_real,
      y = loss_breaks_score,
      xout = sum_loss_musd_cap,
      rule = 2
    )$y
  )

cols <- c(
  "#FFF0E0",
  "#FDD0A2",
  "#FDAE6B",
  "#FD8D3C",
  "#F03B20",
  "#EF1A1A",
  "#D00000"
)

color_limits <- range(loss_breaks_score)
color_brks <- loss_breaks_score
color_labels <- c("0", "1", "2", "10", "50", "150", "300")
color_vals <- rescale(color_brks, to = c(0, 1), from = color_limits)

# =========================
# 8) Top loss callout cities
# =========================
top_callout <- city_stat %>%
  arrange(desc(sum_loss_musd)) %>%
  slice_head(n = TOP_CALLOUT_N) %>%
  mutate(
    callout_rank = row_number(),
    title_label = paste0("num=", plant_count)
  )

# =========================
# 8.1) Near-position search for bars
# =========================
all_candidates <- top_callout %>%
  select(callout_rank, lon, lat) %>%
  group_by(callout_rank) %>%
  group_modify(~ make_near_candidates(.x$lon[1], .x$lat[1], .x$callout_rank[1])) %>%
  ungroup() %>%
  rowwise() %>%
  mutate(
    density = density_penalty(
      x_text,
      y_text,
      city_stat$lon,
      city_stat$lat,
      rx = 4,
      ry = 3
    ),
    score = dist * 4 + density * 2
  ) %>%
  ungroup() %>%
  arrange(callout_rank, score)

used_pos <- data.frame(
  callout_rank = integer(),
  x_text = numeric(),
  y_text = numeric()
)

selected_pos_list <- list()

for (rr in sort(unique(all_candidates$callout_rank))) {
  
  cand_rr <- all_candidates %>%
    filter(callout_rank == rr) %>%
    arrange(score)
  
  selected <- NULL
  
  for (ii in seq_len(nrow(cand_rr))) {
    xx <- cand_rr$x_text[ii]
    yy <- cand_rr$y_text[ii]
    
    if (!overlap_penalty(xx, yy, used_pos)) {
      selected <- cand_rr[ii, ]
      break
    }
  }
  
  if (is.null(selected)) {
    selected <- cand_rr[1, ]
  }
  
  selected_pos_list[[as.character(rr)]] <- selected
  
  used_pos <- bind_rows(
    used_pos,
    data.frame(
      callout_rank = rr,
      x_text = selected$x_text,
      y_text = selected$y_text
    )
  )
}

selected_pos <- bind_rows(selected_pos_list) %>%
  select(callout_rank, x_text, y_text)

top_callout <- top_callout %>%
  left_join(selected_pos, by = "callout_rank")

write.csv(
  top_callout %>%
    select(
      callout_rank,
      city_name_final,
      iso3,
      admin1,
      admin2,
      sum_loss_musd,
      plant_count,
      coal_count,
      oilgas_count,
      bioenergy_count,
      coal_loss,
      oilgas_loss,
      bioenergy_loss,
      lon,
      lat,
      x_text,
      y_text
    ),
  OUT_CALLOUT_CSV,
  row.names = FALSE
)

# =========================
# 9) Build stacked bars for callouts
# =========================
callout_bar_df <- top_callout %>%
  select(
    callout_rank,
    x_text,
    y_text,
    coal_loss,
    oilgas_loss,
    bioenergy_loss
  ) %>%
  pivot_longer(
    cols = c(coal_loss, oilgas_loss, bioenergy_loss),
    names_to = "type_raw",
    values_to = "loss"
  ) %>%
  mutate(
    Type = case_when(
      type_raw == "coal_loss" ~ "coal",
      type_raw == "oilgas_loss" ~ "oil/gas",
      type_raw == "bioenergy_loss" ~ "bioenergy"
    ),
    Type = factor(Type, levels = type_levels)
  ) %>%
  group_by(callout_rank) %>%
  mutate(
    total_loss = sum(loss, na.rm = TRUE),
    share = ifelse(total_loss > 0, loss / total_loss, 0),
    ymin_share = lag(cumsum(share), default = 0),
    ymax_share = cumsum(share),
    
    xmin = x_text - CALLOUT_BAR_W / 2,
    xmax = x_text + CALLOUT_BAR_W / 2,
    ymin = y_text - CALLOUT_BAR_H / 2 + ymin_share * CALLOUT_BAR_H,
    ymax = y_text - CALLOUT_BAR_H / 2 + ymax_share * CALLOUT_BAR_H
  ) %>%
  ungroup()

# =========================
# 10) Label positions: num only
# =========================
callout_title_df <- top_callout %>%
  mutate(
    label_x = x_text,
    label_y = y_text + CALLOUT_BAR_H / 2 + 0.8,
    
    line_xend = x_text,
    line_yend = y_text - CALLOUT_BAR_H / 2
  )

# =========================
# 11) Main map
# =========================
p_map <- ggplot() +
  
  geom_sf(
    data = world,
    fill = "grey88",
    color = "grey70",
    linewidth = 0.25
  ) +
  
  geom_sf(
    data = city_pts_wgs84,
    aes(color = loss_color_score, size = plant_count),
    alpha = 0.92
  ) +
  
  geom_segment(
    data = callout_title_df,
    aes(
      x = lon,
      y = lat,
      xend = line_xend,
      yend = line_yend
    ),
    inherit.aes = FALSE,
    color = "grey45",
    linewidth = 0.35,
    alpha = 0.85
  ) +
  
  geom_rect(
    data = callout_bar_df,
    aes(
      xmin = xmin,
      xmax = xmax,
      ymin = ymin,
      ymax = ymax,
      fill = Type
    ),
    inherit.aes = FALSE,
    color = "white",
    linewidth = 0.10,
    alpha = 0.82
  ) +
  
  geom_text(
    data = callout_title_df,
    aes(
      x = label_x,
      y = label_y,
      label = title_label
    ),
    inherit.aes = FALSE,
    angle = 0,
    hjust = 0.5,
    vjust = 0,
    size = 2.3,
    
    fontface = "plain",
    
    color = "grey25"
  ) +
  
  scale_color_gradientn(
    colours = cols,
    values = color_vals,
    limits = color_limits,
    oob = scales::squish,
    breaks = color_brks,
    labels = color_labels,
    name = NULL,
    guide = "none"
  ) +
  
  scale_size_continuous(
    range = c(0.55, 3),
    breaks = c(1, 2, 5, 10, 20),
    name = NULL,
    guide = "none"
  ) +
  
  scale_fill_manual(
    values = type_pal,
    breaks = type_levels,
    name = NULL,
    guide = "none"
  ) +
  
  coord_sf(
    expand = FALSE,
    xlim = c(-150, 150),
    ylim = c(-60, 80),
    clip = "on"
  ) +
  
  scale_x_continuous(
    breaks = seq(-150, 150, by = 60),
    labels = lon_label
  ) +
  
  scale_y_continuous(
    breaks = seq(-30, 60, by = 30),
    labels = lat_label
  ) +
  
  theme_minimal(base_size = 12) +
  theme(
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.title = element_blank(),
    axis.text = element_text(color = "grey25", size = 9),
    axis.ticks = element_line(color = "grey60", linewidth = 0.3),
    axis.ticks.length = unit(2.0, "mm"),
    panel.border = element_rect(color = "grey40", fill = NA, linewidth = 0.6),
    plot.margin = margin(5, 10, 5, 10)
  )

ggsave(
  OUT_MAP_SVG,
  p_map,
  width = 12,
  height = 5.2,
  device = svglite::svglite
)

ggsave(
  OUT_MAP_PDF,
  p_map,
  width = 12,
  height = 5.2
)

# =========================
# 12) Color legend
# =========================
LEG_TITLE_COLOR <- "Productivity loss\n(M USD)"

p_leg_color_src <- ggplot() +
  geom_sf(
    data = world,
    fill = "grey88",
    color = "grey70",
    linewidth = 0.25
  ) +
  geom_sf(
    data = city_pts_wgs84,
    aes(color = loss_color_score),
    size = 2.5,
    alpha = 0.92
  ) +
  scale_color_gradientn(
    colours = cols,
    values = color_vals,
    limits = color_limits,
    oob = scales::squish,
    breaks = color_brks,
    labels = color_labels,
    name = LEG_TITLE_COLOR,
    guide = guide_colorbar(
      barheight = unit(50, "mm"),
      barwidth = unit(6, "mm"),
      ticks.colour = "grey30",
      frame.colour = "grey30"
    )
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position = "left",
    legend.title = element_text(size = 10),
    legend.text = element_text(size = 9)
  )

leg_color <- cowplot::get_legend(p_leg_color_src)

ggsave(
  OUT_LEG_SVG,
  leg_color,
  width = 1.8,
  height = 2.8,
  device = svglite::svglite
)

ggsave(
  OUT_LEG_PDF,
  leg_color,
  width = 1.8,
  height = 2.8
)

# =========================
# 13) Size legend
# =========================
LEG_TITLE_SIZE <- "Plant count"

size_df <- data.frame(
  x = 1:5,
  y = 1,
  plant_count = c(1, 2, 4, 10, 20)
)

p_leg_size_src <- ggplot(size_df, aes(x = x, y = y, size = plant_count)) +
  geom_point(color = "grey20", alpha = 0.92) +
  scale_size_continuous(
    range = c(0.65, 3.2),
    breaks = c(1, 2, 4, 10, 20),
    name = LEG_TITLE_SIZE
  ) +
  theme_void(base_size = 12) +
  theme(
    legend.position = "left",
    legend.title = element_text(size = 10),
    legend.text = element_text(size = 9)
  )

leg_size <- cowplot::get_legend(p_leg_size_src)

ggsave(
  OUT_SIZE_LEG_SVG,
  leg_size,
  width = 1.6,
  height = 2.0,
  device = svglite::svglite
)

ggsave(
  OUT_SIZE_LEG_PDF,
  leg_size,
  width = 1.6,
  height = 2.0
)

# =========================
# 14) Combine map + color legend
# =========================
LEG_X <- 0.06
LEG_Y <- 0.04
LEG_W <- 0.18
LEG_H <- 0.52
LEG_SCALE <- 0.32

p_final <- cowplot::ggdraw() +
  cowplot::draw_plot(p_map, x = 0, y = 0, width = 1, height = 1) +
  cowplot::draw_grob(
    leg_color,
    x = LEG_X,
    y = LEG_Y,
    width = LEG_W,
    height = LEG_H,
    scale = LEG_SCALE,
    hjust = 0,
    vjust = 0
  )

ggsave(
  OUT_FINAL_SVG,
  p_final,
  width = 12,
  height = 5.2,
  device = svglite::svglite
)

ggsave(
  OUT_FINAL_PDF,
  p_final,
  width = 12,
  height = 5.2
)