suppressPackageStartupMessages({
  library(xml2)
  library(rsvg)
})

base_dir <- paste0(
  "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图一温差统计/",
  "Fig1_complete_composite"
)

stems <- c(
  "Fig1_complete_main_plants_boxplots_efg_frames",
  "Fig1_complete_background_HWN_plants_boxplots",
  "Fig1_complete_MMT_exceedance_plants_boxplots",
  "Fig1_complete_MMT_background_plants_boxplots"
)

svg_ns <- "http://www.w3.org/2000/svg"

frame_group <- function(id, lines, color, linewidth) {
  line_nodes <- vapply(lines, function(points) {
    sprintf(
      '<polyline points="%s" style="fill:none;stroke:%s;stroke-width:%.2f;stroke-linecap:butt"/>',
      points, color, linewidth
    )
  }, character(1))
  xml_root(read_xml(sprintf(
    '<g xmlns="%s" id="%s">%s</g>',
    svg_ns, id, paste(line_nodes, collapse = "")
  )))
}

add_group <- function(parent, id, lines, color, linewidth) {
  old <- xml_find_all(parent, sprintf('.//*[starts-with(@id, "%s")]', id))
  if (length(old)) xml_remove(old)
  xml_add_child(parent, frame_group(id, lines, color, linewidth))
}

for (stem in stems) {
  svg_path <- file.path(base_dir, paste0(stem, ".svg"))
  if (!file.exists(svg_path)) next

  doc <- read_xml(svg_path)
  root <- xml_root(doc)
  nested <- xml_find_all(root, './*[local-name()="svg"]')
  if (length(nested) < 8) {
    stop("Unexpected Figure 1 SVG structure: ", svg_path)
  }

  # c and d: latitudinal-profile panels inside the first nested SVG.
  add_group(
    nested[[1]], "complete_frame_cd",
    c(
      "774.12,4.98 893.70,4.98",
      "893.70,4.98 893.70,292.31",
      "774.12,325.38 893.70,325.38",
      "893.70,325.38 893.70,602.66"
    ),
    "#555555", 0.85
  )

  # h-k: retain the existing left/bottom axes and add matching top/right edges.
  box_specs <- list(
    list(lines = c("40.78,5.98 354.02,5.98", "354.02,5.98 354.02,302.92")),
    list(lines = c("40.78,5.98 354.02,5.98", "354.02,5.98 354.02,301.53")),
    list(lines = c("46.49,5.98 282.02,5.98", "282.02,5.98 282.02,237.65")),
    list(lines = c("63.45,5.98 282.02,5.98", "282.02,5.98 282.02,237.65"))
  )
  for (index in seq_along(box_specs)) {
    add_group(
      nested[[index + 4]], paste0("complete_frame_box_", index),
      box_specs[[index]]$lines, "#4C4C4C", 0.96
    )
  }

  write_xml(doc, svg_path, options = "format")
  rsvg_pdf(svg_path, file.path(base_dir, paste0(stem, ".pdf")))
  rsvg_png(svg_path, file.path(base_dir, paste0(stem, ".png")), width = 3000)
  message("Updated: ", stem)
}
