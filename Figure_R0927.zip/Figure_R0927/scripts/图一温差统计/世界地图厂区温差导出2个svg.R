# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(sf)
  library(ggplot2)
  library(rnaturalearth)
  library(scales)
  library(cowplot)
  library(svglite)
  library(grid)
})

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"

LON_COL <- "Longitude"
LAT_COL <- "Latitude"
VAL_COL <- "delt_warm_min"

OUT_MAP_SVG <- "map_heat_delt.svg"
OUT_MAP_PDF <- "map_heat_delt.pdf"
OUT_LEG_SVG <- "legend_heat_delt.svg"
OUT_LEG_PDF <- "legend_heat_delt.pdf"

# =========================
# 2) Read & prepare
# =========================
df_raw <- read_excel(excel_path)

need_cols <- c(LON_COL, LAT_COL, VAL_COL)
if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

df <- df_raw %>%
  mutate(plot_val = as.numeric(.data[[VAL_COL]])) %>%
  filter(!is.na(.data[[LON_COL]]), !is.na(.data[[LAT_COL]]), !is.na(plot_val))

pts <- st_as_sf(df, coords = c(LON_COL, LAT_COL), crs = 4326, remove = FALSE)
world <- ne_countries(scale = "medium", returnclass = "sf")

# =========================
# 3) Color scale (keep Fig-2 style, but bias to heat)
# =========================
# 你想突出热端：固定不对称范围
limits <- c(-0.5, 1.0)

# 颜色（沿用你图二那套）
cols <- c("#08306B","#2171B5","#6BAED6","#FEE8C8","#FDBB84","#E34A33","#B30000")

# ✅ 关键：自定义“锚点”(anchors) 来控制哪里更显色
# 解释：
# - 负端只占 1/4，所以负端压缩（-0.5 到 -0.1）
# - 0 附近到 0.3 是你数据最密集的区域，放密一些锚点让它更“红橙分明”
anchors <- c(-0.5, -0.20, -0.05, 0.00, 0.20, 0.60, 1.00)

# 把 anchors 映射到 0~1（gradientn 的 values）
vals <- rescale(anchors, to = c(0, 1), from = limits)

# 图例刻度（你也可以按论文叙事改）
brks <- c(-0.5, -0.25, 0, 0.25, 0.5, 0.75, 1.0)

# =========================
# 4) Main map (NO legend) + remove grid
# =========================
p_map <- ggplot() +
  geom_sf(data = world, fill = "grey88", color = "grey70", linewidth = 0.25) +
  geom_sf(data = pts, aes(color = plot_val), size = 0.65, alpha = 0.95) +
  scale_color_gradientn(
    colours = cols,
    values  = vals,
    limits  = limits,
    oob     = scales::squish,
    breaks  = brks,
    labels  = label_number(accuracy = 0.01),
    name    = NULL,
    guide   = "none"
  ) +
  coord_sf(expand = FALSE, xlim = c(-150, 150), ylim = c(-60, 80)) +
  scale_x_continuous(
    breaks = seq(-150, 150, by = 60),
    labels = function(x) paste0(ifelse(x==0, "0", abs(x)), "°",
                                ifelse(x<0, "W", ifelse(x>0, "E", "")))
  ) +
  scale_y_continuous(
    breaks = seq(-30, 60, by = 30),
    labels = function(y) paste0(ifelse(y==0, "0", abs(y)), "°",
                                ifelse(y<0, "S", ifelse(y>0, "N", "")))
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.background  = element_rect(fill = "white", color = NA),
    # ✅ 去网格线
    panel.grid.major  = element_blank(),
    panel.grid.minor  = element_blank(),
    axis.title        = element_blank(),
    axis.text         = element_text(color = "grey25", size = 9),
    axis.ticks        = element_line(color = "grey60", linewidth = 0.3),
    axis.ticks.length = unit(2.0, "mm"),
    panel.border      = element_rect(color = "grey40", fill = NA, linewidth = 0.6),
    plot.margin       = margin(5, 10, 5, 10)
  )

ggsave(OUT_MAP_SVG, p_map, width = 12, height = 5.2, device = svglite::svglite)
ggsave(OUT_MAP_PDF, p_map, width = 12, height = 5.2)

# =========================
# 5) Legend-only plot -> extract legend -> save
# =========================
LEG_TITLE <- "Heat dT (degC)"  # 避免 °C 编码警告

p_leg_src <- ggplot() +
  geom_sf(data = world, fill = "grey88", color = "grey70", linewidth = 0.25) +
  geom_sf(data = pts, aes(color = plot_val), size = 0.65, alpha = 0.95) +
  scale_color_gradientn(
    colours = cols,
    values  = vals,
    limits  = limits,
    oob     = scales::squish,
    breaks  = brks,
    labels  = label_number(accuracy = 0.01),
    name    = LEG_TITLE,
    guide   = guide_colorbar(
      barheight = unit(50, "mm"),
      barwidth  = unit(6,  "mm"),
      ticks.colour = "grey30",
      frame.colour = "grey30"
    )
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.grid.major  = element_blank(),
    panel.grid.minor  = element_blank(),
    legend.position = "left",
    legend.title = element_text(size = 10),
    legend.text  = element_text(size = 9)
  )

leg <- cowplot::get_legend(p_leg_src)

ggsave(OUT_LEG_SVG, leg, width = 1.8, height = 2.8, device = svglite::svglite)
ggsave(OUT_LEG_PDF, leg, width = 1.8, height = 2.8)

message("Done!\n- ", OUT_MAP_SVG, "\n- ", OUT_LEG_SVG)

# =========================
# 6) COMBINE map + legend (legend in bottom-left) -> save final
# =========================

OUT_FINAL_SVG <- "map_deltT_signBlueRed2_withLegend.svg"
OUT_FINAL_PDF <- "map_deltT_signBlueRed2_withLegend.pdf"

# 你可以微调这四个数：
# x, y: 左下角位置（0~1，相对整张图）
# w, h: 图例占的相对宽高（0~1）
LEG_X <- 0.06
LEG_Y <- 0.02
LEG_W <- 0.18
LEG_H <- 0.55
LEG_SCALE <- 0.30

p_final <- cowplot::ggdraw() +
  cowplot::draw_plot(p_map, x = 0, y = 0, width = 1, height = 1) +
  cowplot::draw_grob(
    leg,
    x = LEG_X, y = LEG_Y, width = LEG_W, height = LEG_H,
    scale = LEG_SCALE, hjust = 0, vjust = 0
  )

# 导出成品（尺寸与地图一致）
ggsave(OUT_FINAL_SVG, p_final, width = 12, height = 5.2, device = svglite::svglite)
ggsave(OUT_FINAL_PDF, p_final, width = 12, height = 5.2)
