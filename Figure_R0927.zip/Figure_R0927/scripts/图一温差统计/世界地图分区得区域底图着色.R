suppressPackageStartupMessages({
  library(sf)
  library(dplyr)
  library(ggplot2)
  library(svglite)
  library(rnaturalearth)
})
sf::sf_use_s2(FALSE)

# =========================
# 1) 区域划分（修正：保证 China 进 EAS）
# =========================
region_order <- c("EUR","MED","FSU","EAS","NAM","SEA","AFN","AFS","SAS","PAN","CSA")

pal_region <- c(
  "NAM"="#2C6BE0",
  "CSA"="#66A3FF",
  "EUR"="#7BC4E6",
  "MED"="#31B7B7",
  "AFN"="#52C06C",
  "AFS"="#1F8F3A",
  "FSU"="#E6E85B",
  "EAS"="#C11A0D",
  "SEA"="#F08A1C",
  "SAS"="#F3B44A",
  "PAN"="#D8C84B"
)

# =========================
# 2) 读世界边界（国家级）并先 wrap_dateline（关键修正）
# =========================
world <- ne_countries(scale = "medium", returnclass = "sf") %>%
  st_transform(4326) %>%
  st_make_valid()

# 国家级先 wrap，避免你现在那种“union 后再 wrap”产生的全球横条伪影
world_wrapped <- st_wrap_dateline(
  world,
  options = c("WRAPDATELINE=YES", "DATELINEOFFSET=180")
) %>%
  st_make_valid()

# 用点在面上分区（避免 centroid 掉海里）
pts <- st_point_on_surface(world_wrapped)
xy  <- st_coordinates(pts)
world_wrapped$lon_pt <- xy[,1]
world_wrapped$lat_pt <- xy[,2]

# ---------------------------------------------------------
# Region10 assignment (country-attribute based)
# 目标：更贴近 Science 图：MED = Middle East + North Africa
#      AFR 按赤道分 AFN/AFS；FSU = former Soviet union；其余按常规地理分区
# ---------------------------------------------------------

# 常用国家清单（按 Science 图常见分法）
fsu_countries <- c(
  "Russia","Ukraine","Belarus","Moldova",
  "Estonia","Latvia","Lithuania",
  "Georgia","Armenia","Azerbaijan",
  "Kazakhstan","Kyrgyzstan","Tajikistan","Turkmenistan","Uzbekistan"
)

eas_countries <- c(
  "China","Mongolia","Japan","North Korea","South Korea","Taiwan"
)

sas_countries <- c(
  "India","Pakistan","Bangladesh","Nepal","Bhutan","Sri Lanka","Afghanistan"
)

sea_countries <- c(
  "Myanmar","Thailand","Laos","Cambodia","Vietnam","Malaysia","Singapore",
  "Indonesia","Philippines","Brunei","Timor-Leste"
)

nam_countries <- c(
  "Canada","United States of America","Mexico","Greenland"
)

pan_countries <- c(
  "Australia","New Zealand","Papua New Guinea","Fiji","Solomon Islands",
  "Vanuatu","Samoa","Tonga","Micronesia","Palau","Marshall Islands",
  "Kiribati","Tuvalu","Nauru","New Caledonia"
)

# MED：只保留 Middle East / West Asia（不包含非洲）
med_countries <- c(
  "Turkey","Cyprus","Syria","Lebanon","Israel","Jordan","Iraq","Iran",
  "Saudi Arabia","Yemen","Oman","United Arab Emirates","Qatar","Kuwait","Bahrain"
)

# 注意：ne_countries() 的国家名在 world$admin / world$name_long 里
# 我们优先用 admin（最稳定），匹配不到再用 name_long
world_wrapped <- world_wrapped %>%
  mutate(
    .name = dplyr::coalesce(.data$admin, .data$name_long, .data$name),
    .continent = dplyr::coalesce(.data$continent, NA_character_),
    .subregion = dplyr::coalesce(.data$subregion, NA_character_)
  )

# 先做“粗分区”（不处理非洲南北）
world_wrapped$Region10 <- dplyr::case_when(
  # Former Soviet Union
  world_wrapped$.name %in% fsu_countries ~ "FSU",
  
  # North America
  world_wrapped$.name %in% nam_countries ~ "NAM",
  world_wrapped$.continent == "North America" ~ "NAM",
  
  # Central & South America（含 Caribbean 你也可以并到 NAM，看你习惯）
  world_wrapped$.continent == "South America" ~ "CSA",
  (world_wrapped$.continent == "North America" &
     world_wrapped$.subregion %in% c("Central America","Caribbean")) ~ "CSA",
  
  # Europe（把俄罗斯等 FSU 已经提前吃掉了）
  world_wrapped$.continent == "Europe" ~ "EUR",
  
  # MED（北非+中东/西亚）
  (world_wrapped$.name %in% med_countries) & (world_wrapped$.continent != "Africa") ~ "MED",
  
  # East Asia / South Asia / Southeast Asia
  world_wrapped$.name %in% eas_countries ~ "EAS",
  world_wrapped$.name %in% sas_countries ~ "SAS",
  world_wrapped$.name %in% sea_countries ~ "SEA",
  
  # PAN（澳新+大洋洲）
  world_wrapped$.name %in% pan_countries ~ "PAN",
  world_wrapped$.continent == "Oceania" ~ "PAN",
  
  # Africa：先标 AFR，下面再按赤道切 AFN/AFS
  world_wrapped$.continent == "Africa" ~ "AFR",
  
  TRUE ~ "OTHER"
)

# 非洲按赤道切成 AFN/AFS（用你已经算好的 lat_pt）
world_wrapped$Region10 <- ifelse(
  world_wrapped$Region10 == "AFR" & !is.na(world_wrapped$lat_pt),
  ifelse(world_wrapped$lat_pt >= 0, "AFN", "AFS"),
  world_wrapped$Region10
)

# 清理临时列
world_wrapped <- world_wrapped %>% select(-.name, -.continent, -.subregion)

world2 <- world_wrapped %>%
  filter(Region10 %in% region_order) %>%
  mutate(Region10 = factor(Region10, levels = region_order))

# =========================
# 3) dissolve 成 10 个区域（wrap 已经做过了） + 去掉“横条伪影”(增强版)
# =========================
reg_poly <- world2 %>%
  group_by(Region10) %>%
  summarise(geometry = st_union(geometry), .groups = "drop") %>%
  st_make_valid()

# 1) 只取面，避免 GEOMETRYCOLLECTION/LINESTRING
reg_poly <- st_collection_extract(reg_poly, "POLYGON") %>%
  st_make_valid()

# 2) 拆成单个 polygon，做“细长横条”判别：bbox + 面积（投影后算）
reg_poly_parts <- reg_poly %>%
  st_cast("POLYGON", warn = FALSE) %>%
  mutate(
    .bbox = lapply(geometry, st_bbox),
    .w = vapply(.bbox, function(b) as.numeric(b["xmax"] - b["xmin"]), numeric(1)),
    .h = vapply(.bbox, function(b) as.numeric(b["ymax"] - b["ymin"]), numeric(1))
  )

# 投影到等面积坐标系算面积（m^2），比“度”稳定很多
reg_poly_parts$.area_m2 <- as.numeric(st_area(st_transform(reg_poly_parts, 6933)))

# 典型伪影：宽度极大 + 高度很小 + 面积很小（就是那条北极/高纬横带）
reg_poly_parts <- reg_poly_parts %>%
  mutate(
    .is_strip = (.w > 120 & .h < 6 & .area_m2 < 1e12) |   # 主规则：横贯全球但很薄、面积也小
      (.w > 160 & .h < 10 & .area_m2 < 2e12)    # 宽一些、稍厚一点的兜底
  ) %>%
  filter(!.is_strip) %>%
  select(-.bbox, -.w, -.h, -.area_m2, -.is_strip)

# 3) 合回每个 Region10 的 MULTIPOLYGON
reg_poly <- reg_poly_parts %>%
  group_by(Region10) %>%
  summarise(geometry = st_union(geometry), .groups = "drop") %>%
  st_cast("MULTIPOLYGON", warn = FALSE) %>%
  st_make_valid()
# =========================
# 4) 画长方形世界地图（加外边框）
# =========================
p <- ggplot() +
  geom_sf(
    data = reg_poly, aes(fill = Region10),
    color = "#4D4D4D", linewidth = 0.35
  ) +
  scale_fill_manual(values = pal_region, drop = FALSE) +
  coord_sf(
    crs = st_crs(4326),
    xlim = c(-180, 180), ylim = c(-60, 85),
    expand = FALSE
  ) +
  theme_void() +
  theme(
    legend.position = "none",
    plot.margin = margin(2, 2, 2, 2),
    # ✅ 外边框（长方形）
    panel.border = element_rect(color = "black", fill = NA, linewidth = 0.9)
  )

ggsave(
  "region10_world_map_rect2.svg", p,
  width = 9.2, height = 4.0,
  device = svglite::svglite
)
message("✅ Saved: region10_world_map_rect2.svg")