# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(svglite)
  library(stringr)
  library(sf)
  library(rnaturalearth)
  library(cowplot)
  library(rstatix)
  library(ggpubr)
})

sf::sf_use_s2(FALSE)

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/48/48plants_MR_pop_GDP2加SMOD2.xlsx"

COL_LAT  <- "Latitude"
COL_LON  <- "Longitude"
COL_TYPE <- "Type"
COL_Y    <- "delt_warm_min"

out_dir <- "region_boxplots_sig_svg"
dir.create(out_dir, showWarnings = FALSE)

type_levels <- c("coal", "oil/gas", "bioenergy")

type_pal <- c(
  "coal"      = "#d40d8c",
  "oil/gas"   = "#0070b8",
  "bioenergy" = "#00b3b0"
)

# =========================
# 1.5) Winsor + y axis
# =========================
WINSOR_P_LO <- 0.02
WINSOR_P_HI <- 0.98

USE_GLOBAL_YLIM_FROM_WINSOR <- TRUE

USE_MANUAL_YLIM <- FALSE
Y_MIN_MANUAL <- -1.5
Y_MAX_MANUAL <-  1.5

Y_BREAKS_STEP <- 0.5

# =========================
# 2) Climate-zone assignment
# =========================
zone_order <- c("Tropical", "Subtropical", "Temperate", "Cold")

assign_zone4 <- function(lat) {
  a <- abs(lat)
  
  dplyr::case_when(
    is.na(a) ~ NA_character_,
    a < 25 ~ "Tropical",
    a < 37.5 ~ "Subtropical",
    a < 50   ~ "Temperate",
    TRUE     ~ "Cold"
  )
}

# =========================
# 3) Read & clean
# =========================
df0 <- read_excel(excel_path)

need_cols <- c(COL_LAT, COL_LON, COL_TYPE, COL_Y)
stopifnot(all(need_cols %in% names(df0)))

df_clean <- df0 %>%
  transmute(
    lat  = suppressWarnings(as.numeric(.data[[COL_LAT]])),
    lon  = suppressWarnings(as.numeric(.data[[COL_LON]])),
    Type = as.character(.data[[COL_TYPE]]),
    y    = suppressWarnings(as.numeric(.data[[COL_Y]]))
  ) %>%
  filter(!is.na(lat), !is.na(lon), !is.na(Type), !is.na(y)) %>%
  filter(Type %in% type_levels) %>%
  mutate(
    Type = factor(Type, levels = type_levels)
  )

df <- df_clean %>%
  mutate(
    ClimateZone = assign_zone4(lat),
    ClimateZone = factor(ClimateZone, levels = zone_order)
  ) %>%
  filter(!is.na(ClimateZone))

# =========================
# 3.5) Winsorize
# =========================
q_lo <- as.numeric(
  quantile(df$y, probs = WINSOR_P_LO, na.rm = TRUE)
)

q_hi <- as.numeric(
  quantile(df$y, probs = WINSOR_P_HI, na.rm = TRUE)
)

df <- df %>%
  mutate(
    y_w = pmin(pmax(y, q_lo), q_hi)
  )

if (USE_MANUAL_YLIM) {
  
  y_min <- Y_MIN_MANUAL
  y_max <- Y_MAX_MANUAL
  
} else if (USE_GLOBAL_YLIM_FROM_WINSOR) {
  
  y_min <- q_lo
  y_max <- q_hi
  
} else {
  
  y_min <- min(df$y_w, na.rm = TRUE)
  y_max <- max(df$y_w, na.rm = TRUE)
}

# 给显著性留空间
y_range <- y_max - y_min
y_max_plot <- y_max + 0.22 * y_range

y_breaks <- seq(
  from = floor(y_min / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  to   = ceiling(y_max_plot / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  by   = Y_BREAKS_STEP
)

# =========================
# 4) 显著性检验
# 每个 ClimateZone 内：
# coal vs oil/gas
# coal vs bioenergy
# oil/gas vs bioenergy
# =========================
sig_df <- df %>%
  group_by(ClimateZone) %>%
  pairwise_wilcox_test(
    y ~ Type,
    p.adjust.method = "BH"
  ) %>%
  ungroup()

# 显著性符号
sig_df <- sig_df %>%
  mutate(
    p_label = case_when(
      p.adj < 0.001 ~ "***",
      p.adj < 0.01  ~ "**",
      p.adj < 0.05  ~ "*",
      TRUE          ~ "ns"
    )
  )

# 每个 zone 的显著性高度
zone_ypos <- tibble(
  ClimateZone = factor(zone_order, levels = zone_order),
  y.position = c(
    y_max + 0.05 * y_range,
    y_max + 0.10 * y_range,
    y_max + 0.15 * y_range
  )[1]
)

sig_df <- sig_df %>%
  left_join(zone_ypos, by = "ClimateZone")

# 为不同比较设置不同高度
sig_df <- sig_df %>%
  group_by(ClimateZone) %>%
  mutate(
    y.position = seq(
      y_max + 0.05 * y_range,
      y_max + 0.15 * y_range,
      length.out = n()
    )
  ) %>%
  ungroup()

# 保存检验结果
write.csv(
  sig_df,
  file.path(out_dir, "zone_significance_results.csv"),
  row.names = FALSE
)

print(sig_df)

# 只用于绘图：不显示 ns
sig_df <- sig_df %>%
  filter(p.adj < 0.05)

# =========================
# 5) Plot function
# =========================
plot_one_region <- function(
    dat_region,
    reg_code,
    y_min,
    y_max_plot,
    y_breaks,
    sig_sub
){
  
  ggplot(
    dat_region,
    aes(x = Type, y = y_w, fill = Type)
  ) +
    
    geom_point(
      position = position_jitter(width = 0.18, height = 0),
      size = 1.1,
      alpha = 0.25,
      color = "black"
    ) +
    
    geom_boxplot(
      width = 0.35,
      outlier.shape = NA,
      color = "black",
      fill = "white",
      linewidth = 0.7
    ) +
    
    geom_boxplot(
      width = 0.35,
      outlier.shape = NA,
      alpha = 0.48,
      color = NA
    ) +
    
    stat_pvalue_manual(
      sig_sub,
      label = "p_label",
      xmin = "group1",
      xmax = "group2",
      y.position = "y.position",
      tip.length = 0.015,
      bracket.size = 0.5,
      size = 4
    ) +
    
    scale_fill_manual(values = type_pal, drop = FALSE) +
    
    scale_y_continuous(
      limits = c(y_min, y_max_plot),
      breaks = y_breaks,
      expand = c(0, 0)
    ) +
    
    labs(
      x = NULL,
      y = expression(Delta*T)
    ) +
    
    ggtitle(reg_code) +
    
    theme_bw(base_size = 12) +
    
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      
      panel.border = element_rect(
        color = "black",
        fill = NA,
        linewidth = 1.1
      ),
      
      plot.title = element_text(
        face = "bold",
        size = 13,
        hjust = 0.5
      ),
      
      axis.text.x = element_text(size = 11),
      axis.ticks.x = element_line(linewidth = 0.8),
      
      axis.text.y = element_text(size = 11),
      axis.title.y = element_text(size = 12),
      
      legend.position = "none",
      
      plot.margin = margin(6, 6, 6, 6)
    )
}

# =========================
# 6) Export loop
# =========================
regions_to_export <- df %>%
  distinct(ClimateZone) %>%
  arrange(ClimateZone) %>%
  pull(ClimateZone) %>%
  as.character()

plot_list <- vector("list", length(regions_to_export))
names(plot_list) <- regions_to_export

for (reg in regions_to_export) {
  
  dat_reg <- df %>%
    filter(ClimateZone == reg)
  
  if (nrow(dat_reg) == 0) next
  
  sig_reg <- sig_df %>%
    filter(ClimateZone == reg)
  
  p <- plot_one_region(
    dat_region = dat_reg,
    reg_code = reg,
    y_min = y_min,
    y_max_plot = y_max_plot,
    y_breaks = y_breaks,
    sig_sub = sig_reg
  )
  
  out_svg <- file.path(
    out_dir,
    paste0("zone_", reg, "_box_sig.svg")
  )
  
  ggsave(
    out_svg,
    p,
    width = 3.2,
    height = 3.3,
    device = svglite::svglite
  )
  
  message(
    "Saved: ",
    out_svg,
    " (n=", nrow(dat_reg), ")"
  )
  
  plot_list[[reg]] <- p
}

# =========================
# 7) Combine
# =========================
plot_list <- plot_list[
  !vapply(plot_list, is.null, logical(1))
]

zone_order_fixed <- c(
  "Tropical",
  "Subtropical",
  "Temperate",
  "Cold"
)

zone_order_fixed <- zone_order_fixed[
  zone_order_fixed %in% names(plot_list)
]

combined <- cowplot::plot_grid(
  plotlist = plot_list[zone_order_fixed],
  nrow = 1,
  align = "hv",
  axis = "tblr"
)

out_combined_svg <- file.path(
  out_dir,
  "zones_4panel_horizontal_sig.svg"
)

ggsave(
  out_combined_svg,
  combined,
  width = 3.2 * length(zone_order_fixed),
  height = 3.3,
  device = svglite::svglite
)

message("✅ Saved combined: ", out_combined_svg)

# =========================
# 8) Legend SVG
# =========================
legend_plot <- ggplot(
  data.frame(
    Type = factor(type_levels, levels = type_levels)
  ),
  aes(x = Type, y = 1, fill = Type)
) +
  
  geom_tile(
    width = 0.9,
    height = 0.9,
    color = NA
  ) +
  
  scale_fill_manual(
    values = type_pal,
    drop = FALSE
  ) +
  
  guides(
    fill = guide_legend(
      title = NULL,
      direction = "vertical",
      byrow = TRUE,
      keywidth  = unit(8, "mm"),
      keyheight = unit(6, "mm"),
      label.position = "right",
      label.hjust = 0,
      default.unit = "mm"
    )
  ) +
  
  theme_void(base_size = 12) +
  
  theme(
    legend.position = "right",
    legend.text = element_text(size = 12),
    legend.key = element_rect(color = NA, fill = NA),
    legend.spacing.y = unit(2, "mm")
  )

leg <- cowplot::get_legend(legend_plot)

out_legend_svg <- file.path(
  out_dir,
  "legend_type.svg"
)

ggsave(
  out_legend_svg,
  plot = leg,
  width = 2.4,
  height = 1.2,
  device = svglite::svglite
)

message("Saved legend: ", out_legend_svg)