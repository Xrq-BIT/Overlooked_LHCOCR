suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(scales)
  library(svglite)
  library(rsvg)
})

excel_path <- paste0(
  "/Users/xuruiqing/Desktop/文章试验整体流程/",
  "0706专注煤电与微气候反事实/",
  "coal_plants_with_LSM_10km_productivity副本2.xlsx"
)
out_dir <- paste0(
  "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图一温差统计/",
  "plant_level_LSM_dT_Q1_Q4_vulnerable"
)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

df <- read_excel(excel_path) %>%
  transmute(
    lsm_dT = suppressWarnings(as.numeric(lsm_delta_t2_mean_c)),
    child_share = suppressWarnings(as.numeric(ratio_10km_child_0_4)),
    old_share = suppressWarnings(as.numeric(ratio_10km_old_worldpop2020))
  ) %>%
  filter(is.finite(lsm_dT)) %>%
  mutate(
    vulnerable_share = child_share + old_share,
    quartile = ntile(lsm_dT, 4),
    lsm_dT_group = case_when(
      quartile == 1L ~ "LSM ΔT Q1 (low)",
      quartile == 4L ~ "LSM ΔT Q4 (high)",
      TRUE ~ NA_character_
    ),
    lsm_dT_group = factor(
      lsm_dT_group,
      levels = c("LSM ΔT Q1 (low)", "LSM ΔT Q4 (high)")
    )
  ) %>%
  filter(
    quartile %in% c(1L, 4L),
    is.finite(vulnerable_share)
  )

group_values <- split(df$vulnerable_share, df$lsm_dT_group)
q1 <- group_values[["LSM ΔT Q1 (low)"]]
q4 <- group_values[["LSM ΔT Q4 (high)"]]
wilcox_test <- wilcox.test(
  q1, q4,
  alternative = "two.sided",
  exact = FALSE,
  conf.int = TRUE
)
p_value <- unname(wilcox_test$p.value)
sig_label <- case_when(
  p_value < 0.001 ~ "***",
  p_value < 0.01 ~ "**",
  p_value < 0.05 ~ "*",
  TRUE ~ "ns"
)

test_table <- data.frame(
  test = "Two-sided Wilcoxon rank-sum test",
  q1_n = length(q1),
  q4_n = length(q4),
  q1_median = median(q1),
  q4_median = median(q4),
  median_difference_q4_minus_q1 = median(q4) - median(q1),
  hodges_lehmann_q4_minus_q1 = -unname(wilcox_test$estimate),
  ci_low = -unname(wilcox_test$conf.int[2]),
  ci_high = -unname(wilcox_test$conf.int[1]),
  W = unname(wilcox_test$statistic),
  p_value = p_value,
  significance = sig_label
)
summary_table <- df %>%
  group_by(lsm_dT_group) %>%
  summarise(
    n = n(),
    mean_vulnerable_share = mean(vulnerable_share),
    median_vulnerable_share = median(vulnerable_share),
    q25_vulnerable_share = quantile(vulnerable_share, 0.25),
    q75_vulnerable_share = quantile(vulnerable_share, 0.75),
    .groups = "drop"
  )
write.csv(
  test_table,
  file.path(out_dir, "LSM_dT_Q1_Q4_vulnerable_wilcoxon_test.csv"),
  row.names = FALSE
)
write.csv(
  summary_table,
  file.path(out_dir, "LSM_dT_Q1_Q4_vulnerable_summary.csv"),
  row.names = FALSE
)

y_min <- max(0, floor(min(df$vulnerable_share) * 10) / 10)
y_max <- max(df$vulnerable_share)
y_range <- y_max - y_min
bracket_y <- y_max + 0.055 * y_range
upper_y <- y_max + 0.145 * y_range
group_pal <- c(
  "LSM ΔT Q1 (low)" = "#C9DCE6",
  "LSM ΔT Q4 (high)" = "#C97A62"
)

p <- ggplot(
  df,
  aes(lsm_dT_group, vulnerable_share, fill = lsm_dT_group)
) +
  geom_point(
    position = position_jitter(width = 0.16, height = 0, seed = 123),
    size = 0.65, alpha = 0.10, color = "#333333", show.legend = FALSE
  ) +
  geom_boxplot(
    width = 0.45, outlier.shape = NA, alpha = 0.88,
    color = "#303030", linewidth = 0.62, show.legend = FALSE
  ) +
  annotate(
    "segment", x = 1, xend = 2, y = bracket_y, yend = bracket_y,
    linewidth = 0.55
  ) +
  annotate(
    "segment", x = 1, xend = 1,
    y = bracket_y - 0.02 * y_range, yend = bracket_y,
    linewidth = 0.55
  ) +
  annotate(
    "segment", x = 2, xend = 2,
    y = bracket_y - 0.02 * y_range, yend = bracket_y,
    linewidth = 0.55
  ) +
  annotate(
    "text", x = 1.5, y = bracket_y + 0.025 * y_range,
    label = sig_label, size = 4, fontface = "bold"
  ) +
  scale_fill_manual(values = group_pal) +
  scale_y_continuous(
    labels = percent_format(accuracy = 1),
    limits = c(y_min, upper_y),
    expand = expansion(mult = c(0, 0))
  ) +
  labs(x = NULL, y = "Vulnerable population share") +
  theme_classic(base_size = 12) +
  theme(
    panel.grid = element_blank(),
    panel.border = element_rect(
      fill = NA, color = "#4C4C4C", linewidth = 0.45
    ),
    axis.line = element_blank(),
    axis.ticks = element_line(color = "#666666", linewidth = 0.35),
    axis.text.x = element_text(size = 10.5, color = "#3F3F3F"),
    axis.text.y = element_text(size = 10.5, color = "#3F3F3F"),
    axis.title = element_text(size = 12),
    legend.position = "none",
    plot.margin = margin(6, 6, 6, 6)
  )

svg_path <- file.path(
  out_dir, "plant_vulnerable_Q1_Q4_LSM_dT_wilcoxon_boxplot.svg"
)
pdf_path <- file.path(
  out_dir, "plant_vulnerable_Q1_Q4_LSM_dT_wilcoxon_boxplot.pdf"
)
ggsave(svg_path, p, width = 4, height = 3.6, device = svglite::svglite)
rsvg_pdf(svg_path, pdf_path)
ggsave(
  file.path(out_dir, "plant_vulnerable_Q1_Q4_LSM_dT_wilcoxon_boxplot.png"),
  p, width = 4, height = 3.6, dpi = 600, bg = "white"
)

print(test_table)
cat("Outputs written to:", normalizePath(out_dir), "\n")
