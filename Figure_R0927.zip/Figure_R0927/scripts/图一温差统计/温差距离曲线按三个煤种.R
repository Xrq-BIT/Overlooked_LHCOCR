# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(tidyr)
  library(ggplot2)
  library(svglite)
})

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/48/48plants_MR_pop_GDP2加SMOD2.xlsx"

COL_TYPE <- "Type"

temp_cols <- c(
  "T_poly_warm_mean",
  "T_r0_1",
  "T_r1_2",
  "T_r2_3",
  "T_r3_4"
)

dist_levels <- c("poly", "r0_1", "r1_2", "r2_3", "r3_4")

PLOT_DELTA <- TRUE

OUT_SVG <- "decay_by_type_with_CI.svg"
OUT_PDF <- "decay_by_type_with_CI.pdf"

type_levels <- c("coal", "oil/gas", "bioenergy")

pal3 <- c(
  "coal"      = "#d40d8c",
  "oil/gas"   = "#0070b8",
  "bioenergy" = "#00b3b0"
)

# =========================
# 2) Read
# =========================
df <- read_excel(excel_path) %>%
  select(all_of(c(COL_TYPE, temp_cols))) %>%
  filter(!is.na(.data[[COL_TYPE]])) %>%
  filter(.data[[COL_TYPE]] %in% type_levels) %>%
  mutate(Type = factor(.data[[COL_TYPE]], levels = type_levels))

# =========================
# 3) Wide -> Long
# =========================
long <- df %>%
  mutate(id = row_number()) %>%
  pivot_longer(
    cols = all_of(temp_cols),
    names_to = "dist",
    values_to = "temp"
  ) %>%
  mutate(
    dist = case_when(
      dist == "T_poly_warm_mean" ~ "poly",
      TRUE ~ sub("T_", "", dist)
    ),
    dist = factor(dist, levels = dist_levels, ordered = TRUE)
  ) %>%
  filter(!is.na(temp))

# =========================
# 4) ΔT vs 3-4 km background
# =========================
if (PLOT_DELTA) {
  ref <- long %>%
    filter(dist == "r3_4") %>%
    select(id, ref_temp = temp)
  
  long <- long %>%
    left_join(ref, by = "id") %>%
    mutate(y = temp - ref_temp)
  
  ylab <- expression(Delta*T~"(°C)")
} else {
  long <- long %>% mutate(y = temp)
  ylab <- "Temperature (°C)"
}

# =========================
# 5) Aggregate: mean + 95% CI
# =========================
agg <- long %>%
  group_by(Type, dist) %>%
  summarise(
    mean_y = mean(y, na.rm = TRUE),
    n      = sum(!is.na(y)),
    sd_y   = sd(y, na.rm = TRUE),
    se_y   = sd_y / sqrt(n),
    ci_lo  = mean_y - 1.96 * se_y,
    ci_hi  = mean_y + 1.96 * se_y,
    .groups = "drop"
  ) %>%
  mutate(x = as.numeric(dist) - 1)

# =========================
# 6) Smooth mean + CI
# =========================
x_grid <- seq(0, 4, length.out = 200)

curve_df <- agg %>%
  arrange(Type, x) %>%
  group_by(Type) %>%
  summarise(
    data = list({
      f_mean <- splinefun(x, mean_y, method = "monoH.FC")
      f_lo   <- splinefun(x, ci_lo,  method = "monoH.FC")
      f_hi   <- splinefun(x, ci_hi,  method = "monoH.FC")
      
      tibble(
        x = x_grid,
        y = f_mean(x_grid),
        ymin = f_lo(x_grid),
        ymax = f_hi(x_grid)
      )
    }),
    .groups = "drop"
  ) %>%
  unnest(data)

# =========================
# 7) Plot
# =========================
p <- ggplot(curve_df, aes(x = x, y = y, color = Type, fill = Type)) +
  
  geom_ribbon(
    aes(ymin = ymin, ymax = ymax),
    alpha = 0.16,
    color = NA
  ) +
  
  geom_line(linewidth = 1.1) +
  
  geom_point(
    data = agg,
    aes(x = x, y = mean_y, color = Type),
    size = 1.8,
    inherit.aes = FALSE
  ) +
  
  scale_color_manual(values = pal3, name = "Type") +
  scale_fill_manual(values = pal3, name = "Type") +
  
  scale_x_continuous(
    breaks = 0:4,
    labels = 0:4,
    limits = c(0, 4),
    expand = c(0, 0)
  ) +
  
  scale_y_continuous(
    limits = c(0, max(curve_df$ymax, na.rm = TRUE) * 1.05),
    expand = c(0, 0)
  ) +
  
  labs(
    x = "Distance (km)",
    y = ylab
  ) +
  
  theme_bw(base_size = 12) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1.1),
    
    axis.ticks = element_line(linewidth = 1),
    axis.ticks.length = unit(4, "pt"),
    
    axis.text = element_text(size = 11),
    axis.title = element_text(size = 12),
    
    legend.position = c(0.82, 0.95),
    legend.justification = c(0, 1),
    legend.background = element_rect(fill = "white", color = "black", linewidth = 0.35),
    legend.key = element_blank(),
    legend.title = element_text(size = 10),
    legend.text = element_text(size = 9),
    
    plot.margin = margin(8, 8, 8, 8)
  )

# =========================
# 8) Export
# =========================
ggsave(OUT_SVG, p, width = 7.2, height = 5.2, device = svglite::svglite)
ggsave(OUT_PDF, p, width = 7.2, height = 5.2)

message("Done: ", OUT_SVG)