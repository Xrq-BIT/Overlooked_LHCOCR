suppressPackageStartupMessages({
  library(xml2)
  library(rsvg)
})

# Preserve the existing panels and statistics; only change the layout.
base <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图一温差统计/Fig1_complete_composite"
source <- file.path(base, "Fig1_complete_delta_HWN_vulnerable_GDP_4cases.svg")
out <- file.path(base, "Fig1_abcdefgh_no_ij")
before <- tools::md5sum(source)
doc <- read_xml(source)
root <- xml_root(doc)
panels <- xml_find_all(root, "./*[local-name()='svg']")
stopifnot(length(panels) == 10)
unchanged <- vapply(panels[c(1:5, 10)], as.character, character(1))

# Stretch the plotting coordinates without distorting text or point symbols.
layout_panel <- function(panel, left, right, old_bottom) {
  s <- 0.85
  frame_left <- 40.78 * s
  frame_width <- right - left
  sx <- frame_width / (354.02 - 40.78)
  sy <- 255 / (old_bottom - 5.98)
  mx <- function(v) ifelse(v < 40.78, v * s,
    ifelse(v > 354.02, frame_left + frame_width + (v - 354.02) * s,
      frame_left + (v - 40.78) * sx))
  my <- function(v) 5.98 * s + (v - 5.98) * sy
  fmt <- function(v) sprintf("%.4f", v)
  for (n in xml_find_all(panel, ".//*")) {
    attrs <- xml_attrs(n)
    for (key in intersect(names(attrs), c("x", "x1", "x2", "cx")))
      xml_set_attr(n, key, fmt(mx(as.numeric(attrs[[key]]))))
    for (key in intersect(names(attrs), c("y", "y1", "y2", "cy")))
      xml_set_attr(n, key, fmt(my(as.numeric(attrs[[key]]))))
    if ("width" %in% names(attrs) && !grepl("%", attrs[["width"]])) {
      x <- if ("x" %in% names(attrs)) as.numeric(attrs[["x"]]) else 0
      xml_set_attr(n, "width", fmt(mx(x + as.numeric(attrs[["width"]])) - mx(x)))
    }
    if ("height" %in% names(attrs) && !grepl("%", attrs[["height"]]))
      xml_set_attr(n, "height", fmt(as.numeric(attrs[["height"]]) * sy))
    if ("r" %in% names(attrs)) xml_set_attr(n, "r", fmt(as.numeric(attrs[["r"]]) * s))
    if ("points" %in% names(attrs)) {
      pts <- matrix(as.numeric(strsplit(trimws(attrs[["points"]]), "[,[:space:]]+")[[1]]), ncol = 2, byrow = TRUE)
      xml_set_attr(n, "points", paste(paste(fmt(mx(pts[, 1])), fmt(my(pts[, 2])), sep = ","), collapse = " "))
    }
    if ("transform" %in% names(attrs)) {
      tr <- attrs[["transform"]]
      hit <- regmatches(tr, regexec("translate\\(([-0-9.]+),([-0-9.]+)\\)", tr))[[1]]
      stopifnot(length(hit) == 3)
      tr <- sub("translate\\([^)]+\\)", paste0("translate(", fmt(mx(as.numeric(hit[2]))), ",", fmt(my(as.numeric(hit[3]))), ")"), tr)
      xml_set_attr(n, "transform", tr)
    }
    if ("textLength" %in% names(attrs))
      xml_set_attr(n, "textLength", paste0(fmt(as.numeric(sub("px$", "", attrs[["textLength"]])) * s), "px"))
    if ("style" %in% names(attrs)) {
      st <- attrs[["style"]]
      for (prop in c("font-size", "stroke-width")) {
        hit <- regmatches(st, regexec(paste0(prop, ": *([0-9.]+)"), st))[[1]]
        if (length(hit) == 2) st <- sub(paste0(prop, ": *[0-9.]+"), paste0(prop, ": ", fmt(as.numeric(hit[2]) * s)), st)
      }
      xml_set_attr(n, "style", st)
    }
  }
  width <- mx(360)
  height <- my(324)
  xml_set_attrs(panel, c(x = fmt(left - frame_left), y = fmt(715 - 5.98 * s),
    width = fmt(width), height = fmt(height), viewBox = paste("0 0", fmt(width), fmt(height))))
}

layout_panel(panels[[6]], 114.85, 582.735, 302.92)
layout_panel(panels[[7]], 672.735, 1140.62, 301.53)
# Match h box and median widths to g without moving points or whiskers.
box_points <- function(n) matrix(as.numeric(strsplit(trimws(xml_attr(n, "points")), "[,[:space:]]+")[[1]]), ncol = 2, byrow = TRUE)
target_width <- diff(range(box_points(xml_find_all(panels[[6]], ".//*[local-name()='polygon']")[[1]])[, 1]))
for (box in xml_find_all(panels[[7]], ".//*[local-name()='polygon']")) {
  pts <- box_points(box)
  edges <- range(pts[, 1])
  centre <- mean(edges)
  pts[, 1] <- centre + (pts[, 1] - centre) * target_width / diff(edges)
  xml_set_attr(box, "points", paste(sprintf("%.4f,%.4f", pts[, 1], pts[, 2]), collapse = " "))
  for (line in xml_find_all(panels[[7]], ".//*[local-name()='line']")) {
    if (abs(as.numeric(xml_attr(line, "x1")) - edges[1]) < 0.001 &&
        abs(as.numeric(xml_attr(line, "x2")) - edges[2]) < 0.001) {
      xml_set_attr(line, "x1", sprintf("%.4f", centre - target_width / 2))
      xml_set_attr(line, "x2", sprintf("%.4f", centre + target_width / 2))
    }
  }
}
xml_remove(panels[c(8, 9)])
labels <- xml_find_all(root, "./*[local-name()='text']")
xml_remove(labels[xml_text(labels) %in% c("i", "j")])
for (label in c("g", "h")) {
  n <- labels[xml_text(labels) == label]
  xml_set_attr(n, "x", if (label == "g") "65" else "622.885")
  xml_set_attr(n, "y", "700")
}
xml_set_attr(root, "height", "1010pt")
xml_set_attr(root, "viewBox", "0 0 1200 1010")
after_panels <- xml_find_all(root, "./*[local-name()='svg']")
stopifnot(all(unname(unchanged) == unname(vapply(after_panels[c(1:5, 8)], as.character, character(1)))))
write_xml(doc, paste0(out, ".svg"))
rsvg_pdf(paste0(out, ".svg"), paste0(out, ".pdf"))
rsvg_png(paste0(out, ".svg"), paste0(out, ".png"), width = 3000)
stopifnot(identical(before, tools::md5sum(source)))
cat("Saved:", out, "\nPanels a-f unchanged; original SVG unchanged.\n")
