suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(sf)
  library(ggplot2)
  library(rnaturalearth)
  library(scales)
  library(cowplot)
  library(svglite)
  library(grid)
})

# This is an overlay version. The original map script is not modified.
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/0706专注煤电与微气候反事实/coal_plants_with_LSM_10km_productivity副本2.xlsx"
out_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图一温差统计/heat_burden_overlay_map"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

LON_COL <- "Longitude"
LAT_COL <- "Latitude"
DT_COL <- "delt_warm_min"
HWN_COLS <- paste0("HWN_background_LSM_all_years_", 2011:2020)

OUT_MAP_SVG <- file.path(out_dir, "map_local_dT_background_HWN_no_legend.svg")
OUT_MAP_PDF <- file.path(out_dir, "map_local_dT_background_HWN_no_legend.pdf")
OUT_LEG_SVG <- file.path(out_dir, "legend_local_dT_background_HWN.svg")
OUT_LEG_PDF <- file.path(out_dir, "legend_local_dT_background_HWN.pdf")
OUT_FINAL_SVG <- file.path(out_dir, "map_local_dT_background_HWN_with_legend.svg")
OUT_FINAL_PDF <- file.path(out_dir, "map_local_dT_background_HWN_with_legend.pdf")
OUT_SUMMARY <- file.path(out_dir, "background_HWN_overlap_summary.csv")

# -------------------------
# Data
# -------------------------
df_raw <- read_excel(excel_path)
need_cols <- c(LON_COL, LAT_COL, DT_COL, HWN_COLS)
if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

df <- df_raw %>%
  mutate(
    local_dT = suppressWarnings(as.numeric(.data[[DT_COL]])),
    across(all_of(HWN_COLS), ~ suppressWarnings(as.numeric(.x))),
    background_HWN_mean = rowMeans(across(all_of(HWN_COLS)), na.rm = TRUE),
    background_HWN_mean = if_else(is.nan(background_HWN_mean), NA_real_, background_HWN_mean),
    background_HWN_plot = pmin(pmax(background_HWN_mean, 10), 30)
  ) %>%
  filter(!is.na(.data[[LON_COL]]), !is.na(.data[[LAT_COL]]))

pts_dt <- df %>%
  filter(!is.na(local_dT))

pts_hwn <- df %>%
  filter(!is.na(background_HWN_mean))

world <- ne_countries(scale = "medium", returnclass = "sf")

# -------------------------
# Scales: preserve the original local-dT palette
# -------------------------
dt_limits <- c(-0.5, 1.0)
dt_cols <- c("#08306B", "#2171B5", "#6BAED6", "#FEE8C8", "#FDBB84", "#E34A33", "#B30000")
dt_anchors <- c(-0.5, -0.20, -0.05, 0.00, 0.20, 0.60, 1.00)
dt_values <- rescale(dt_anchors, to = c(0, 1), from = dt_limits)
dt_breaks <- c(-0.5, -0.25, 0, 0.25, 0.5, 0.75, 1.0)

hwn_limits <- c(10, 30)
hwn_breaks <- c(10, 20, 30)

dt_scale <- scale_color_gradientn(
  colours = dt_cols,
  values = dt_values,
  limits = dt_limits,
  oob = squish,
  breaks = dt_breaks,
  labels = label_number(accuracy = 0.01),
  name = "Local dT (degC)"
)

hwn_scale <- scale_size_continuous(
  range = c(0.8, 4.2),
  breaks = hwn_breaks,
  name = "Background HWN\n(days yr-1)"
)

# -------------------------
# Main map: heat-burden halo + local-dT center
# -------------------------
p_map <- ggplot() +
  geom_sf(data = world, fill = "grey88", color = "grey70", linewidth = 0.25) +
  geom_point(
    data = pts_hwn,
    aes(
      x = .data[[LON_COL]],
      y = .data[[LAT_COL]],
      size = background_HWN_plot
    ),
    shape = 16,
    color = "#F28E2B",
    alpha = 0.18,
    show.legend = FALSE
  ) +
  geom_point(
    data = pts_dt,
    aes(
      x = .data[[LON_COL]],
      y = .data[[LAT_COL]],
      color = local_dT
    ),
    size = 0.62,
    alpha = 0.96,
    show.legend = FALSE
  ) +
  dt_scale +
  hwn_scale +
  coord_sf(expand = FALSE, xlim = c(-150, 150), ylim = c(-60, 80)) +
  scale_x_continuous(
    breaks = seq(-150, 150, by = 60),
    labels = function(x) paste0(
      ifelse(x == 0, "0", abs(x)), "\u00B0",
      ifelse(x < 0, "W", ifelse(x > 0, "E", ""))
    )
  ) +
  scale_y_continuous(
    breaks = seq(-30, 60, by = 30),
    labels = function(y) paste0(
      ifelse(y == 0, "0", abs(y)), "\u00B0",
      ifelse(y < 0, "S", ifelse(y > 0, "N", ""))
    )
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.background = element_rect(fill = "white", color = NA),
    panel.grid = element_blank(),
    axis.title = element_blank(),
    axis.text = element_text(color = "grey25", size = 9),
    axis.ticks = element_line(color = "grey60", linewidth = 0.3),
    axis.ticks.length = unit(2, "mm"),
    panel.border = element_rect(color = "grey40", fill = NA, linewidth = 0.6),
    plot.margin = margin(5, 10, 5, 10)
  )

ggsave(OUT_MAP_SVG, p_map, width = 12, height = 5.2, device = svglite::svglite)
ggsave(OUT_MAP_PDF, p_map, width = 12, height = 5.2, device = grDevices::pdf)

# -------------------------
# Combined legend
# -------------------------
p_leg_src <- ggplot() +
  geom_point(
    data = pts_hwn,
    aes(
      x = .data[[LON_COL]],
      y = .data[[LAT_COL]],
      size = background_HWN_plot
    ),
    shape = 16,
    color = "#F28E2B",
    alpha = 0.35
  ) +
  geom_point(
    data = pts_dt,
    aes(
      x = .data[[LON_COL]],
      y = .data[[LAT_COL]],
      color = local_dT
    ),
    size = 0.62,
    alpha = 0.96
  ) +
  dt_scale +
  hwn_scale +
  guides(
    color = guide_colorbar(
      order = 1,
      barheight = unit(34, "mm"),
      barwidth = unit(5.5, "mm"),
      ticks.colour = "grey30",
      frame.colour = "grey30"
    ),
    size = guide_legend(
      order = 2,
      override.aes = list(shape = 16, color = "#F28E2B", alpha = 0.35)
    )
  ) +
  theme_void(base_size = 11) +
  theme(
    legend.position = "left",
    legend.box = "vertical",
    legend.title = element_text(size = 9.5),
    legend.text = element_text(size = 8.5),
    legend.spacing.y = unit(1.5, "mm")
  )

leg <- cowplot::get_legend(p_leg_src)
ggsave(OUT_LEG_SVG, leg, width = 2.0, height = 3.4, device = svglite::svglite)
ggsave(OUT_LEG_PDF, leg, width = 2.0, height = 3.4, device = grDevices::pdf)

p_final <- cowplot::ggdraw() +
  cowplot::draw_plot(p_map, x = 0, y = 0, width = 1, height = 1) +
  cowplot::draw_grob(
    leg,
    x = 0.055,
    y = 0.015,
    width = 0.19,
    height = 0.64,
    scale = 0.46,
    hjust = 0,
    vjust = 0
  )

ggsave(OUT_FINAL_SVG, p_final, width = 12, height = 5.2, device = svglite::svglite)
ggsave(OUT_FINAL_PDF, p_final, width = 12, height = 5.2, device = grDevices::pdf)

# -------------------------
# Descriptive overlap statistics for the manuscript text/caption
# -------------------------
hwn <- pts_hwn$background_HWN_mean
overlap_df <- pts_hwn %>% filter(!is.na(local_dT))
summary_df <- data.frame(
  metric = c(
    "plants_with_local_dT",
    "plants_with_background_HWN",
    "background_HWN_mean",
    "background_HWN_median",
    "background_HWN_q25",
    "background_HWN_q75",
    "share_HWN_ge_15_days",
    "share_HWN_ge_18_days",
    "share_HWN_ge_20_days",
    "share_HWN_ge_15_and_local_dT_ge_0.2C",
    "spearman_background_HWN_vs_local_dT"
  ),
  value = c(
    nrow(pts_dt),
    nrow(pts_hwn),
    mean(hwn),
    median(hwn),
    quantile(hwn, 0.25),
    quantile(hwn, 0.75),
    mean(hwn >= 15),
    mean(hwn >= 18),
    mean(hwn >= 20),
    mean(overlap_df$background_HWN_mean >= 15 & overlap_df$local_dT >= 0.2),
    cor(
      overlap_df$background_HWN_mean,
      overlap_df$local_dT,
      method = "spearman",
      use = "complete.obs"
    )
  )
)
write.csv(summary_df, OUT_SUMMARY, row.names = FALSE)

message(
  "Done\n",
  "- ", OUT_FINAL_PDF, "\n",
  "- ", OUT_FINAL_SVG, "\n",
  "- ", OUT_SUMMARY
)
