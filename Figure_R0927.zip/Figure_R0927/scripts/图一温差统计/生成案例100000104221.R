# Reuse the accepted case-map script with case-specific inputs.
template_path <- paste0(
  "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图一温差统计/",
  "具体厂温度等温线环状图导出svg.R"
)
output_dir <- "/Users/xuruiqing/RData"

script <- readLines(template_path, warn = FALSE, encoding = "UTF-8")
script <- sub(
  '^tif_path <- ".*"$',
  'tif_path <- "/Users/xuruiqing/Downloads/plant_airtemp_polybands_2019_id_100000104221.tif"',
  script
)
script <- sub(
  '^OUT_MAP_SVG <- ".*"$',
  'OUT_MAP_SVG <- "44case_temp_map100000104221.svg"',
  script
)
script <- sub(
  '^OUT_LEG_SVG <- ".*"$',
  'OUT_LEG_SVG <- "44case_temp_legend100000104221.svg"',
  script
)
script <- sub(
  '^OUT_COMBINED_SVG <- ".*"$',
  'OUT_COMBINED_SVG <- "44case_temp_combined100000104221.svg"',
  script
)
script <- sub(
  '^CASE_LABEL <- ".*"$',
  'CASE_LABEL <- "Subbituminous (Carbon, USA)"',
  script
)

old_wd <- setwd(output_dir)
on.exit(setwd(old_wd), add = TRUE)
eval(parse(text = script), envir = new.env(parent = globalenv()))

