# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(svglite)
  library(ggdist)
})

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/48/48plants_MR_pop_GDP2加SMOD.xlsx"

COL_CAP  <- "Plant_Capacity"
COL_TYPE <- "Type"
COL_Y    <- "delt_warm_min"

out_dir <- "type_panel_capacity_raincloud_svg"
dir.create(out_dir, showWarnings = FALSE)

type_levels <- c("coal", "oil/gas", "bioenergy")

type_pal <- c(
  "coal"      = "#d40d8c",
  "oil/gas"   = "#0070b8",
  "bioenergy" = "#00b3b0"
)

# =========================
# 1.5) 统一 y 轴 + 抑制极端值
# =========================
WINSOR_P_LO <- 0.01
WINSOR_P_HI <- 0.99

USE_GLOBAL_YLIM_FROM_WINSOR <- TRUE

USE_MANUAL_YLIM <- FALSE
Y_MIN_MANUAL <- -1.5
Y_MAX_MANUAL <-  1.5

Y_BREAKS_STEP <- 0.2

# =========================
# 2) Capacity-group assignment
# 按每种燃料类型内部 33.3% / 66.6% 分位数划分
# =========================
cap_order <- c("Small", "Medium", "Large")

# =========================
# 3) Read & clean
# =========================
df0 <- read_excel(excel_path)

need_cols <- c(COL_CAP, COL_TYPE, COL_Y)
stopifnot(all(need_cols %in% names(df0)))

df <- df0 %>%
  transmute(
    cap  = suppressWarnings(as.numeric(.data[[COL_CAP]])),
    Type = as.character(.data[[COL_TYPE]]),
    y    = suppressWarnings(as.numeric(.data[[COL_Y]]))
  ) %>%
  filter(!is.na(cap), !is.na(Type), !is.na(y)) %>%
  filter(Type %in% type_levels) %>%
  mutate(
    Type = factor(Type, levels = type_levels)
  ) %>%
  group_by(Type) %>%
  mutate(
    q33 = as.numeric(stats::quantile(cap, probs = 0.333, na.rm = TRUE, type = 7)),
    q67 = as.numeric(stats::quantile(cap, probs = 0.666, na.rm = TRUE, type = 7)),
    CapacityGroup = dplyr::case_when(
      cap <= q33 ~ "Small",
      cap <= q67 ~ "Medium",
      TRUE       ~ "Large"
    ),
    CapacityGroup = factor(CapacityGroup, levels = cap_order)
  ) %>%
  ungroup() %>%
  filter(!is.na(CapacityGroup)) %>%
  select(-q33, -q67)

# =========================
# 3.5) 全局 winsorize + 统一 y 轴范围
# =========================
q_lo <- as.numeric(stats::quantile(df$y, probs = WINSOR_P_LO, na.rm = TRUE))
q_hi <- as.numeric(stats::quantile(df$y, probs = WINSOR_P_HI, na.rm = TRUE))

df <- df %>%
  mutate(
    y_w = pmin(pmax(y, q_lo), q_hi)
  )

if (USE_MANUAL_YLIM) {
  y_min <- Y_MIN_MANUAL
  y_max <- Y_MAX_MANUAL
} else if (USE_GLOBAL_YLIM_FROM_WINSOR) {
  y_min <- q_lo
  y_max <- q_hi
} else {
  y_min <- min(df$y_w, na.rm = TRUE)
  y_max <- max(df$y_w, na.rm = TRUE)
}

y_breaks <- seq(
  from = floor(y_min / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  to   = ceiling(y_max / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  by   = Y_BREAKS_STEP
)

# =========================
# 4) Plot
# =========================
p <- ggplot(df, aes(x = CapacityGroup, y = y_w, fill = Type)) +
  
  # 半小提琴（云）
  stat_halfeye(
    adjust = 0.8,
    width = 0.58,
    .width = 0,
    justification = -0.22,
    point_colour = NA,
    alpha = 0.72
  ) +
  
  # 散点（只新增这一层）
  geom_point(
    aes(color = Type),
    position = position_jitter(width = 0.06, height = 0, seed = 123),
    size = 0.7,
    alpha = 0.20,
    shape = 16,
    show.legend = FALSE
  ) +
  
  # 箱线
  geom_boxplot(
    width = 0.16,
    outlier.shape = NA,
    color = "black",
    fill = "white",
    linewidth = 0.8
  ) +
  
  facet_wrap(~ Type, nrow = 1, scales = "fixed") +
  
  scale_fill_manual(values = type_pal, drop = FALSE) +
  scale_color_manual(values = type_pal, drop = FALSE) +
  
  scale_y_continuous(
    limits = c(y_min, y_max),
    breaks = y_breaks,
    expand = c(0, 0)
  ) +
  
  labs(
    x = "Plant capacity group (MW)",
    y = expression(Delta*T)
  ) +
  
  theme_bw(base_size = 12) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1.1),
    
    strip.background = element_blank(),
    strip.text = element_text(face = "bold", size = 13),
    
    axis.text.x = element_text(size = 11),
    axis.ticks.x = element_line(linewidth = 0.8),
    
    axis.text.y = element_text(size = 11),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12),
    
    legend.position = "none",
    plot.margin = margin(6, 6, 6, 6)
  )

# =========================
# 5) Export main figure
# =========================
out_svg <- file.path(out_dir, "type_panel_capacity_raincloud.svg")
ggsave(
  out_svg,
  p,
  width = 9.0,
  height = 3.7,
  device = svglite::svglite
)
message("✅ Saved: ", out_svg)

# =========================
# 6) Export standalone legend SVG
# =========================
legend_plot <- ggplot(
  data.frame(Type = factor(type_levels, levels = type_levels)),
  aes(x = Type, y = 1, fill = Type)
) +
  geom_tile(width = 0.9, height = 0.9, color = NA) +
  scale_fill_manual(values = type_pal, drop = FALSE) +
  guides(
    fill = guide_legend(
      title = NULL,
      direction = "vertical",
      byrow = TRUE,
      keywidth  = unit(8, "mm"),
      keyheight = unit(6, "mm"),
      label.position = "right",
      label.hjust = 0,
      default.unit = "mm"
    )
  ) +
  theme_void(base_size = 12) +
  theme(
    legend.position = "right",
    legend.text = element_text(size = 12),
    legend.key = element_rect(color = NA, fill = NA),
    legend.spacing.y = unit(2, "mm")
  )

leg <- cowplot::get_legend(legend_plot)

out_legend_svg <- file.path(out_dir, "legend_type.svg")
ggsave(
  out_legend_svg,
  plot = leg,
  width = 2.4, height = 1.2,
  device = svglite::svglite
)
message("Saved legend: ", out_legend_svg)