# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(svglite)
  library(cowplot)
})

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/48/48plants_MR_pop_GDP2加SMOD.xlsx"

COL_CAP  <- "Plant_Capacity"
COL_TYPE <- "Type"
COL_Y    <- "delt_warm_min"

out_dir <- "type_panel_capacity_absolute_boxplot_svg"
dir.create(out_dir, showWarnings = FALSE)

type_levels <- c("coal", "oil/gas", "bioenergy")

type_pal <- c(
  "coal"      = "#d40d8c",
  "oil/gas"   = "#0070b8",
  "bioenergy" = "#00b3b0"
)

# =========================
# 1.5) 统一 y 轴 + 抑制极端值
# =========================
WINSOR_P_LO <- 0.01
WINSOR_P_HI <- 0.99

USE_GLOBAL_YLIM_FROM_WINSOR <- TRUE

USE_MANUAL_YLIM <- FALSE
Y_MIN_MANUAL <- -1.5
Y_MAX_MANUAL <-  1.5

Y_BREAKS_STEP <- 0.2

# =========================
# 2) Read & clean
# =========================
df0 <- read_excel(excel_path)

need_cols <- c(COL_CAP, COL_TYPE, COL_Y)
stopifnot(all(need_cols %in% names(df0)))

df <- df0 %>%
  transmute(
    cap  = suppressWarnings(as.numeric(.data[[COL_CAP]])),
    Type = as.character(.data[[COL_TYPE]]),
    y    = suppressWarnings(as.numeric(.data[[COL_Y]]))
  ) %>%
  filter(!is.na(cap), !is.na(Type), !is.na(y)) %>%
  filter(Type %in% type_levels) %>%
  mutate(
    Type = factor(Type, levels = type_levels),
    
    # =========================
    # 按绝对容量阈值分组
    # =========================
    CapacityGroup = case_when(
      
      # coal: 0-300 / 300-600 / 450+
      Type == "coal" & cap < 300 ~ "0-300",
      Type == "coal" & cap < 800 ~ "300-800",
      Type == "coal"             ~ "800+",
      
      # oil/gas: 0-200 / 200-500 / 500+
      Type == "oil/gas" & cap < 200 ~ "0-200",
      Type == "oil/gas" & cap < 500 ~ "200-500",
      Type == "oil/gas"             ~ "500+",
      
      # bioenergy: 0-30 / 30-60 / 60+
      Type == "bioenergy" & cap < 30 ~ "0-30",
      Type == "bioenergy" & cap < 60 ~ "30-60",
      Type == "bioenergy"            ~ "60+",
      
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(CapacityGroup))

# 每个 Type 内部重新设定 x 轴顺序
df <- df %>%
  mutate(
    CapacityGroup = factor(
      CapacityGroup,
      levels = c(
        "0-300", "300-800", "800+",
        "0-200", "200-500", "500+",
        "0-30", "30-60", "60+"
      )
    )
  )

# =========================
# 3) Export summary table
# =========================
cap_summary <- df %>%
  count(Type, CapacityGroup, sort = FALSE)

write.csv(
  cap_summary,
  file.path(out_dir, "capacity_group_counts.csv"),
  row.names = FALSE
)

print(cap_summary)

# =========================
# 4) Winsorize y + unified y scale
# =========================
q_lo <- as.numeric(stats::quantile(df$y, probs = WINSOR_P_LO, na.rm = TRUE))
q_hi <- as.numeric(stats::quantile(df$y, probs = WINSOR_P_HI, na.rm = TRUE))

df <- df %>%
  mutate(
    y_w = pmin(pmax(y, q_lo), q_hi)
  )

if (USE_MANUAL_YLIM) {
  y_min <- Y_MIN_MANUAL
  y_max <- Y_MAX_MANUAL
} else if (USE_GLOBAL_YLIM_FROM_WINSOR) {
  y_min <- q_lo
  y_max <- q_hi
} else {
  y_min <- min(df$y_w, na.rm = TRUE)
  y_max <- max(df$y_w, na.rm = TRUE)
}

y_breaks <- seq(
  from = floor(y_min / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  to   = ceiling(y_max / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  by   = Y_BREAKS_STEP
)

# =========================
# 5) Plot: 箱线图 + 黑色散点
# =========================
p <- ggplot(df, aes(x = CapacityGroup, y = y_w, fill = Type)) +
  
  geom_point(
    position = position_jitter(width = 0.18, height = 0, seed = 123),
    size = 1.0,
    alpha = 0.18,
    color = "black",
    show.legend = FALSE
  ) +
  
  geom_boxplot(
    width = 0.42,
    outlier.shape = NA,
    color = "black",
    fill = "white",
    linewidth = 0.8
  ) +
  
  geom_boxplot(
    width = 0.42,
    outlier.shape = NA,
    alpha = 0.48,
    color = NA,
    linewidth = 0.8,
    show.legend = FALSE
  ) +
  
  facet_wrap(~ Type, nrow = 1, scales = "free_x") +
  
  scale_fill_manual(values = type_pal, drop = FALSE) +
  
  scale_y_continuous(
    limits = c(y_min, y_max),
    breaks = y_breaks,
    expand = c(0, 0)
  ) +
  
  labs(
    x = "Plant capacity group (MW)",
    y = expression(Delta*T)
  ) +
  
  theme_bw(base_size = 12) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(color = "black", fill = NA, linewidth = 1.1),
    
    strip.background = element_blank(),
    strip.text = element_text(face = "bold", size = 13),
    
    axis.text.x = element_text(size = 10.5, angle = 25, hjust = 1),
    axis.ticks.x = element_line(linewidth = 0.8),
    
    axis.text.y = element_text(size = 11),
    axis.title.x = element_text(size = 12),
    axis.title.y = element_text(size = 12),
    
    legend.position = "none",
    plot.margin = margin(6, 6, 6, 6)
  )

# =========================
# 6) Export main figure
# =========================
out_svg <- file.path(out_dir, "type_panel_capacity_absolute_boxplot.svg")
out_pdf <- file.path(out_dir, "type_panel_capacity_absolute_boxplot.pdf")

ggsave(
  out_svg,
  p,
  width = 10.0,
  height = 4.2,
  device = svglite::svglite
)

ggsave(
  out_pdf,
  p,
  width = 10.0,
  height = 4.2
)

message("✅ Saved: ", out_svg)

# =========================
# 7) Export standalone legend SVG
# =========================
legend_plot <- ggplot(
  data.frame(Type = factor(type_levels, levels = type_levels)),
  aes(x = Type, y = 1, fill = Type)
) +
  geom_tile(width = 0.9, height = 0.9, color = NA) +
  scale_fill_manual(values = type_pal, drop = FALSE) +
  guides(
    fill = guide_legend(
      title = NULL,
      direction = "vertical",
      byrow = TRUE,
      keywidth  = unit(8, "mm"),
      keyheight = unit(6, "mm"),
      label.position = "right",
      label.hjust = 0,
      default.unit = "mm"
    )
  ) +
  theme_void(base_size = 12) +
  theme(
    legend.position = "right",
    legend.text = element_text(size = 12),
    legend.key = element_rect(color = NA, fill = NA),
    legend.spacing.y = unit(2, "mm")
  )

leg <- cowplot::get_legend(legend_plot)

out_legend_svg <- file.path(out_dir, "legend_type.svg")

ggsave(
  out_legend_svg,
  plot = leg,
  width = 2.4,
  height = 1.2,
  device = svglite::svglite
)

message("Saved legend: ", out_legend_svg)