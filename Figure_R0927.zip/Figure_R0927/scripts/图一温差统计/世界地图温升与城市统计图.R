# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(sf)
  library(ggplot2)
  library(rnaturalearth)
  library(scales)
  library(cowplot)
  library(svglite)
  library(grid)
})

sf::sf_use_s2(FALSE)

# =========================
# 1) File paths
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/48/48plants_MR_pop_GDP2加SMOD.xlsx"
gpkg_path  <- "/Users/xuruiqing/Desktop/文章试验整体流程/data/GHS_UCDB_GLOBE_R2024A_V1_1/GHS_UCDB_GLOBE_R2024A.gpkg"

layer_name <- "GHS_UCDB_THEME_CLIMATE_GLOBE_R2024A"

OUT_MAP_SVG   <- "city_centroid_delt_warm_min_map.svg"
OUT_MAP_PDF   <- "city_centroid_delt_warm_min_map.pdf"
OUT_LEG_SVG   <- "city_centroid_delt_warm_min_legend.svg"
OUT_LEG_PDF   <- "city_centroid_delt_warm_min_legend.pdf"
OUT_FINAL_SVG <- "city_centroid_delt_warm_min_withLegend.svg"
OUT_FINAL_PDF <- "city_centroid_delt_warm_min_withLegend.pdf"

# =========================
# 2) Config
# =========================
LON_COL <- "Longitude"
LAT_COL <- "Latitude"
VAL_COL <- "delt_warm_min"

# GHS-UCDB 城市ID字段
CITY_ID_COL <- "ID_UC_G0"

# =========================
# 3) Read plant excel
# =========================
df_raw <- read_excel(excel_path)

need_cols <- c(LON_COL, LAT_COL, VAL_COL)
if (!all(need_cols %in% names(df_raw))) {
  stop("缺少必要列：", paste(setdiff(need_cols, names(df_raw)), collapse = ", "))
}

df <- df_raw %>%
  mutate(
    Longitude = as.numeric(.data[[LON_COL]]),
    Latitude  = as.numeric(.data[[LAT_COL]]),
    plot_val  = as.numeric(.data[[VAL_COL]])
  ) %>%
  filter(!is.na(Longitude), !is.na(Latitude), !is.na(plot_val))

plants_sf <- st_as_sf(
  df,
  coords = c("Longitude", "Latitude"),
  crs = 4326,
  remove = FALSE
)

# =========================
# 4) Read city polygons
# =========================
cities <- st_read(gpkg_path, layer = layer_name, quiet = TRUE)

cat("当前图层名：", layer_name, "\n")
print(names(cities))
print(st_crs(cities))

# 去掉字段名前缀 X.
names(cities) <- sub("^X\\.", "", names(cities))

if (!(CITY_ID_COL %in% names(cities))) {
  stop(paste0("城市图层中不存在字段：", CITY_ID_COL))
}

geom_col <- attr(cities, "sf_column")

# =========================
# 5) CRS align
# =========================
plants_sf_proj <- st_transform(plants_sf, st_crs(cities))

# =========================
# 6) Spatial join: plant -> city
# =========================
plants_joined <- st_join(
  plants_sf_proj,
  cities[, c(CITY_ID_COL, geom_col)],
  join = st_within,
  left = FALSE
)

cat("成功匹配到城市的电厂数：", nrow(plants_joined), "\n")

# =========================
# 7) Aggregate to city level
# =========================
city_stat <- plants_joined %>%
  st_drop_geometry() %>%
  group_by(.data[[CITY_ID_COL]]) %>%
  summarise(
    mean_delt_warm_min = mean(plot_val, na.rm = TRUE),
    plant_count = n(),
    .groups = "drop"
  )

cities_stat <- cities %>%
  left_join(city_stat, by = CITY_ID_COL) %>%
  filter(!is.na(mean_delt_warm_min))

cat("有电厂且成功聚合的城市数：", nrow(cities_stat), "\n")

# 城市质心点
city_pts <- st_point_on_surface(cities_stat)
city_pts_wgs84 <- st_transform(city_pts, 4326)

# 世界底图
world <- ne_countries(scale = "medium", returnclass = "sf")

# =========================
# 8) Color scale（参考你给的那套）
# =========================
limits <- c(-0.2, 1.0)

cols <- c("#2171B5", "#6BAED6",
          "#FEE8C8", "#FDBB84", "#E34A33", "#B30000","#800026")

anchors <- c(-0.20, -0.05, 0.00, 0.20, 0.40, 0.60, 1)
vals <- rescale(anchors, to = c(0, 1), from = limits)

brks <- c(-0.2, 0, 0.25, 0.5, 0.75, 1.0)

# =========================
# 9) Main map (NO legend)
# =========================
p_map <- ggplot() +
  geom_sf(data = world, fill = "grey88", color = "grey70", linewidth = 0.25) +
  geom_sf(
    data = city_pts_wgs84,
    aes(color = mean_delt_warm_min, size = plant_count),
    alpha = 0.95
  ) +
  scale_color_gradientn(
    colours = cols,
    values  = vals,
    limits  = limits,
    oob     = scales::squish,
    breaks  = brks,
    labels  = label_number(accuracy = 0.01),
    name    = NULL,
    guide   = "none"
  ) +
  scale_size_continuous(
    range = c(0.8, 3.5),
    breaks = c(1, 2, 4, 8,10),
    name = NULL,
    guide = "none"
  ) +
  coord_sf(expand = FALSE, xlim = c(-150, 150), ylim = c(-60, 80)) +
  scale_x_continuous(
    breaks = seq(-150, 150, by = 60),
    labels = function(x) paste0(ifelse(x == 0, "0", abs(x)), "°",
                                ifelse(x < 0, "W", ifelse(x > 0, "E", "")))
  ) +
  scale_y_continuous(
    breaks = seq(-30, 60, by = 30),
    labels = function(y) paste0(ifelse(y == 0, "0", abs(y)), "°",
                                ifelse(y < 0, "S", ifelse(y > 0, "N", "")))
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.background  = element_rect(fill = "white", color = NA),
    panel.grid.major  = element_blank(),
    panel.grid.minor  = element_blank(),
    axis.title        = element_blank(),
    axis.text         = element_text(color = "grey25", size = 9),
    axis.ticks        = element_line(color = "grey60", linewidth = 0.3),
    axis.ticks.length = unit(2.0, "mm"),
    panel.border      = element_rect(color = "grey40", fill = NA, linewidth = 0.6),
    plot.margin       = margin(5, 10, 5, 10)
  )

ggsave(OUT_MAP_SVG, p_map, width = 12, height = 5.2, device = svglite::svglite)
ggsave(OUT_MAP_PDF, p_map, width = 12, height = 5.2)

# =========================
# 10) 两个单独图例
# =========================
LEG_TITLE_COLOR <- "delt_T (°C)"
LEG_TITLE_SIZE  <- "Plant count"

# ---------- 10.1 颜色图例（保持你现在的样式） ----------
p_leg_color_src <- ggplot() +
  geom_sf(data = world, fill = "grey88", color = "grey70", linewidth = 0.25) +
  geom_sf(
    data = city_pts_wgs84,
    aes(color = mean_delt_warm_min),
    size = 2.5,
    alpha = 0.95
  ) +
  scale_color_gradientn(
    colours = cols,
    values  = vals,
    limits  = limits,
    oob     = scales::squish,
    breaks  = brks,
    labels  = label_number(accuracy = 0.01),
    name    = LEG_TITLE_COLOR,
    guide   = guide_colorbar(
      barheight = unit(50, "mm"),
      barwidth  = unit(6, "mm"),
      ticks.colour = "grey30",
      frame.colour = "grey30"
    )
  ) +
  theme_minimal(base_size = 12) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    legend.position  = "left",
    legend.title     = element_text(size = 10),
    legend.text      = element_text(size = 9)
  )

leg_color <- cowplot::get_legend(p_leg_color_src)

# 单独导出颜色图例
ggsave(
  "city_centroid_delt_warm_min_color_legend.svg",
  leg_color,
  width = 1.8, height = 2.8,
  device = svglite::svglite
)
ggsave(
  "city_centroid_delt_warm_min_color_legend.pdf",
  leg_color,
  width = 1.8, height = 2.8
)

# ---------- 10.2 点大小图例（单独生成） ----------
# 用一个小数据框专门生成 size legend，更稳
size_df <- data.frame(
  x = 1:5,
  y = 1,
  plant_count = c(1, 3, 5, 10, 20)
)

p_leg_size_src <- ggplot(size_df, aes(x = x, y = y, size = plant_count)) +
  geom_point(color = "grey20", alpha = 0.95) +
  scale_size_continuous(
    range = c(0.8, 3.5),
    breaks = c(1, 3, 5, 10, 20),
    name = LEG_TITLE_SIZE
  ) +
  theme_void(base_size = 12) +
  theme(
    legend.position = "left",
    legend.title    = element_text(size = 10),
    legend.text     = element_text(size = 9)
  )

leg_size <- cowplot::get_legend(p_leg_size_src)

# 单独导出点大小图例
ggsave(
  "city_centroid_delt_warm_min_size_legend.svg",
  leg_size,
  width = 1.6, height = 2.0,
  device = svglite::svglite
)
ggsave(
  "city_centroid_delt_warm_min_size_legend.pdf",
  leg_size,
  width = 1.6, height = 2.0
)

# =========================
# 11) COMBINE map + 两个图例（左下角）
# =========================
# 左下角位置参数（只放颜色图例）
LEG_X <- 0.07
LEG_Y <- 0.09
LEG_W <- 0.12
LEG_H <- 0.42

p_final <- cowplot::ggdraw() +
  cowplot::draw_plot(p_map, x = 0, y = 0, width = 1, height = 1) +
  cowplot::draw_plot(
    leg_color,
    x = LEG_X, y = LEG_Y,
    width = LEG_W, height = LEG_H
  )

ggsave(
  OUT_FINAL_SVG,
  p_final,
  width = 12,
  height = 5.2,
  device = svglite::svglite
)
ggsave(
  OUT_FINAL_PDF,
  p_final,
  width = 12,
  height = 5.2
)

message(
  "Done!\n- ", OUT_MAP_SVG,
  "\n- city_centroid_delt_warm_min_size_legend.svg",
  "\n- city_centroid_delt_warm_min_color_legend.svg",
  "\n- ", OUT_FINAL_SVG
)