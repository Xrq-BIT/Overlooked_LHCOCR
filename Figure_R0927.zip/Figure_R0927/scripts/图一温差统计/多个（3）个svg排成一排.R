# =========================
# 0. Packages
# =========================
library(magick)
library(ggplot2)
library(ggplotify)
library(patchwork)
library(svglite)

# =========================
# 1. 读取四个 SVG + 去掉外部留白
# =========================
svg1 <- image_trim(image_read("44case_temp_combined100000100221.svg"))
# svg2 <- image_trim(image_read("44case_temp_combined100000406040.svg"))
svg3 <- image_trim(image_read("44case_temp_combined100000103708.svg"))
svg4 <- image_trim(image_read("44case_temp_combined100000101668.svg"))

# =========================
# 2. 转成 ggplot 对象
# =========================
p1 <- as.ggplot(svg1)
# p2 <- as.ggplot(svg2)
p3 <- as.ggplot(svg3)
p4 <- as.ggplot(svg4)

# =========================
# 3. 横向拼接（更紧凑）
# =========================
combined <- (p1 + p3 + p4) +
  plot_layout(
    ncol = 3,
    widths = c(1, 1, 1)
  ) &
  theme(
    plot.margin = margin(0, 0, 0)
  )

# =========================
# 4. 导出新的 SVG
# =========================
ggsave(
  "44radial_all_zones_tight2.svg",
  combined,
  width = 11.2,   # 比原来 12 略小一点
  height = 3.2,   # 比原来 3.5 略小一点
  device = svglite,
  bg = "transparent"
)

print(combined)