suppressPackageStartupMessages({
  library(magick)
  library(base64enc)
})

base_dir <- "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图一温差统计/Fig1_complete_composite"
target_name <- Sys.getenv("FIG1_PALETTE_TARGET", unset = "")
if (nzchar(target_name)) {
  svg_files <- file.path(base_dir, target_name)
} else {
  svg_files <- file.path(
    base_dir,
    c(
      "Fig1_complete_main_plants_boxplots_efg_frames.svg",
      "Fig1_complete_background_HWN_plants_boxplots.svg"
    )
  )
}

# Images 1-2 are map legends; images 3-8 are the three temperature fields and
# their color bars. Only the latter are adjusted.
temperature_image_indices <- 3:8

adjust_png_data_uri <- function(uri) {
  prefix <- "data:image/png;base64,"
  encoded <- substring(uri, nchar(prefix) + 1)
  input_raw <- base64decode(encoded)

  input_png <- tempfile(fileext = ".png")
  output_png <- tempfile(fileext = ".png")
  on.exit(unlink(c(input_png, output_png)), add = TRUE)
  writeBin(input_raw, input_png)

  img <- image_read(input_png)
  img <- image_modulate(img, brightness = 101, saturation = 92, hue = 100)
  image_write(img, path = output_png, format = "png")

  paste0(prefix, base64encode(output_png, linewidth = 0))
}

for (svg_file in svg_files) {
  if (!file.exists(svg_file)) stop("Missing SVG: ", svg_file)

  backup <- sub("\\.svg$", "_before_efg_palette.svg", svg_file)
  if (!file.exists(backup)) file.copy(svg_file, backup)

  svg_text <- paste(readLines(svg_file, warn = FALSE), collapse = "\n")
  pattern <- "data:image/png;base64,[A-Za-z0-9+/=]+"
  matches <- regmatches(svg_text, gregexpr(pattern, svg_text, perl = TRUE))[[1]]

  if (length(matches) < max(temperature_image_indices)) {
    stop("Unexpected embedded-image count in ", basename(svg_file), ": ", length(matches))
  }

  adjusted <- matches
  adjusted[temperature_image_indices] <- vapply(
    matches[temperature_image_indices],
    adjust_png_data_uri,
    character(1)
  )
  regmatches(svg_text, gregexpr(pattern, svg_text, perl = TRUE)) <- list(adjusted)
  writeLines(svg_text, svg_file, useBytes = TRUE)

  message("Adjusted e-g palette: ", svg_file)
}
