# Plant-level age-share comparison using the plant-ring warming metric used in Figure 1.
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(scales)
  library(svglite)
  library(cowplot)
})

excel_path <- paste0(
  "/Users/xuruiqing/Desktop/文章试验整体流程/",
  "0706专注煤电与微气候反事实/",
  "coal_plants_with_LSM_10km_productivity副本2.xlsx"
)
out_dir <- paste0(
  "/Users/xuruiqing/Desktop/文章试验整体流程/绘图/图一温差统计/",
  "plant_level_old_child_Q1_Q4_delt_warm_min"
)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

df <- read_excel(excel_path) %>%
  transmute(
    deltT = suppressWarnings(as.numeric(delt_warm_min)),
    old_share = suppressWarnings(as.numeric(ratio_10km_old_worldpop2020)),
    child_share = suppressWarnings(as.numeric(ratio_10km_child_0_4))
  ) %>%
  filter(is.finite(deltT)) %>%
  mutate(
    vulnerable_share = old_share + child_share,
    quartile = ntile(deltT, 4),
    deltT_group = case_when(
      quartile == 1L ~ "ΔT Q1 (low)",
      quartile == 4L ~ "ΔT Q4 (high)",
      TRUE ~ NA_character_
    ),
    deltT_group = factor(
      deltT_group,
      levels = c("ΔT Q1 (low)", "ΔT Q4 (high)")
    )
  ) %>%
  filter(quartile %in% c(1L, 4L))

wilcoxon_result <- function(data, outcome, label) {
  z <- data %>% filter(is.finite(.data[[outcome]]))
  values <- split(z[[outcome]], z$deltT_group)
  q1 <- values[["ΔT Q1 (low)"]]
  q4 <- values[["ΔT Q4 (high)"]]
  test <- wilcox.test(
    q1, q4,
    alternative = "two.sided",
    exact = FALSE,
    conf.int = TRUE
  )
  p <- unname(test$p.value)

  data.frame(
    outcome = label,
    test = "Two-sided Wilcoxon rank-sum test",
    q1_n = length(q1),
    q4_n = length(q4),
    q1_median = median(q1),
    q4_median = median(q4),
    q4_minus_q1 = median(q4) - median(q1),
    W = unname(test$statistic),
    p_value = p,
    significance = case_when(
      p < 0.001 ~ "***",
      p < 0.01 ~ "**",
      p < 0.05 ~ "*",
      TRUE ~ "ns"
    )
  )
}

tests <- bind_rows(
  wilcoxon_result(df, "old_share", "Population aged 65+"),
  wilcoxon_result(df, "child_share", "Population aged 0-4"),
  wilcoxon_result(df, "vulnerable_share", "Population aged 0-4 or 65+")
)
write.csv(
  tests,
  file.path(out_dir, "age_share_Q1_Q4_delt_warm_min_wilcoxon_tests.csv"),
  row.names = FALSE
)

group_pal <- c(
  "ΔT Q1 (low)" = "#C9DCE6",
  "ΔT Q4 (high)" = "#C97A62"
)

plot_age_share <- function(outcome, y_label, sig_label) {
  z <- df %>% filter(is.finite(.data[[outcome]]))
  ymax <- max(z[[outcome]], na.rm = TRUE)
  # Keep every observation while avoiding an empty lower range for shares
  # whose observed minimum is well above zero.
  ymin <- max(0, floor(min(z[[outcome]], na.rm = TRUE) * 10) / 10)
  yrange <- ymax - ymin
  bracket_y <- ymax + 0.055 * yrange
  upper_y <- ymax + 0.145 * yrange

  ggplot(z, aes(x = deltT_group, y = .data[[outcome]], fill = deltT_group)) +
    geom_point(
      position = position_jitter(width = 0.16, height = 0, seed = 123),
      size = 0.65, alpha = 0.10, color = "#333333", show.legend = FALSE
    ) +
    geom_boxplot(
      width = 0.45, outlier.shape = NA, alpha = 0.88,
      color = "#303030", linewidth = 0.62, show.legend = FALSE
    ) +
    annotate(
      "segment", x = 1, xend = 2, y = bracket_y, yend = bracket_y,
      linewidth = 0.55
    ) +
    annotate(
      "segment", x = 1, xend = 1,
      y = bracket_y - 0.02 * yrange, yend = bracket_y, linewidth = 0.55
    ) +
    annotate(
      "segment", x = 2, xend = 2,
      y = bracket_y - 0.02 * yrange, yend = bracket_y, linewidth = 0.55
    ) +
    annotate(
      "text", x = 1.5, y = bracket_y + 0.025 * yrange,
      label = sig_label, size = 4, fontface = "bold"
    ) +
    scale_fill_manual(values = group_pal) +
    scale_y_continuous(
      labels = percent_format(accuracy = 1),
      limits = c(ymin, upper_y),
      expand = expansion(mult = c(0, 0))
    ) +
    labs(x = NULL, y = y_label) +
    theme_classic(base_size = 12) +
    theme(
      panel.grid = element_blank(),
      panel.border = element_rect(
        fill = NA, color = "#4C4C4C", linewidth = 0.45
      ),
      axis.line = element_blank(),
      axis.ticks = element_line(color = "#666666", linewidth = 0.35),
      axis.text.x = element_text(size = 11, color = "#3F3F3F"),
      axis.text.y = element_text(size = 10.5, color = "#3F3F3F"),
      axis.title = element_text(size = 12),
      legend.position = "none",
      plot.margin = margin(6, 6, 6, 6)
    )
}

p_old <- plot_age_share(
  "old_share",
  "Population aged 65+",
  tests$significance[tests$outcome == "Population aged 65+"]
)
p_child <- plot_age_share(
  "child_share",
  "Population aged 0-4",
  tests$significance[tests$outcome == "Population aged 0-4"]
)
p_vulnerable <- plot_age_share(
  "vulnerable_share",
  "Vulnerable population share",
  tests$significance[tests$outcome == "Population aged 0-4 or 65+"]
)
p_diagnostic <- plot_grid(p_old, p_child, nrow = 1, align = "hv", axis = "tblr")

save_plot <- function(stem, plot, width, height) {
  svg_path <- file.path(out_dir, paste0(stem, ".svg"))
  ggsave(
    svg_path,
    plot, width = width, height = height, device = svglite::svglite
  )
  rsvg::rsvg_pdf(
    svg_path,
    file.path(out_dir, paste0(stem, ".pdf"))
  )
  rsvg::rsvg_png(
    svg_path,
    file.path(out_dir, paste0(stem, ".png")),
    width = round(width * 300)
  )
}

save_plot("plant_old65_share_Q1_Q4_delt_warm_min", p_old, 4, 3.6)
save_plot("plant_child04_share_Q1_Q4_delt_warm_min", p_child, 4, 3.6)
save_plot("plant_vulnerable_share_Q1_Q4_delt_warm_min", p_vulnerable, 4, 3.6)
save_plot("plant_old_child_share_Q1_Q4_delt_warm_min_diagnostic", p_diagnostic, 7.4, 3.9)

print(tests)
cat("\nOutputs written to: ", normalizePath(out_dir), "\n", sep = "")
