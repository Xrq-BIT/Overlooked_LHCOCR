# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(svglite)
  library(stringr)
  library(sf)
  library(rnaturalearth)
  library(cowplot)
})
sf::sf_use_s2(FALSE)

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/48/48plants_MR_pop_GDP2加SMOD2.xlsx"

COL_LAT  <- "Latitude"
COL_LON  <- "Longitude"
COL_TYPE <- "Type"
COL_Y    <- "delt_warm_min"

out_dir <- "region_boxplots_svg3"
dir.create(out_dir, showWarnings = FALSE)

type_levels <- c("coal", "oil/gas", "bioenergy")

type_pal <- c(
  "coal"      = "#d40d8c",
  "oil/gas"   = "#0070b8",
  "bioenergy" = "#00b3b0"
)

# =========================
# 1.5) 你要的关键改动：统一 y 轴 + 抑制极端值
# =========================
# (A) 全局截尾比例：让“极端点”不把箱线压扁
WINSOR_P_LO <- 0.02   # 1%
WINSOR_P_HI <- 0.98   # 99%

# (B) 统一 y 轴显示范围：
#    方案1：自动用“截尾后的全局范围”来统一所有区域（推荐，省事）
USE_GLOBAL_YLIM_FROM_WINSOR <- TRUE

#    方案2：你手工指定一个统一范围（如果你想强制所有图一样）
#    例如：-1.5 到 1.5（按你数据大概，后面你可自己改）
USE_MANUAL_YLIM <- FALSE
Y_MIN_MANUAL <- -1.5
Y_MAX_MANUAL <-  1.5

# (C) y 轴刻度（可不动；想更像 Science 可以 0.5 步长）
Y_BREAKS_STEP <- 0.5


# =========================
# 2) Region assignment by lat/lon (原样保留)
# =========================
# =========================
# 2) Climate-zone assignment by latitude (4 zones)
#    ✅ Replace Region10 with ClimateZone
# =========================
zone_order <- c("Tropical", "Subtropical", "Temperate", "Cold")

assign_zone4 <- function(lat) {
  a <- abs(lat)
  dplyr::case_when(
    is.na(a)          ~ NA_character_,
    a < 23.5          ~ "Tropical",      # 热带（回归线之间）
    a < 35            ~ "Subtropical",   # 副热带
    a < 50            ~ "Temperate",     # 温带
    TRUE              ~ "Cold"           # 寒带/高纬
  )
}
# =========================
# 3) Read & clean（只做“必要的、与你要求一致的”读取）
#     ✅ 改动点：Region10 不再用 assign_region10()，
#     ✅ 而是用“世界地图同款 reg_poly”做空间匹配（经纬度 -> 区域面）
# =========================
df0 <- read_excel(excel_path)

need_cols <- c(COL_LAT, COL_LON, COL_TYPE, COL_Y)
stopifnot(all(need_cols %in% names(df0)))

# 先按你原逻辑清洗成点数据（保留 lat/lon）
df_clean <- df0 %>%
  transmute(
    lat  = suppressWarnings(as.numeric(.data[[COL_LAT]])),
    lon  = suppressWarnings(as.numeric(.data[[COL_LON]])),
    Type = as.character(.data[[COL_TYPE]]),
    y    = suppressWarnings(as.numeric(.data[[COL_Y]]))
  ) %>%
  filter(!is.na(lat), !is.na(lon), !is.na(Type), !is.na(y)) %>%
  filter(Type %in% type_levels) %>%
  mutate(Type = factor(Type, levels = type_levels))

# 直接按纬度分温度带
df <- df_clean %>%
  mutate(
    ClimateZone = assign_zone4(lat),
    ClimateZone = factor(ClimateZone, levels = zone_order)
  ) %>%
  filter(!is.na(ClimateZone))

# =========================
# 3.5) 全局 winsorize + 统一 y 轴范围（新增）
# =========================
q_lo <- as.numeric(stats::quantile(df$y, probs = WINSOR_P_LO, na.rm = TRUE))
q_hi <- as.numeric(stats::quantile(df$y, probs = WINSOR_P_HI, na.rm = TRUE))

df <- df %>%
  mutate(
    y_w = pmin(pmax(y, q_lo), q_hi)   # winsorized 值用于画箱线/散点
  )

if (USE_MANUAL_YLIM) {
  y_min <- Y_MIN_MANUAL
  y_max <- Y_MAX_MANUAL
} else if (USE_GLOBAL_YLIM_FROM_WINSOR) {
  y_min <- q_lo
  y_max <- q_hi
} else {
  y_min <- min(df$y_w, na.rm = TRUE)
  y_max <- max(df$y_w, na.rm = TRUE)
}

# 统一 breaks（让每张图刻度一致）
y_breaks <- seq(
  from = floor(y_min / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  to   = ceiling(y_max / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  by   = Y_BREAKS_STEP
)

# =========================
# 4) Plot function (one region -> one svg)
#    只改：用 y_w + 统一 ylim/breaks
# =========================
plot_one_region <- function(dat_region, reg_code, y_min, y_max, y_breaks) {
  
  ggplot(dat_region, aes(x = Type, y = y_w, fill = Type)) +
    
    geom_point(
      position = position_jitter(width = 0.18, height = 0),
      size = 1.1, alpha = 0.25, color = "black"
    ) +
    
    geom_boxplot(
      width = 0.35,
      outlier.shape = NA,
      color = "black",
      fill = "white",
      linewidth = 0.7
    ) +
    
    geom_boxplot(
      width = 0.35,
      outlier.shape = NA,
      alpha = 0.48,
      color = NA
    ) +
    
    scale_fill_manual(values = type_pal, drop = FALSE) +
    
    # ✅ 统一 y 轴：同一范围 + 同一 breaks（关键）
    scale_y_continuous(
      limits = c(y_min, y_max),
      breaks = y_breaks,
      expand = c(0, 0)
    ) +
    
    labs(x = NULL, y = expression(Delta*T)) +
    
    theme_bw(base_size = 12) +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 1.1),
      
      plot.title = element_text(face = "bold", size = 13, hjust = 0.5),
      
      axis.text.x = element_text(size = 11),
      axis.ticks.x = element_line(linewidth = 0.8),
      
      axis.text.y = element_text(size = 11),
      axis.title.y = element_text(size = 12),
      
      legend.position = "none",
      plot.margin = margin(6, 6, 6, 6)
    ) +
    ggtitle(reg_code)
}

# =========================
# 5) Export loop + collect plots for a combined SVG
# =========================
regions_to_export <- df %>%
  filter(!is.na(ClimateZone)) %>%
  distinct(ClimateZone) %>%
  arrange(ClimateZone) %>%
  pull(ClimateZone) %>%
  as.character()

# ✅ 用来收集每个区的 ggplot 对象
plot_list <- vector("list", length(regions_to_export))
names(plot_list) <- regions_to_export

for (reg in regions_to_export) {
  dat_reg <- df %>% filter(ClimateZone == reg)
  if (nrow(dat_reg) == 0) next
  
  p <- plot_one_region(dat_reg, reg, y_min, y_max, y_breaks)
  
  out_svg <- file.path(out_dir, paste0("zone_", reg, "_box.svg"))
  ggsave(out_svg, p, width = 3.1, height = 3.0, device = svglite::svglite)
  message("Saved: ", out_svg, "  (n=", nrow(dat_reg), ")")
  
  # ✅ 收集起来，后面拼图用
  plot_list[[reg]] <- p
}

# ✅ 去掉可能为空的（极少数情况下某个 zone 没样本）
plot_list <- plot_list[!vapply(plot_list, is.null, logical(1))]

# =========================
# 5.5) Combine 4 zone plots into ONE horizontal SVG
# =========================
# 你希望固定顺序：热带-副热带-温带-寒带
zone_order_fixed <- c("Tropical", "Subtropical", "Temperate", "Cold")
zone_order_fixed <- zone_order_fixed[zone_order_fixed %in% names(plot_list)]

combined <- cowplot::plot_grid(
  plotlist = plot_list[zone_order_fixed],
  nrow = 1, align = "hv", axis = "tblr"
)

# 宽度按单图 3.1*4 = 12.4；高度仍 3.0（你可微调）
out_combined_svg <- file.path(out_dir, "zones_4panel_horizontal.svg")
ggsave(
  out_combined_svg,
  combined,
  width = 3.1 * length(zone_order_fixed),
  height = 3.0,
  device = svglite::svglite
)
out_combined_pdf <- file.path(out_dir, "zones_4panel_horizontal.pdf")
ggsave(
  out_combined_pdf,
  combined,
  width = 3.1 * length(zone_order_fixed),
  height = 3.0,
)
message("✅ Saved combined: ", out_combined_svg)

# =========================
# 6) Export a standalone legend SVG (Type colors)
#    ✅ 只新增，不改你原图
# =========================
legend_plot <- ggplot(
  data.frame(Type = factor(type_levels, levels = type_levels)),
  aes(x = Type, y = 1, fill = Type)
) +
  geom_tile(width = 0.9, height = 0.9, color = NA) +
  scale_fill_manual(values = type_pal, drop = FALSE) +
  guides(
    fill = guide_legend(
      title = NULL,
      direction = "vertical",
      byrow = TRUE,
      keywidth  = unit(8, "mm"),
      keyheight = unit(6, "mm"),
      label.position = "right",
      label.hjust = 0,
      default.unit = "mm"
    )
  ) +
  theme_void(base_size = 12) +
  theme(
    legend.position = "right",
    legend.text = element_text(size = 12),
    legend.key = element_rect(color = NA, fill = NA),
    legend.spacing.y = unit(2, "mm")
  )

# 把图例提取出来再保存（避免空白画布）
leg <- cowplot::get_legend(legend_plot)

out_legend_svg <- file.path(out_dir, "legend_type.svg")
ggsave(
  out_legend_svg,
  plot = leg,
  width = 2.4, height = 1.2, # 你可以按需要微调
  device = svglite::svglite
)
message("Saved legend: ", out_legend_svg)