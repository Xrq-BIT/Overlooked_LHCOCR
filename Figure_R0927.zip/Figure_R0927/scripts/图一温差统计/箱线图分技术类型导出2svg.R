# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(svglite)
  library(cowplot)
  library(stringr)
})

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/48/48plants_MR_pop_GDP2加SMOD.xlsx"

COL_TYPE <- "Type"
COL_TECH <- "Technology"
COL_Y    <- "delt_warm_min"

out_dir <- "technology_subtype_boxplots_svg"
dir.create(out_dir, showWarnings = FALSE)

type_levels <- c("coal", "oil/gas")

type_pal <- c(
  "coal"      = "#d40d8c",
  "oil/gas"   = "#0070b8"
)

# =========================
# 1.5) 统一 y 轴 + 抑制极端值
# =========================
WINSOR_P_LO <- 0.02
WINSOR_P_HI <- 0.98

USE_GLOBAL_YLIM_FROM_WINSOR <- TRUE

USE_MANUAL_YLIM <- FALSE
Y_MIN_MANUAL <- -1.5
Y_MAX_MANUAL <-  1.5

Y_BREAKS_STEP <- 0.2

# =========================
# 2) Read & clean
# =========================
df0 <- read_excel(excel_path)

need_cols <- c(COL_TYPE, COL_TECH, COL_Y)
stopifnot(all(need_cols %in% names(df0)))

df <- df0 %>%
  transmute(
    Type = as.character(.data[[COL_TYPE]]),
    Technology = as.character(.data[[COL_TECH]]),
    y = suppressWarnings(as.numeric(.data[[COL_Y]]))
  ) %>%
  filter(!is.na(Type), !is.na(Technology), !is.na(y)) %>%
  filter(Type %in% type_levels) %>%
  mutate(
    Type = factor(Type, levels = type_levels),
    tech_lower = str_to_lower(str_trim(Technology))
  ) %>%
  filter(
    tech_lower != "",
    !tech_lower %in% c("unknown", "na", "n/a")
  )

# =========================
# 3) Auto technology classification
# 每行只归到一个技术组
# =========================
df <- df %>%
  mutate(
    Tech_group = case_when(
      
      # -----------------
      # coal: 4 groups
      # -----------------
      # ---- coal（按技术梯度细分） ----
      
      Type == "coal" & str_detect(tech_lower, "subcritical") ~ "Subcritical",
      
      Type == "coal" & str_detect(tech_lower, "ultra-supercritical|ultra supercritical") ~ "Ultra-supercritical",
      
      Type == "coal" & str_detect(tech_lower, "supercritical") ~ "Supercritical",
      
      Type == "coal" & str_detect(tech_lower, "igcc|cfb") ~ "Advanced",
      
      Type == "coal" ~ "Other coal tech",
      
      # -----------------
      # oil/gas: 4 groups
      # -----------------
      Type == "oil/gas" & str_detect(tech_lower, "combined cycle|iscc|iccc") ~ "Combined cycle",
      
      Type == "oil/gas" & str_detect(tech_lower, "gas turbine") ~ "Gas turbine",
      
      Type == "oil/gas" & str_detect(tech_lower, "steam turbine") ~ "Steam turbine",
      
      Type == "oil/gas" ~ "Other oil/gas tech",
      
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(Tech_group))

# =========================
# 4) Set order for subgroups
# =========================
tech_order <- c(
  "Subcritical",
  "Supercritical",
  "Ultra-supercritical",
  "Advanced",
  "Other coal tech",
  "Combined cycle", "Gas turbine", "Steam turbine", "Other oil/gas tech"
)

df <- df %>%
  mutate(
    Tech_group = factor(Tech_group, levels = tech_order)
  )

# =========================
# 5) Export summary table
# =========================
tech_summary <- df %>%
  count(Type, Tech_group, sort = FALSE)

write.csv(
  tech_summary,
  file.path(out_dir, "technology_group_counts.csv"),
  row.names = FALSE
)

# =========================
# 6) Winsorize y + unified y scale
# =========================
q_lo <- as.numeric(stats::quantile(df$y, probs = WINSOR_P_LO, na.rm = TRUE))
q_hi <- as.numeric(stats::quantile(df$y, probs = WINSOR_P_HI, na.rm = TRUE))

df <- df %>%
  mutate(
    y_w = pmin(pmax(y, q_lo), q_hi)
  )

if (USE_MANUAL_YLIM) {
  y_min <- Y_MIN_MANUAL
  y_max <- Y_MAX_MANUAL
} else if (USE_GLOBAL_YLIM_FROM_WINSOR) {
  y_min <- q_lo
  y_max <- q_hi
} else {
  y_min <- min(df$y_w, na.rm = TRUE)
  y_max <- max(df$y_w, na.rm = TRUE)
}

y_breaks <- seq(
  from = floor(y_min / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  to   = ceiling(y_max / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  by   = Y_BREAKS_STEP
)

# =========================
# 7) 单个子图函数
# =========================
plot_one_type <- function(dat, type_name, fill_col, y_min, y_max, y_breaks) {
  ggplot(dat, aes(x = Tech_group, y = y_w)) +
    
    geom_point(
      position = position_jitter(width = 0.18, height = 0, seed = 123),
      size = 1.0,
      alpha = 0.18,
      color = "black",
      show.legend = FALSE
    ) +
    
    geom_boxplot(
      width = 0.42,
      outlier.shape = NA,
      color = "black",
      fill = "white",
      linewidth = 0.8
    ) +
    
    geom_boxplot(
      width = 0.42,
      outlier.shape = NA,
      alpha = 0.48,
      color = NA,
      fill = fill_col
    ) +
    
    scale_y_continuous(
      limits = c(y_min, y_max),
      breaks = y_breaks,
      expand = c(0, 0)
    ) +
    
    labs(
      x = NULL,
      y = expression(Delta*T),
      title = type_name
    ) +
    
    theme_bw(base_size = 12) +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 1.1),
      
      plot.title = element_text(face = "bold", size = 13, hjust = 0.5),
      
      axis.text.x = element_text(size = 10.5, angle = 25, hjust = 1),
      axis.ticks.x = element_line(linewidth = 0.8),
      
      axis.text.y = element_text(size = 11),
      axis.title.x = element_blank(),
      axis.title.y = element_text(size = 12),
      
      legend.position = "none",
      plot.margin = margin(6, 6, 6, 6)
    )
}

# =========================
# 8) 分别生成两个子图并导出
# =========================
plot_list <- list()

for (tp in type_levels) {
  dat_tp <- df %>% filter(Type == tp)
  if (nrow(dat_tp) == 0) next
  
  p_tp <- plot_one_type(
    dat = dat_tp,
    type_name = tp,
    fill_col = type_pal[[tp]],
    y_min = y_min,
    y_max = y_max,
    y_breaks = y_breaks
  )
  
  file_name_tp <- paste0("technology_subtype_", gsub("/", "_", tp), ".svg")
  out_svg_tp <- file.path(out_dir, file_name_tp)
  
  width_tp <- if (tp == "coal") 4.0 else 4.0
  
  ggsave(
    out_svg_tp,
    p_tp,
    width = width_tp,
    height = 4.0,
    device = svglite::svglite
  )
  
  message("Saved: ", out_svg_tp)
  plot_list[[tp]] <- p_tp
}

# =========================
# 9) 合并两个子图
# =========================
plot_list_fixed <- plot_list[type_levels]
plot_list_fixed <- plot_list_fixed[!vapply(plot_list_fixed, is.null, logical(1))]

combined <- cowplot::plot_grid(
  plotlist = plot_list_fixed,
  nrow = 1,
  align = "hv",
  axis = "tblr",
  rel_widths = c(1, 1)
)

out_combined_svg <- file.path(out_dir, "technology_subtype_boxplots_2panel.svg")
ggsave(
  out_combined_svg,
  combined,
  width = 8.4,
  height = 4.0,
  device = svglite::svglite
)

message("✅ Saved combined: ", out_combined_svg)

# =========================
# 10) Export standalone legend SVG
# =========================
legend_plot <- ggplot(
  data.frame(Type = factor(type_levels, levels = type_levels)),
  aes(x = Type, y = 1, fill = Type)
) +
  geom_tile(width = 0.9, height = 0.9, color = NA) +
  scale_fill_manual(values = type_pal, drop = FALSE) +
  guides(
    fill = guide_legend(
      title = NULL,
      direction = "vertical",
      byrow = TRUE,
      keywidth = unit(8, "mm"),
      keyheight = unit(6, "mm"),
      label.position = "right",
      label.hjust = 0,
      default.unit = "mm"
    )
  ) +
  theme_void(base_size = 12) +
  theme(
    legend.position = "right",
    legend.text = element_text(size = 12),
    legend.key = element_rect(color = NA, fill = NA),
    legend.spacing.y = unit(2, "mm")
  )

leg <- cowplot::get_legend(legend_plot)

out_legend_svg <- file.path(out_dir, "legend_type.svg")
ggsave(
  out_legend_svg,
  plot = leg,
  width = 2.4,
  height = 1.2,
  device = svglite::svglite
)

# 顺带导出 PDF
out_combined_pdf <- file.path(out_dir, "technology_subtype_boxplots_2panel.pdf")
ggsave(
  out_combined_pdf,
  combined,
  width = 8.4,
  height = 4.0
)

message("Saved legend: ", out_legend_svg)