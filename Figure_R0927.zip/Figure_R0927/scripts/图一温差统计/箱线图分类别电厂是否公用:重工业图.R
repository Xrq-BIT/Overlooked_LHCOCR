suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(stringr)
  library(svglite)
  library(cowplot)
})

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/48/48plants_MR_pop_GDP2加SMOD.xlsx"

COL_FUEL <- "Type"
COL_Y    <- "delt_warm_min"
COL_CAPT <- "Captive Industry Type"

out_dir <- "captive_heavy_vs_noncaptive_box"
dir.create(out_dir, showWarnings = FALSE)

fuel_levels <- c("coal","oil/gas","bioenergy")

# 全局 winsor + 统一y轴
WINSOR_P_LO <- 0.02
WINSOR_P_HI <- 0.98
Y_BREAKS_STEP <- 0.25

# 点太多就抽样（兼容旧 dplyr）
MAX_POINTS_PER_GROUP <- 900

# =========================
# 2) Read & clean
# =========================
df0 <- read_excel(excel_path)
stopifnot(all(c(COL_FUEL, COL_Y, COL_CAPT) %in% names(df0)))

df <- df0 %>%
  transmute(
    Fuel = as.character(.data[[COL_FUEL]]),
    y    = suppressWarnings(as.numeric(.data[[COL_Y]])),
    cap_raw = str_squish(str_to_lower(as.character(.data[[COL_CAPT]])))
  ) %>%
  filter(!is.na(Fuel), !is.na(y)) %>%
  mutate(
    Fuel = factor(Fuel, levels = fuel_levels),
    CaptiveGroup = case_when(
      is.na(cap_raw) | cap_raw == "" | cap_raw == "na" ~ "Grid_plant",
      str_detect(cap_raw,
                 "iron & steel|steel|aluminum|nickel|cement|oil & refining|refining|chemicals|pulp & paper|other metals & mining|mining|coal mining"
      ) ~ "Industrial_plant",
      TRUE ~ NA_character_
    )
  ) %>%
  filter(!is.na(Fuel), !is.na(CaptiveGroup)) %>%
  mutate(
    CaptiveGroup = factor(CaptiveGroup, levels = c("Grid_plant","Industrial_plant"))
  )

# =========================
# 3) Winsorize globally + unified y axis
# =========================
q_lo <- as.numeric(stats::quantile(df$y, probs = WINSOR_P_LO, na.rm = TRUE))
q_hi <- as.numeric(stats::quantile(df$y, probs = WINSOR_P_HI, na.rm = TRUE))

df <- df %>% mutate(y_w = pmin(pmax(y, q_lo), q_hi))

y_min <- q_lo
y_max <- q_hi

y_breaks <- seq(
  from = floor(y_min / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  to   = ceiling(y_max / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  by   = Y_BREAKS_STEP
)

# =========================
# 4) Plot function (match your "zone" style)
# =========================
grp_pal <- c(
  "Grid_plant"   = "#8DA0CB",  # 你也可以换更浅一点
  "Industrial_plant" = "#FC8D62"
)
plot_one_fuel <- function(dat_fu, fuel_name) {
  
  # 抽样点（兼容旧 dplyr；每组最多 MAX_POINTS_PER_GROUP）
  set.seed(1)
  pts <- dat_fu %>%
    group_by(CaptiveGroup) %>%
    group_modify(~{
      n_take <- min(nrow(.x), MAX_POINTS_PER_GROUP)
      .x[sample.int(nrow(.x), n_take), , drop = FALSE]
    }) %>%
    ungroup()
  
  ggplot(dat_fu, aes(x = CaptiveGroup, y = y_w, fill = CaptiveGroup)) +
    
    # 点：统一灰色（别用 fill 颜色，否则太花）
    geom_point(
      data = pts,
      position = position_jitter(width = 0.18, height = 0),
      size = 1.1, alpha = 0.18, color = "black"
    ) +
    
    # 先画“淡色箱体”（有颜色）
    geom_boxplot(
      width = 0.35,
      outlier.shape = NA,
      alpha = 0.55,
      color = NA
    ) +
    
    # 再叠一层“黑边框箱线”（保证期刊风）
    geom_boxplot(
      width = 0.35,
      outlier.shape = NA,
      color = "black",
      fill  = NA,          # ✅ 关键：只画边框，不覆盖前面的颜色
      linewidth = 0.9
    ) +
    
    scale_fill_manual(values = grp_pal, drop = FALSE) +
    
    scale_y_continuous(
      limits = c(y_min, y_max),
      breaks = y_breaks,
      expand = c(0, 0)
    ) +
    
    labs(x = NULL, y = expression(Delta*T[heat])) +
    ggtitle(fuel_name) +
    
    theme_bw(base_size = 12) +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 1.1),
      
      plot.title = element_text(face = "bold", size = 13, hjust = 0.5),
      
      axis.text.x = element_text(size = 12),
      axis.ticks.x = element_line(linewidth = 0.8),
      
      axis.text.y = element_text(size = 11),
      axis.title.y = element_text(size = 12),
      
      legend.position = "none",
      plot.margin = margin(6, 6, 6, 6)
    )
}

# =========================
# 5) Export 3 single SVGs + collect plots
# =========================
plot_list <- vector("list", length(fuel_levels))
names(plot_list) <- fuel_levels

for (fu in fuel_levels) {
  dat_fu <- df %>% filter(Fuel == fu)
  if (nrow(dat_fu) == 0) next
  
  p <- plot_one_fuel(dat_fu, fu)
  
  out_svg <- file.path(out_dir, paste0("heavy_vs_non_", gsub("/", "_", fu), ".svg"))
  ggsave(out_svg, p, width = 3.2, height = 3.0, device = svglite::svglite)
  message("Saved: ", out_svg, " (n=", nrow(dat_fu), ")")
  
  plot_list[[fu]] <- p
}

plot_list <- plot_list[!vapply(plot_list, is.null, logical(1))]

# =========================
# 6) Combine 3 fuel plots into ONE horizontal SVG
# =========================
fuel_order_fixed <- c("coal","oil/gas","bioenergy")
fuel_order_fixed <- fuel_order_fixed[fuel_order_fixed %in% names(plot_list)]

combined <- cowplot::plot_grid(
  plotlist = plot_list[fuel_order_fixed],
  nrow = 1,
  align = "hv",
  axis = "tblr"
)

out_combined_svg <- file.path(out_dir, "heavy_vs_non_3panel_horizontal.svg")
ggsave(
  out_combined_svg,
  combined,
  width  = 3.2 * length(fuel_order_fixed),
  height = 3.0,
  device = svglite::svglite
)

message("✅ Saved combined: ", out_combined_svg)
message("Winsor: [", signif(q_lo, 4), ", ", signif(q_hi, 4), "]")