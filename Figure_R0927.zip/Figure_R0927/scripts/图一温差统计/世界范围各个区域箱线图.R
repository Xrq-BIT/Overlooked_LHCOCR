# =========================
# 0) Packages
# =========================
suppressPackageStartupMessages({
  library(readxl)
  library(dplyr)
  library(ggplot2)
  library(svglite)
  library(stringr)
  library(sf)
  library(rnaturalearth)
  library(cowplot)
})
sf::sf_use_s2(FALSE)

# =========================
# 1) Config
# =========================
excel_path <- "/Users/xuruiqing/Desktop/文章试验整体流程/杂七杂八验证/Plant_2019_all_info_area_heat_cold_delt.xlsx"

COL_LAT  <- "Latitude"
COL_LON  <- "Longitude"
COL_TYPE <- "Type"
COL_Y    <- "heat_delt"

out_dir <- "region_boxplots_svg2"
dir.create(out_dir, showWarnings = FALSE)

type_levels <- c("coal", "oil/gas", "bioenergy")

type_pal <- c(
  "coal"      = "#d40d8c",
  "oil/gas"   = "#0070b8",
  "bioenergy" = "#00b3b0"
)

# =========================
# 1.5) 你要的关键改动：统一 y 轴 + 抑制极端值
# =========================
# (A) 全局截尾比例：让“极端点”不把箱线压扁
WINSOR_P_LO <- 0.02   # 1%
WINSOR_P_HI <- 0.98   # 99%

# (B) 统一 y 轴显示范围：
#    方案1：自动用“截尾后的全局范围”来统一所有区域（推荐，省事）
USE_GLOBAL_YLIM_FROM_WINSOR <- TRUE

#    方案2：你手工指定一个统一范围（如果你想强制所有图一样）
#    例如：-1.5 到 1.5（按你数据大概，后面你可自己改）
USE_MANUAL_YLIM <- FALSE
Y_MIN_MANUAL <- -1.5
Y_MAX_MANUAL <-  1.5

# (C) y 轴刻度（可不动；想更像 Science 可以 0.5 步长）
Y_BREAKS_STEP <- 0.5


# =========================
# 2) Region assignment by lat/lon (原样保留)
# =========================
# =========================
# 2) Region assignment (EXACTLY consistent with world map: build reg_poly then spatial-join points)
# =========================

region_order <- c("EUR","MED","FSU","EAS","NAM","SEA","AFN","AFS","SAS","PAN","CSA")

# --- build world polygons and assign each country to Region10 (same as your map script) ---
world <- ne_countries(scale = "medium", returnclass = "sf") %>%
  st_transform(4326) %>%
  st_make_valid()

world_wrapped <- st_wrap_dateline(
  world,
  options = c("WRAPDATELINE=YES", "DATELINEOFFSET=180")
) %>% st_make_valid()

pts_w <- st_point_on_surface(world_wrapped)
xy_w  <- st_coordinates(pts_w)
world_wrapped$lon_pt <- xy_w[,1]
world_wrapped$lat_pt <- xy_w[,2]

fsu_countries <- c(
  "Russia","Ukraine","Belarus","Moldova",
  "Estonia","Latvia","Lithuania",
  "Georgia","Armenia","Azerbaijan",
  "Kazakhstan","Kyrgyzstan","Tajikistan","Turkmenistan","Uzbekistan"
)

eas_countries <- c("China","Mongolia","Japan","North Korea","South Korea","Taiwan")

sas_countries <- c("India","Pakistan","Bangladesh","Nepal","Bhutan","Sri Lanka","Afghanistan")

sea_countries <- c(
  "Myanmar","Thailand","Laos","Cambodia","Vietnam","Malaysia","Singapore",
  "Indonesia","Philippines","Brunei","Timor-Leste"
)

nam_countries <- c("Canada","United States of America","Mexico","Greenland")

pan_countries <- c(
  "Australia","New Zealand","Papua New Guinea","Fiji","Solomon Islands",
  "Vanuatu","Samoa","Tonga","Micronesia","Palau","Marshall Islands",
  "Kiribati","Tuvalu","Nauru","New Caledonia"
)

# MED：只保留 Middle East / West Asia（不包含非洲）
med_countries <- c(
  "Turkey","Cyprus","Syria","Lebanon","Israel","Jordan","Iraq","Iran",
  "Saudi Arabia","Yemen","Oman","United Arab Emirates","Qatar","Kuwait","Bahrain"
)

world_wrapped <- world_wrapped %>%
  mutate(
    .name = dplyr::coalesce(.data$admin, .data$name_long, .data$name),
    .continent = dplyr::coalesce(.data$continent, NA_character_),
    .subregion = dplyr::coalesce(.data$subregion, NA_character_)
  )

world_wrapped$Region10 <- dplyr::case_when(
  # FSU
  world_wrapped$.name %in% fsu_countries ~ "FSU",
  
  # NAM
  world_wrapped$.name %in% nam_countries ~ "NAM",
  world_wrapped$.continent == "North America" ~ "NAM",
  
  # CSA
  world_wrapped$.continent == "South America" ~ "CSA",
  (world_wrapped$.continent == "North America" &
     world_wrapped$.subregion %in% c("Central America","Caribbean")) ~ "CSA",
  
  # EUR
  world_wrapped$.continent == "Europe" ~ "EUR",
  
  # MED (西亚/中东；非洲不进 MED)
  (world_wrapped$.name %in% med_countries) & (world_wrapped$.continent != "Africa") ~ "MED",
  
  # EAS / SAS / SEA
  world_wrapped$.name %in% eas_countries ~ "EAS",
  world_wrapped$.name %in% sas_countries ~ "SAS",
  world_wrapped$.name %in% sea_countries ~ "SEA",
  
  # PAN
  world_wrapped$.name %in% pan_countries ~ "PAN",
  world_wrapped$.continent == "Oceania" ~ "PAN",
  
  # Africa -> AFR then split by equator
  world_wrapped$.continent == "Africa" ~ "AFR",
  
  TRUE ~ "OTHER"
)

world_wrapped$Region10 <- ifelse(
  world_wrapped$Region10 == "AFR" & !is.na(world_wrapped$lat_pt),
  ifelse(world_wrapped$lat_pt >= 0, "AFN", "AFS"),
  world_wrapped$Region10
)

world2 <- world_wrapped %>%
  select(Region10, geometry) %>%
  filter(Region10 %in% region_order) %>%
  mutate(Region10 = factor(Region10, levels = region_order))

# dissolve to region polygons (and remove strip artifacts) — same as your map script
reg_poly <- world2 %>%
  group_by(Region10) %>%
  summarise(geometry = st_union(geometry), .groups = "drop") %>%
  st_make_valid()

reg_poly <- st_collection_extract(reg_poly, "POLYGON") %>%
  st_make_valid()

reg_poly_parts <- reg_poly %>%
  st_cast("POLYGON", warn = FALSE) %>%
  mutate(
    .bbox = lapply(geometry, st_bbox),
    .w = vapply(.bbox, function(b) as.numeric(b["xmax"] - b["xmin"]), numeric(1)),
    .h = vapply(.bbox, function(b) as.numeric(b["ymax"] - b["ymin"]), numeric(1))
  )

reg_poly_parts$.area_m2 <- as.numeric(st_area(st_transform(reg_poly_parts, 6933)))

reg_poly_parts <- reg_poly_parts %>%
  mutate(
    .is_strip = (.w > 120 & .h < 6 & .area_m2 < 1e12) |
      (.w > 160 & .h < 10 & .area_m2 < 2e12)
  ) %>%
  filter(!.is_strip) %>%
  select(-.bbox, -.w, -.h, -.area_m2, -.is_strip)

reg_poly <- reg_poly_parts %>%
  group_by(Region10) %>%
  summarise(geometry = st_union(geometry), .groups = "drop") %>%
  st_cast("MULTIPOLYGON", warn = FALSE) %>%
  st_make_valid()

# =========================
# 3) Read & clean（只做“必要的、与你要求一致的”读取）
#     ✅ 改动点：Region10 不再用 assign_region10()，
#     ✅ 而是用“世界地图同款 reg_poly”做空间匹配（经纬度 -> 区域面）
# =========================
df0 <- read_excel(excel_path)

need_cols <- c(COL_LAT, COL_LON, COL_TYPE, COL_Y)
stopifnot(all(need_cols %in% names(df0)))

# 先按你原逻辑清洗成点数据（保留 lat/lon）
df_clean <- df0 %>%
  transmute(
    lat  = suppressWarnings(as.numeric(.data[[COL_LAT]])),
    lon  = suppressWarnings(as.numeric(.data[[COL_LON]])),
    Type = as.character(.data[[COL_TYPE]]),
    y    = suppressWarnings(as.numeric(.data[[COL_Y]]))
  ) %>%
  filter(!is.na(lat), !is.na(lon), !is.na(Type), !is.na(y)) %>%
  filter(Type %in% type_levels) %>%
  mutate(Type = factor(Type, levels = type_levels))

# 转 sf 点，并用 reg_poly（地图同款区域面）做空间 join
pts_sf <- st_as_sf(df_clean, coords = c("lon", "lat"), crs = 4326, remove = FALSE)

pts_join <- st_join(
  pts_sf,
  reg_poly[, c("Region10")],   # reg_poly 必须在前面已生成（世界地图那套代码）
  join = st_intersects,
  left = TRUE
)

# 回到普通 df，并按原逻辑过滤 OTHER
df <- pts_join %>%
  st_drop_geometry() %>%
  filter(!is.na(Region10), as.character(Region10) != "OTHER")

region_order <- c("EUR","MED","FSU","EAS","NAM","SEA","AFN","AFS","SAS","PAN","CSA")
df <- df %>% mutate(Region10 = factor(Region10, levels = region_order))

# =========================
# 3.5) 全局 winsorize + 统一 y 轴范围（新增）
# =========================
q_lo <- as.numeric(stats::quantile(df$y, probs = WINSOR_P_LO, na.rm = TRUE))
q_hi <- as.numeric(stats::quantile(df$y, probs = WINSOR_P_HI, na.rm = TRUE))

df <- df %>%
  mutate(
    y_w = pmin(pmax(y, q_lo), q_hi)   # winsorized 值用于画箱线/散点
  )

if (USE_MANUAL_YLIM) {
  y_min <- Y_MIN_MANUAL
  y_max <- Y_MAX_MANUAL
} else if (USE_GLOBAL_YLIM_FROM_WINSOR) {
  y_min <- q_lo
  y_max <- q_hi
} else {
  y_min <- min(df$y_w, na.rm = TRUE)
  y_max <- max(df$y_w, na.rm = TRUE)
}

# 统一 breaks（让每张图刻度一致）
y_breaks <- seq(
  from = floor(y_min / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  to   = ceiling(y_max / Y_BREAKS_STEP) * Y_BREAKS_STEP,
  by   = Y_BREAKS_STEP
)

# =========================
# 4) Plot function (one region -> one svg)
#    只改：用 y_w + 统一 ylim/breaks
# =========================
plot_one_region <- function(dat_region, reg_code, y_min, y_max, y_breaks) {
  
  ggplot(dat_region, aes(x = Type, y = y_w, fill = Type)) +
    
    geom_point(
      position = position_jitter(width = 0.18, height = 0),
      size = 1.1, alpha = 0.25, color = "black"
    ) +
    
    geom_boxplot(
      width = 0.35,
      outlier.shape = NA,
      color = "black",
      fill = "white",
      linewidth = 0.7
    ) +
    
    geom_boxplot(
      width = 0.35,
      outlier.shape = NA,
      alpha = 0.48,
      color = NA
    ) +
    
    scale_fill_manual(values = type_pal, drop = FALSE) +
    
    # ✅ 统一 y 轴：同一范围 + 同一 breaks（关键）
    scale_y_continuous(
      limits = c(y_min, y_max),
      breaks = y_breaks,
      expand = c(0, 0)
    ) +
    
    labs(x = NULL, y = expression(Delta*T[heat])) +
    
    theme_bw(base_size = 12) +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 1.1),
      
      plot.title = element_text(face = "bold", size = 13, hjust = 0.5),
      
      axis.text.x = element_text(size = 11),
      axis.ticks.x = element_line(linewidth = 0.8),
      
      axis.text.y = element_text(size = 11),
      axis.title.y = element_text(size = 12),
      
      legend.position = "none",
      plot.margin = margin(6, 6, 6, 6)
    ) +
    ggtitle(reg_code)
}

# =========================
# 5) Export loop（原样，只把 y 轴参数传进去）
# =========================
regions_to_export <- df %>%
  filter(!is.na(Region10)) %>%
  distinct(Region10) %>%
  arrange(Region10) %>%
  pull(Region10) %>%
  as.character()

for (reg in regions_to_export) {
  dat_reg <- df %>% filter(Region10 == reg)
  if (nrow(dat_reg) == 0) next
  
  p <- plot_one_region(dat_reg, reg, y_min, y_max, y_breaks)
  
  out_svg <- file.path(out_dir, paste0("region_", reg, "_box.svg"))
  ggsave(out_svg, p, width = 3.1, height = 3.0, device = svglite::svglite)
  message("Saved: ", out_svg, "  (n=", nrow(dat_reg), ")")
}

message("✅ Done. Exported SVGs to: ", out_dir)
message("Winsorized at [", WINSOR_P_LO, ", ", WINSOR_P_HI, "] quantiles: ",
        "q_lo=", signif(q_lo, 4), ", q_hi=", signif(q_hi, 4),
        " | y-lim=[", signif(y_min, 4), ", ", signif(y_max, 4), "]")

# =========================
# 6) Export a standalone legend SVG (Type colors)
#    ✅ 只新增，不改你原图
# =========================
legend_plot <- ggplot(
  data.frame(Type = factor(type_levels, levels = type_levels)),
  aes(x = Type, y = 1, fill = Type)
) +
  geom_tile(width = 0.9, height = 0.9, color = NA) +
  scale_fill_manual(values = type_pal, drop = FALSE) +
  guides(
    fill = guide_legend(
      title = NULL,
      direction = "vertical",
      byrow = TRUE,
      keywidth  = unit(8, "mm"),
      keyheight = unit(6, "mm"),
      label.position = "right",
      label.hjust = 0,
      default.unit = "mm"
    )
  ) +
  theme_void(base_size = 12) +
  theme(
    legend.position = "right",
    legend.text = element_text(size = 12),
    legend.key = element_rect(color = NA, fill = NA),
    legend.spacing.y = unit(2, "mm")
  )

# 把图例提取出来再保存（避免空白画布）
leg <- cowplot::get_legend(legend_plot)

out_legend_svg <- file.path(out_dir, "legend_type.svg")
ggsave(
  out_legend_svg,
  plot = leg,
  width = 2.4, height = 1.2, # 你可以按需要微调
  device = svglite::svglite
)
message("Saved legend: ", out_legend_svg)