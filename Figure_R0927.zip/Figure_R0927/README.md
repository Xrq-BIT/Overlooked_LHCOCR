# Coal-plant heat: R plotting scripts

This collection contains R plotting and figure-assembly scripts from the three author-designated figure directories. It is a code collection prepared for release, not a validated end-to-end reproduction package.

## Contents
- `scripts/图一温差统计`: temperature and heatwave figures.
- `scripts/图二经济损失`: economic-loss figures.
- `scripts/图三退役与未来情景`: retirement and future-scenario figures.
- `selection_manifest.csv`: every candidate, modification time, selection decision and SHA-256 checksum.
- `r_packages.csv`: packages detected in retained scripts; this is not a version lockfile.
- `input_path_inventory.csv`: input-reading and local-path statements requiring configuration.
- `syntax_check.txt`: R parsing checks only, not execution tests.

## Selection
94 R files were inspected; 66 were retained. Clear versions of the same task were grouped and the newest modification time selected. Different outcomes, grouping variables, case plants and distinct figure types were retained separately. Files marked deleted in their names were excluded. Explicit R-script dependencies are retained if required. Selection does not imply that every retained analysis appears in the submitted manuscript.

The retained scripts are byte-for-byte copies of the originals. No statistical calculations, labels, paths or graphics settings were changed. Modification times are selection evidence, not proof that a script generated the submitted figure.

## Main figure layout scripts
- Figure 1: `scripts/图一温差统计/组图一_去除ij_双列gh.R`
- Figure 2: `scripts/图二经济损失/图二组图_去除c_第二排双图.R`
- Figure 3, newest layout candidate: `scripts/图三退役与未来情景/组图_2050两情景四象限插入与并排对比版.R`

## Before running or publishing
1. Configure the hard-coded input and output paths. Existing output paths may overwrite local figures; use a separate output directory.
2. Supply the required spreadsheets, CSVs, spatial files and intermediate panels separately. This collection intentionally contains no original PDF, SVG, raster or data files. Some composition scripts read existing SVG panels or previously composed figures; they are not standalone data-to-figure programs. Older scripts needed to generate those intermediate graphics have not been automatically inferred or included.
3. Install the needed R packages and their system dependencies. Test the scripts with the intended source data, then record package versions with `sessionInfo()` or a lockfile. No runtime versions have been fabricated here.
4. Confirm which scripts correspond to the final submitted panels; then choose a licence and add the data-repository link and release DOI. No licence or public upload has been applied automatically.

## 中文说明
本次只汇总R代码，没有改动原目录。明显同任务版本按修改时间保留最新；不同数据指标、案例及绘图用途不强行合并。共检查94份，保留66份，旧版本24份、标记删除4份不纳入代码目录。筛选清单保留所有文件的去向。
代码仍包含本机绝对路径，组图脚本可能依赖已有SVG。此次仅作语法解析检查，未重新运行绘图，也不代表已验证复现投稿图。公开前须配齐数据和中间图依赖、设置路径、确定许可证。原有历史变量名和注释未统一改写。
